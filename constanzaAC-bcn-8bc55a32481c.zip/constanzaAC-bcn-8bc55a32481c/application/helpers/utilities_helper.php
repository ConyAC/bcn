<?php
function get_image($img_name, $return = false) {
	$CI = &get_instance();
	$file_url = base_url().$CI->config->item('IMAGES_FOLDER')."/".$img_name;
	$file_path = "./".$CI->config->item('IMAGES_FOLDER')."/".$img_name;
	
	if(!file_exists($file_path) || $img_name == "") {
		if($return === false)
			echo base_url().$CI->config->item('IMAGES_FOLDER')."/default_image.png";
		else
			return base_url().$CI->config->item('IMAGES_FOLDER')."/default_image.png";
	}
	else {
		if($return === false)
			echo $file_url;
		else
			return $file_url;
	}
}
