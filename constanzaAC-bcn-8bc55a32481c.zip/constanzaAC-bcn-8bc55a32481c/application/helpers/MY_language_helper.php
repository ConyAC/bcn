<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function lang($line, $vars = array())
{
    $CI =& get_instance();
    $line = $CI->lang->line($line);

    if ($vars)
    {
        $line = vsprintf($line, (array) $vars);
    }

    return $line;
}

function load_languages() {
	$CI =& get_instance();
	
	$languages = $CI->config->item('LOADED_LANGUAGES');
	foreach($languages as $lang):
		$CI->lang->load($lang, $CI->session->userdata('locale'));
	endforeach;
}
