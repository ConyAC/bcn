<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-13 03:39:48 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:48 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:48 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:48 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:48 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:48 --> Database Driver Class Initialized
ERROR - 2014-06-13 03:39:48 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 03:39:49 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:49 --> A session cookie was not found.
DEBUG - 2014-06-13 03:39:49 --> Session routines successfully run
ERROR - 2014-06-13 03:39:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:49 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:49 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:49 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:49 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:50 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:50 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:50 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:50 --> Session routines successfully run
ERROR - 2014-06-13 03:39:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:50 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:50 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:50 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:50 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:50 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:50 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:50 --> Session routines successfully run
ERROR - 2014-06-13 03:39:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:50 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:50 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:50 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:39:50 --> File loaded: application/views/auth/login.php
DEBUG - 2014-06-13 03:39:50 --> Final output sent to browser
DEBUG - 2014-06-13 03:39:50 --> Total execution time: 0.0939
DEBUG - 2014-06-13 03:39:55 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:55 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:55 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:55 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:55 --> Session routines successfully run
ERROR - 2014-06-13 03:39:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:55 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:55 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:55 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-06-13 03:39:55 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:55 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:55 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:55 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:55 --> Session routines successfully run
ERROR - 2014-06-13 03:39:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:55 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:55 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:55 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:39:55 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 03:39:58 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:58 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:58 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:58 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:58 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:58 --> Session routines successfully run
ERROR - 2014-06-13 03:39:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:58 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:58 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:58 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:58 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:58 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:58 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:58 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:39:58 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:39:58 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-13 03:39:58 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 03:39:58 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-13 03:39:58 --> Final output sent to browser
DEBUG - 2014-06-13 03:39:58 --> Total execution time: 0.1044
DEBUG - 2014-06-13 03:39:59 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:59 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:59 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:59 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:59 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:59 --> Database Driver Class Initialized
ERROR - 2014-06-13 03:39:59 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:59 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Session Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:39:59 --> Session routines successfully run
DEBUG - 2014-06-13 03:39:59 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Hooks Class Initialized
ERROR - 2014-06-13 03:39:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:39:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:39:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:39:59 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Email Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:39:59 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:39:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:59 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:39:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Controller Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:39:59 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:39:59 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:59 --> Final output sent to browser
DEBUG - 2014-06-13 03:39:59 --> Total execution time: 0.1010
DEBUG - 2014-06-13 03:39:59 --> Database Driver Class Initialized
ERROR - 2014-06-13 03:39:59 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 03:39:59 --> Config Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:39:59 --> URI Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Router Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Output Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Security Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Input Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:39:59 --> Language Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Loader Class Initialized
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:39:59 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:39:59 --> Database Driver Class Initialized
ERROR - 2014-06-13 03:39:59 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 03:40:00 --> Session Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Session Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:40:00 --> Session routines successfully run
DEBUG - 2014-06-13 03:40:00 --> Session routines successfully run
ERROR - 2014-06-13 03:40:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:40:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:40:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:40:00 --> Email Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: cookie_helper
ERROR - 2014-06-13 03:40:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:40:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:40:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Email Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Controller Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:40:00 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:40:00 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Controller Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:40:00 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:40:00 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Final output sent to browser
DEBUG - 2014-06-13 03:40:00 --> Total execution time: 1.1750
DEBUG - 2014-06-13 03:40:00 --> Final output sent to browser
DEBUG - 2014-06-13 03:40:00 --> Total execution time: 1.1398
DEBUG - 2014-06-13 03:40:00 --> Session Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:40:00 --> Session routines successfully run
ERROR - 2014-06-13 03:40:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:40:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:40:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:40:00 --> Email Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Model Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Controller Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:40:00 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:40:00 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:40:00 --> Final output sent to browser
DEBUG - 2014-06-13 03:40:00 --> Total execution time: 1.2219
DEBUG - 2014-06-13 03:43:49 --> Config Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:43:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:43:49 --> URI Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Router Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Output Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Security Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Input Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:43:49 --> Language Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Loader Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:43:49 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:43:49 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Session Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:43:49 --> Session routines successfully run
ERROR - 2014-06-13 03:43:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:43:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:43:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:43:49 --> Email Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:43:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:43:49 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:43:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:43:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:43:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Controller Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:43:49 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:43:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:43:49 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:43:49 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:43:49 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 03:43:49 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 03:43:49 --> Final output sent to browser
DEBUG - 2014-06-13 03:43:49 --> Total execution time: 0.1649
DEBUG - 2014-06-13 03:43:57 --> Config Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:43:57 --> URI Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Router Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Output Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Security Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Input Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:43:57 --> Language Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Loader Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:43:57 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:43:57 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Session Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:43:57 --> Session routines successfully run
ERROR - 2014-06-13 03:43:57 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:43:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:43:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:43:57 --> Email Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:43:57 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:43:57 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:43:57 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:43:57 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Model Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Controller Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:43:57 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:43:57 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:43:57 --> Final output sent to browser
DEBUG - 2014-06-13 03:43:57 --> Total execution time: 0.1981
DEBUG - 2014-06-13 03:44:32 --> Config Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:44:32 --> URI Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Router Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Output Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Security Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Input Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:44:32 --> Language Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Loader Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:44:32 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:44:32 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Session Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:44:32 --> Session routines successfully run
ERROR - 2014-06-13 03:44:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:44:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:44:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:44:32 --> Email Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:44:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:44:32 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:44:32 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:44:32 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Controller Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:44:32 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:44:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:44:32 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:44:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:44:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 03:44:32 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 03:44:32 --> Final output sent to browser
DEBUG - 2014-06-13 03:44:32 --> Total execution time: 0.1113
DEBUG - 2014-06-13 03:44:38 --> Config Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:44:38 --> URI Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Router Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Output Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Security Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Input Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:44:38 --> Language Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Loader Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:44:38 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:44:38 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Session Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:44:38 --> Session routines successfully run
ERROR - 2014-06-13 03:44:38 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:44:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:44:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:44:38 --> Email Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:44:38 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:44:38 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:44:38 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:44:38 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Controller Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:44:38 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:44:38 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:44:38 --> Final output sent to browser
DEBUG - 2014-06-13 03:44:38 --> Total execution time: 0.1665
DEBUG - 2014-06-13 03:44:40 --> Config Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:44:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:44:40 --> URI Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Router Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Output Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Security Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Input Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:44:40 --> Language Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Loader Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:44:40 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:44:40 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Session Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:44:40 --> Session routines successfully run
ERROR - 2014-06-13 03:44:40 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:44:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:44:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:44:40 --> Email Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:44:40 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:44:40 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:44:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:44:40 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:44:40 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Model Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Controller Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:44:40 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:44:40 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:44:40 --> Final output sent to browser
DEBUG - 2014-06-13 03:44:40 --> Total execution time: 0.0784
DEBUG - 2014-06-13 03:55:16 --> Config Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:55:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:55:16 --> URI Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Router Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Output Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Security Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Input Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:55:16 --> Language Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Loader Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:55:16 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:55:16 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:55:16 --> Session Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:55:17 --> Session routines successfully run
ERROR - 2014-06-13 03:55:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:55:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:55:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:55:17 --> Email Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:55:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:55:17 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:17 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:55:17 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Controller Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:17 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:55:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:55:17 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Config Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:55:42 --> URI Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Router Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Output Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Security Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Input Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:55:42 --> Language Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Loader Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:55:42 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:55:42 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Session Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:55:42 --> Session routines successfully run
ERROR - 2014-06-13 03:55:42 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:55:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:55:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:55:42 --> Email Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:55:42 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:55:42 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:42 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:55:42 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Controller Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:42 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:55:42 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:55:42 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:55:42 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:55:42 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 03:55:42 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 03:55:42 --> Final output sent to browser
DEBUG - 2014-06-13 03:55:42 --> Total execution time: 0.1625
DEBUG - 2014-06-13 03:55:46 --> Config Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:55:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:55:46 --> URI Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Router Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Output Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Security Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Input Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:55:46 --> Language Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Loader Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:55:46 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:55:46 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Session Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:55:46 --> Session routines successfully run
ERROR - 2014-06-13 03:55:46 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:55:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:55:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:55:46 --> Email Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:55:46 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:55:46 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:46 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:55:46 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Controller Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:46 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:55:46 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:55:46 --> Pagination Class Initialized
ERROR - 2014-06-13 03:55:46 --> Severity: Warning  --> Missing argument 1 for Report_controller::ajax_view_fields_by_table() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 200
ERROR - 2014-06-13 03:55:46 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 03:55:46 --> Final output sent to browser
DEBUG - 2014-06-13 03:55:46 --> Total execution time: 0.1500
DEBUG - 2014-06-13 03:55:49 --> Config Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:55:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:55:49 --> URI Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Router Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Output Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Security Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Input Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:55:49 --> Language Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Loader Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:55:49 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:55:49 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Session Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:55:49 --> Session routines successfully run
ERROR - 2014-06-13 03:55:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:55:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:55:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:55:49 --> Email Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:55:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:55:49 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:55:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Model Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Controller Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:55:49 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:55:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:55:49 --> Pagination Class Initialized
ERROR - 2014-06-13 03:55:49 --> Severity: Warning  --> Missing argument 1 for Report_controller::ajax_view_fields_by_table() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 200
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
ERROR - 2014-06-13 03:55:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 215
DEBUG - 2014-06-13 03:55:49 --> Final output sent to browser
DEBUG - 2014-06-13 03:55:49 --> Total execution time: 0.1268
DEBUG - 2014-06-13 03:58:45 --> Config Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:58:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:58:45 --> URI Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Router Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Output Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Security Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Input Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:58:45 --> Language Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Loader Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:58:45 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:58:45 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Session Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:58:45 --> Session routines successfully run
ERROR - 2014-06-13 03:58:45 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:58:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:58:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:58:45 --> Email Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:58:45 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:58:45 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:45 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:58:45 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Controller Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:45 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:58:45 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:58:45 --> Pagination Class Initialized
DEBUG - 2014-06-13 03:58:45 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 03:58:45 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 03:58:45 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 03:58:45 --> Final output sent to browser
DEBUG - 2014-06-13 03:58:45 --> Total execution time: 0.1231
DEBUG - 2014-06-13 03:58:47 --> Config Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:58:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:58:47 --> URI Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Router Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Output Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Security Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Input Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:58:47 --> Language Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Loader Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:58:47 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:58:47 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Session Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:58:47 --> Session routines successfully run
ERROR - 2014-06-13 03:58:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:58:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:58:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:58:47 --> Email Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:58:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:58:47 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:47 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:58:47 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Controller Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:47 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:58:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:58:47 --> Pagination Class Initialized
ERROR - 2014-06-13 03:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 03:58:47 --> Final output sent to browser
DEBUG - 2014-06-13 03:58:47 --> Total execution time: 0.0747
DEBUG - 2014-06-13 03:58:50 --> Config Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:58:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:58:50 --> URI Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Router Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Output Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Security Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Input Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:58:50 --> Language Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Loader Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:58:50 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:58:50 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Session Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:58:50 --> Session routines successfully run
ERROR - 2014-06-13 03:58:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:58:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:58:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:58:50 --> Email Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:58:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:58:50 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:58:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:58:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Controller Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:50 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:58:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:58:50 --> Pagination Class Initialized
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
DEBUG - 2014-06-13 03:58:50 --> Final output sent to browser
DEBUG - 2014-06-13 03:58:50 --> Total execution time: 0.1389
DEBUG - 2014-06-13 03:58:59 --> Config Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Hooks Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 03:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 03:58:59 --> URI Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Router Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Output Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Security Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Input Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 03:58:59 --> Language Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Loader Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 03:58:59 --> Helper loaded: form_helper
DEBUG - 2014-06-13 03:58:59 --> Database Driver Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Session Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Helper loaded: string_helper
DEBUG - 2014-06-13 03:58:59 --> Session routines successfully run
ERROR - 2014-06-13 03:58:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 03:58:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 03:58:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 03:58:59 --> Email Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 03:58:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 03:58:59 --> Helper loaded: language_helper
DEBUG - 2014-06-13 03:58:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Helper loaded: date_helper
DEBUG - 2014-06-13 03:58:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Model Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Controller Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 03:58:59 --> Form Validation Class Initialized
DEBUG - 2014-06-13 03:58:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 03:58:59 --> Pagination Class Initialized
ERROR - 2014-06-13 03:58:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
ERROR - 2014-06-13 03:58:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 216
DEBUG - 2014-06-13 03:58:59 --> Final output sent to browser
DEBUG - 2014-06-13 03:58:59 --> Total execution time: 0.0714
DEBUG - 2014-06-13 04:04:13 --> Config Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:04:13 --> URI Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Router Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Output Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Security Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Input Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:04:13 --> Language Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Loader Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:04:13 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:04:13 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Session Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:04:13 --> Session routines successfully run
ERROR - 2014-06-13 04:04:13 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:04:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:04:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:04:13 --> Email Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:04:13 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:04:13 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:04:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:13 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:04:13 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Controller Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:13 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:04:13 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:04:13 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:04:13 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:04:13 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:04:13 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:04:13 --> Final output sent to browser
DEBUG - 2014-06-13 04:04:13 --> Total execution time: 0.1134
DEBUG - 2014-06-13 04:04:20 --> Config Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:04:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:04:20 --> URI Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Router Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Output Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Security Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Input Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:04:20 --> Language Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Loader Class Initialized
DEBUG - 2014-06-13 04:04:20 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:04:20 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:04:20 --> Database Driver Class Initialized
ERROR - 2014-06-13 04:04:20 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 04:04:21 --> Session Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:04:21 --> Session routines successfully run
ERROR - 2014-06-13 04:04:21 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:04:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:04:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:04:21 --> Email Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:04:21 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:04:21 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:04:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:04:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Controller Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:21 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:04:21 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:04:21 --> Final output sent to browser
DEBUG - 2014-06-13 04:04:21 --> Total execution time: 1.5065
DEBUG - 2014-06-13 04:04:22 --> Config Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:04:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:04:22 --> URI Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Router Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Output Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Security Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Input Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:04:22 --> Language Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Loader Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:04:22 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:04:22 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Session Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:04:22 --> Session routines successfully run
ERROR - 2014-06-13 04:04:22 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:04:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:04:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:04:22 --> Email Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:04:22 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:04:22 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:04:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:22 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:04:22 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Controller Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:22 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:04:22 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:04:22 --> Pagination Class Initialized
ERROR - 2014-06-13 04:04:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 04:04:22 --> Final output sent to browser
DEBUG - 2014-06-13 04:04:22 --> Total execution time: 0.1025
DEBUG - 2014-06-13 04:04:24 --> Config Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:04:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:04:24 --> URI Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Router Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Output Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Security Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Input Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:04:24 --> Language Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Loader Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:04:24 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:04:24 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Session Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:04:24 --> Session routines successfully run
ERROR - 2014-06-13 04:04:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:04:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:04:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:04:24 --> Email Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:04:24 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:04:24 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:04:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:04:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Controller Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:04:24 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:04:24 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:04:24 --> Final output sent to browser
DEBUG - 2014-06-13 04:04:24 --> Total execution time: 0.0896
DEBUG - 2014-06-13 04:06:13 --> Config Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:06:13 --> URI Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Router Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Output Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Security Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Input Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:06:13 --> Language Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Loader Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:06:13 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:06:13 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Session Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:06:13 --> Session routines successfully run
ERROR - 2014-06-13 04:06:13 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:06:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:06:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:06:13 --> Email Class Initialized
DEBUG - 2014-06-13 04:06:13 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:06:13 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:06:14 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:06:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:14 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:06:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:14 --> Controller Class Initialized
DEBUG - 2014-06-13 04:06:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:14 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:06:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:06:14 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:06:14 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:06:14 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:06:14 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:06:14 --> Final output sent to browser
DEBUG - 2014-06-13 04:06:14 --> Total execution time: 0.1319
DEBUG - 2014-06-13 04:06:16 --> Config Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:06:16 --> URI Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Router Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Output Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Security Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Input Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:06:16 --> Language Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Loader Class Initialized
DEBUG - 2014-06-13 04:06:16 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:06:16 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:06:16 --> Database Driver Class Initialized
ERROR - 2014-06-13 04:06:16 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 04:06:17 --> Session Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:06:17 --> Session routines successfully run
ERROR - 2014-06-13 04:06:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:06:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:06:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:06:17 --> Email Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:06:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:06:17 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:06:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Controller Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:17 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:06:17 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:06:17 --> Final output sent to browser
DEBUG - 2014-06-13 04:06:17 --> Total execution time: 1.3000
DEBUG - 2014-06-13 04:06:19 --> Config Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:06:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:06:19 --> URI Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Router Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Output Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Security Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Input Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:06:19 --> Language Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Loader Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:06:19 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:06:19 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Session Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:06:19 --> Session routines successfully run
ERROR - 2014-06-13 04:06:19 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:06:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:06:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:06:19 --> Email Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:06:19 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:06:19 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:19 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:06:19 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Controller Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:19 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:06:19 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:06:19 --> Pagination Class Initialized
ERROR - 2014-06-13 04:06:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 04:06:19 --> Final output sent to browser
DEBUG - 2014-06-13 04:06:19 --> Total execution time: 0.0799
DEBUG - 2014-06-13 04:06:21 --> Config Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:06:21 --> URI Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Router Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Output Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Security Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Input Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:06:21 --> Language Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Loader Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:06:21 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:06:21 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Session Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:06:21 --> Session routines successfully run
ERROR - 2014-06-13 04:06:21 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:06:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:06:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:06:21 --> Email Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:06:21 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:06:21 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:06:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Model Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Controller Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:06:21 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:06:21 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:06:21 --> Final output sent to browser
DEBUG - 2014-06-13 04:06:21 --> Total execution time: 0.0771
DEBUG - 2014-06-13 04:07:46 --> Config Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:07:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:07:46 --> URI Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Router Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Output Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Security Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Input Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:07:46 --> Language Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Loader Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:07:46 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:07:46 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Session Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:07:46 --> Session routines successfully run
ERROR - 2014-06-13 04:07:46 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:07:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:07:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:07:46 --> Email Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:07:46 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:07:46 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:07:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:07:46 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:07:46 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Controller Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:07:46 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:07:46 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:07:46 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:07:46 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:07:46 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:07:46 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:07:46 --> Final output sent to browser
DEBUG - 2014-06-13 04:07:46 --> Total execution time: 0.0757
DEBUG - 2014-06-13 04:07:50 --> Config Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:07:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:07:50 --> URI Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Router Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Output Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Security Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Input Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:07:50 --> Language Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Loader Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:07:50 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Session Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:07:50 --> Session routines successfully run
ERROR - 2014-06-13 04:07:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:07:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:07:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:07:50 --> Email Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:07:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:07:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Controller Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:07:50 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:07:50 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Final output sent to browser
DEBUG - 2014-06-13 04:07:50 --> Total execution time: 0.0738
DEBUG - 2014-06-13 04:07:50 --> Config Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:07:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:07:50 --> URI Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Router Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Output Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Security Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Input Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:07:50 --> Language Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Loader Class Initialized
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:07:50 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:07:50 --> Database Driver Class Initialized
ERROR - 2014-06-13 04:07:50 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 04:07:51 --> Session Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:07:51 --> Session routines successfully run
ERROR - 2014-06-13 04:07:51 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:07:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:07:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:07:51 --> Email Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:07:51 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:07:51 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Controller Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:07:51 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:07:51 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:07:51 --> Final output sent to browser
DEBUG - 2014-06-13 04:07:51 --> Total execution time: 1.2876
DEBUG - 2014-06-13 04:11:41 --> Config Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:11:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:11:41 --> URI Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Router Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Output Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Security Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Input Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:11:41 --> Language Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Loader Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:11:41 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:11:41 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Session Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:11:41 --> Session routines successfully run
ERROR - 2014-06-13 04:11:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:11:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:11:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:11:41 --> Email Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:11:41 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:11:41 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:41 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:11:41 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Controller Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:41 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:11:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:11:41 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:11:41 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:11:41 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:11:41 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:11:41 --> Final output sent to browser
DEBUG - 2014-06-13 04:11:41 --> Total execution time: 0.1699
DEBUG - 2014-06-13 04:11:49 --> Config Class Initialized
DEBUG - 2014-06-13 04:11:49 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:11:49 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:11:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:11:49 --> URI Class Initialized
DEBUG - 2014-06-13 04:11:49 --> Router Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Output Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Security Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Input Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:11:50 --> Language Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Config Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:11:50 --> Loader Class Initialized
DEBUG - 2014-06-13 04:11:50 --> URI Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:11:50 --> Router Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:11:50 --> Output Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Security Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Input Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:11:50 --> Language Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Loader Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Session Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:11:50 --> Session routines successfully run
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: form_helper
ERROR - 2014-06-13 04:11:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:11:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:11:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:11:50 --> Email Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:11:50 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:11:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Session Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:11:50 --> Session routines successfully run
ERROR - 2014-06-13 04:11:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
ERROR - 2014-06-13 04:11:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:11:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Controller Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:50 --> Email Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:11:50 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:11:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Controller Class Initialized
DEBUG - 2014-06-13 04:11:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:50 --> Form Validation Class Initialized
ERROR - 2014-06-13 04:11:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 04:11:50 --> Final output sent to browser
DEBUG - 2014-06-13 04:11:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:11:50 --> Total execution time: 0.1042
DEBUG - 2014-06-13 04:11:50 --> Pagination Class Initialized
ERROR - 2014-06-13 04:11:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 04:11:50 --> Final output sent to browser
DEBUG - 2014-06-13 04:11:50 --> Total execution time: 0.0803
DEBUG - 2014-06-13 04:11:52 --> Config Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:11:52 --> URI Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Router Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Output Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Security Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Input Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:11:52 --> Language Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Loader Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:11:52 --> Config Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:11:52 --> URI Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Router Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Session Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:11:52 --> Output Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Session routines successfully run
DEBUG - 2014-06-13 04:11:52 --> Security Class Initialized
ERROR - 2014-06-13 04:11:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:11:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:11:52 --> Input Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:11:52 --> Language Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Email Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:11:52 --> Loader Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Controller Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:52 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Session Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:11:52 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Session routines successfully run
DEBUG - 2014-06-13 04:11:52 --> Final output sent to browser
DEBUG - 2014-06-13 04:11:52 --> Total execution time: 0.0808
ERROR - 2014-06-13 04:11:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:11:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:11:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:11:52 --> Email Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Controller Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:11:52 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:11:52 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:11:52 --> Final output sent to browser
DEBUG - 2014-06-13 04:11:52 --> Total execution time: 0.0822
DEBUG - 2014-06-13 04:13:06 --> Config Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:13:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:13:06 --> URI Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Router Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Output Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Security Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Input Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:13:06 --> Language Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Loader Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:13:06 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Session Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:13:06 --> Session routines successfully run
DEBUG - 2014-06-13 04:13:06 --> Config Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Hooks Class Initialized
ERROR - 2014-06-13 04:13:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:13:06 --> Utf8 Class Initialized
ERROR - 2014-06-13 04:13:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:13:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:13:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:13:06 --> URI Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Router Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Email Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Output Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:13:06 --> Security Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:13:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Input Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:13:06 --> Language Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Loader Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Controller Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:06 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:13:06 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Database Driver Class Initialized
ERROR - 2014-06-13 04:13:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 04:13:06 --> Final output sent to browser
DEBUG - 2014-06-13 04:13:06 --> Total execution time: 0.0800
DEBUG - 2014-06-13 04:13:06 --> Session Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:13:06 --> Session routines successfully run
ERROR - 2014-06-13 04:13:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:13:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:13:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:13:06 --> Email Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:13:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Controller Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:06 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:13:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:13:06 --> Pagination Class Initialized
ERROR - 2014-06-13 04:13:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 209
DEBUG - 2014-06-13 04:13:06 --> Final output sent to browser
DEBUG - 2014-06-13 04:13:06 --> Total execution time: 0.0802
DEBUG - 2014-06-13 04:13:09 --> Config Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:13:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:13:09 --> URI Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Config Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:13:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:13:09 --> URI Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Router Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Output Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Security Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Input Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:13:09 --> Language Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Loader Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Router Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:13:09 --> Output Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Security Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Input Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:13:09 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Language Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Session Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Loader Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:13:09 --> Session routines successfully run
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: form_helper
ERROR - 2014-06-13 04:13:09 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:13:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:13:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:13:09 --> Email Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:13:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Session Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Session routines successfully run
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: date_helper
ERROR - 2014-06-13 04:13:09 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
ERROR - 2014-06-13 04:13:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:13:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Controller Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:09 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Email Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:13:09 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:13:09 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Final output sent to browser
DEBUG - 2014-06-13 04:13:09 --> Total execution time: 0.0818
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Model Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Controller Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:13:09 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:13:09 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:13:09 --> Final output sent to browser
DEBUG - 2014-06-13 04:13:09 --> Total execution time: 0.1109
DEBUG - 2014-06-13 04:14:18 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:18 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Output Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:18 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:18 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:14:18 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:18 --> Session routines successfully run
ERROR - 2014-06-13 04:14:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:18 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:18 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:18 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:14:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:18 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:18 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:14:18 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:14:18 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:14:18 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:14:18 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:18 --> Total execution time: 0.0766
DEBUG - 2014-06-13 04:14:24 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:24 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:24 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:24 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Output Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:24 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Output Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:24 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:14:24 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:24 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:24 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:24 --> Session routines successfully run
ERROR - 2014-06-13 04:14:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:24 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:24 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:24 --> Session routines successfully run
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
ERROR - 2014-06-13 04:14:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:14:24 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:24 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:24 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Helper loaded: date_helper
ERROR - 2014-06-13 04:14:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:14:24 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:24 --> Total execution time: 0.0793
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:24 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:24 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:24 --> Pagination Class Initialized
ERROR - 2014-06-13 04:14:24 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:14:24 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:24 --> Total execution time: 0.0969
DEBUG - 2014-06-13 04:14:26 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:26 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:26 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Output Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:26 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:14:26 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:26 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:26 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:26 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:26 --> Session routines successfully run
DEBUG - 2014-06-13 04:14:26 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Output Class Initialized
ERROR - 2014-06-13 04:14:26 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:26 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:26 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:26 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:26 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:26 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:26 --> Session routines successfully run
ERROR - 2014-06-13 04:14:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:14:26 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:26 --> Total execution time: 0.0813
ERROR - 2014-06-13 04:14:26 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:26 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:26 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:26 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:26 --> Pagination Class Initialized
ERROR - 2014-06-13 04:14:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:14:26 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:26 --> Total execution time: 0.0750
DEBUG - 2014-06-13 04:14:28 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:28 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Output Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:28 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:28 --> Config Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:14:28 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:14:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:14:28 --> URI Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Router Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Output Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Security Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Input Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:14:28 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Language Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:28 --> Loader Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Session routines successfully run
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: form_helper
ERROR - 2014-06-13 04:14:28 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:28 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Session Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:14:28 --> Session routines successfully run
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
ERROR - 2014-06-13 04:14:28 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:14:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:14:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:28 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Email Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:14:28 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:14:28 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:28 --> Total execution time: 0.0814
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Model Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Controller Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:14:28 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:14:28 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:14:28 --> Final output sent to browser
DEBUG - 2014-06-13 04:14:28 --> Total execution time: 0.0763
DEBUG - 2014-06-13 04:16:49 --> Config Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:16:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:16:49 --> URI Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Router Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Output Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Security Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Input Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:16:49 --> Language Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Loader Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:16:49 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:16:49 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Session Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:16:49 --> Session routines successfully run
ERROR - 2014-06-13 04:16:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:16:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:16:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:16:49 --> Email Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:16:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:16:49 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:16:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:16:49 --> Model Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Model Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:16:49 --> Model Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Model Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Controller Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:16:49 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:16:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:16:49 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:16:49 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:16:49 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:16:49 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:16:49 --> Final output sent to browser
DEBUG - 2014-06-13 04:16:49 --> Total execution time: 0.0738
DEBUG - 2014-06-13 04:17:27 --> Config Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:17:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:17:27 --> URI Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Router Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Output Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Security Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Input Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:17:27 --> Language Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Loader Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:17:27 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:17:27 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Session Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:17:27 --> Session routines successfully run
ERROR - 2014-06-13 04:17:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:17:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:17:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:17:27 --> Email Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:17:27 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:17:27 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:17:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Controller Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:27 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:17:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:17:27 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:17:28 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:17:28 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:17:28 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:17:28 --> Final output sent to browser
DEBUG - 2014-06-13 04:17:28 --> Total execution time: 0.1234
DEBUG - 2014-06-13 04:17:30 --> Config Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:17:30 --> URI Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Router Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Output Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Security Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Config Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Input Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:17:30 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:17:30 --> Language Class Initialized
DEBUG - 2014-06-13 04:17:30 --> URI Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Router Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Loader Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Output Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:17:30 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Session Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:17:30 --> Session routines successfully run
ERROR - 2014-06-13 04:17:30 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:17:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:17:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:17:30 --> Email Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Controller Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:30 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:17:30 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Security Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Final output sent to browser
DEBUG - 2014-06-13 04:17:30 --> Input Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Total execution time: 0.0683
DEBUG - 2014-06-13 04:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:17:30 --> Language Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Loader Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:17:30 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Session Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:17:30 --> Session routines successfully run
ERROR - 2014-06-13 04:17:30 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:17:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:17:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:17:30 --> Email Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Controller Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:30 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:17:30 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:17:30 --> Pagination Class Initialized
ERROR - 2014-06-13 04:17:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
DEBUG - 2014-06-13 04:17:30 --> Final output sent to browser
DEBUG - 2014-06-13 04:17:30 --> Total execution time: 0.1913
DEBUG - 2014-06-13 04:17:32 --> Config Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:17:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:17:32 --> URI Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Config Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:17:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:17:32 --> URI Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Router Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Output Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Security Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Input Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:17:32 --> Language Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Loader Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:17:32 --> Router Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:17:32 --> Output Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Security Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Input Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:17:32 --> Language Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Loader Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Session Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:17:32 --> Session routines successfully run
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: url_helper
ERROR - 2014-06-13 04:17:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:17:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:17:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:17:32 --> Email Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:17:32 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Controller Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:32 --> Session Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:17:32 --> Session routines successfully run
DEBUG - 2014-06-13 04:17:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:17:32 --> Pagination Class Initialized
ERROR - 2014-06-13 04:17:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:17:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
DEBUG - 2014-06-13 04:17:32 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
DEBUG - 2014-06-13 04:17:32 --> Email Class Initialized
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
DEBUG - 2014-06-13 04:17:32 --> Language file loaded: language/spanish/ion_auth_lang.php
ERROR - 2014-06-13 04:17:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
DEBUG - 2014-06-13 04:17:32 --> Final output sent to browser
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:17:32 --> Total execution time: 0.0793
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Model Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Controller Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:17:32 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:17:32 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:17:32 --> Final output sent to browser
DEBUG - 2014-06-13 04:17:32 --> Total execution time: 0.1188
DEBUG - 2014-06-13 04:18:24 --> Config Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:18:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:18:24 --> URI Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Router Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Output Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Security Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Input Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:18:24 --> Language Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Loader Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:18:24 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:18:24 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Session Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:18:24 --> Session routines successfully run
ERROR - 2014-06-13 04:18:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:18:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:18:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:18:24 --> Email Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:18:24 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:18:24 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:18:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Controller Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:24 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:18:24 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:18:24 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:18:24 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:18:24 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:18:24 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:18:24 --> Final output sent to browser
DEBUG - 2014-06-13 04:18:24 --> Total execution time: 0.0780
DEBUG - 2014-06-13 04:18:30 --> Config Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:18:30 --> URI Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Router Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Output Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Security Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Input Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:18:30 --> Language Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Loader Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:18:30 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Session Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:18:30 --> Session routines successfully run
ERROR - 2014-06-13 04:18:30 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:18:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:18:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:18:30 --> Email Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:18:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Controller Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:30 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:18:30 --> Pagination Class Initialized
ERROR - 2014-06-13 04:18:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 224
DEBUG - 2014-06-13 04:18:30 --> Final output sent to browser
DEBUG - 2014-06-13 04:18:30 --> Total execution time: 0.0728
DEBUG - 2014-06-13 04:18:30 --> Config Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:18:30 --> URI Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Router Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Output Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Security Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Input Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:18:30 --> Language Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Loader Class Initialized
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:18:30 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:18:30 --> Database Driver Class Initialized
ERROR - 2014-06-13 04:18:30 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 04:18:31 --> Session Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:18:31 --> Session routines successfully run
ERROR - 2014-06-13 04:18:31 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:18:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:18:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:18:31 --> Email Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:18:31 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:18:31 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Controller Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:31 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:18:31 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:18:31 --> Pagination Class Initialized
ERROR - 2014-06-13 04:18:31 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:18:31 --> Final output sent to browser
DEBUG - 2014-06-13 04:18:31 --> Total execution time: 1.1994
DEBUG - 2014-06-13 04:18:34 --> Config Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:18:34 --> URI Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Router Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Output Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Security Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Config Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Input Class Initialized
DEBUG - 2014-06-13 04:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:18:34 --> Language Class Initialized
DEBUG - 2014-06-13 04:18:34 --> URI Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Router Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Loader Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Output Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:18:34 --> Security Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:18:34 --> Input Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:18:34 --> Language Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Session Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Loader Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:18:34 --> Session routines successfully run
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: url_helper
ERROR - 2014-06-13 04:18:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:18:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:18:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:18:34 --> Email Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:18:34 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:34 --> Session Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:18:34 --> Session routines successfully run
ERROR - 2014-06-13 04:18:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:18:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:18:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Email Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:18:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Controller Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:18:34 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Final output sent to browser
DEBUG - 2014-06-13 04:18:34 --> Total execution time: 0.0896
DEBUG - 2014-06-13 04:18:34 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Controller Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:18:34 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:18:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:18:34 --> Pagination Class Initialized
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
ERROR - 2014-06-13 04:18:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 226
DEBUG - 2014-06-13 04:18:34 --> Final output sent to browser
DEBUG - 2014-06-13 04:18:34 --> Total execution time: 0.1044
DEBUG - 2014-06-13 04:22:06 --> Config Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:22:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:22:06 --> URI Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Router Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Output Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Security Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Input Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:22:06 --> Language Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Loader Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:22:06 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:22:06 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Session Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:22:06 --> Session routines successfully run
ERROR - 2014-06-13 04:22:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:22:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:22:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:22:06 --> Email Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:22:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:22:06 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:22:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Controller Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:06 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:22:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:22:06 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:22:06 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:22:06 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:22:06 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:22:06 --> Final output sent to browser
DEBUG - 2014-06-13 04:22:06 --> Total execution time: 0.1066
DEBUG - 2014-06-13 04:22:14 --> Config Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:22:14 --> URI Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Router Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Config Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Output Class Initialized
DEBUG - 2014-06-13 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:22:14 --> URI Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Security Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Router Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Input Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:22:14 --> Language Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Output Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Security Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Input Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:22:14 --> Language Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Loader Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:22:14 --> Loader Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:22:14 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Session Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:22:14 --> Session routines successfully run
ERROR - 2014-06-13 04:22:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:22:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:22:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:22:14 --> Email Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Session Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Controller Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:22:14 --> Session routines successfully run
DEBUG - 2014-06-13 04:22:14 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-06-13 04:22:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:22:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:22:14 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-06-13 04:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:22:14 --> Final output sent to browser
DEBUG - 2014-06-13 04:22:14 --> Total execution time: 0.0821
DEBUG - 2014-06-13 04:22:14 --> Email Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Controller Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:14 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:22:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:22:14 --> Pagination Class Initialized
ERROR - 2014-06-13 04:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 224
DEBUG - 2014-06-13 04:22:14 --> Final output sent to browser
DEBUG - 2014-06-13 04:22:14 --> Total execution time: 0.1023
DEBUG - 2014-06-13 04:22:16 --> Config Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:22:16 --> URI Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Router Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Output Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Security Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Input Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:22:16 --> Language Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Config Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:22:16 --> URI Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Router Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Loader Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Output Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Security Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:22:16 --> Input Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:22:16 --> Language Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:22:16 --> Loader Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:22:16 --> Session Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:22:16 --> Session routines successfully run
ERROR - 2014-06-13 04:22:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:22:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:22:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:22:16 --> Email Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:22:16 --> Session Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:22:16 --> Session routines successfully run
ERROR - 2014-06-13 04:22:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:22:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Controller Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:16 --> Email Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:22:16 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Controller Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:22:16 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:22:16 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:22:16 --> Final output sent to browser
DEBUG - 2014-06-13 04:22:16 --> Total execution time: 0.0833
DEBUG - 2014-06-13 04:23:25 --> Config Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:23:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:23:25 --> URI Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Router Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Output Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Security Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Input Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:23:25 --> Language Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Loader Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:23:25 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:23:25 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Session Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:23:25 --> Session routines successfully run
ERROR - 2014-06-13 04:23:25 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:23:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:23:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:23:25 --> Email Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:23:25 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:23:25 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:23:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:25 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:23:25 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Controller Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:25 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:23:25 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:23:25 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:23:25 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:23:25 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:23:25 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:23:25 --> Final output sent to browser
DEBUG - 2014-06-13 04:23:25 --> Total execution time: 0.1222
DEBUG - 2014-06-13 04:23:29 --> Config Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:23:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:23:29 --> URI Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Router Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Output Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Security Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Input Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:23:29 --> Language Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Loader Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:23:29 --> Config Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:23:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:23:29 --> URI Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Router Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Session Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Output Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:23:29 --> Session routines successfully run
DEBUG - 2014-06-13 04:23:29 --> Security Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Input Class Initialized
ERROR - 2014-06-13 04:23:29 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:23:29 --> Global POST and COOKIE data sanitized
ERROR - 2014-06-13 04:23:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:23:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:23:29 --> Language Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Loader Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Email Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:23:29 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Session Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:23:29 --> Session routines successfully run
ERROR - 2014-06-13 04:23:29 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:23:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:23:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:23:29 --> Email Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Controller Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:23:29 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Controller Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:29 --> Final output sent to browser
DEBUG - 2014-06-13 04:23:29 --> Total execution time: 0.0938
DEBUG - 2014-06-13 04:23:29 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:23:29 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:23:29 --> Final output sent to browser
DEBUG - 2014-06-13 04:23:29 --> Total execution time: 0.0737
DEBUG - 2014-06-13 04:23:31 --> Config Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:23:31 --> URI Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Router Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Output Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Security Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Input Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:23:31 --> Language Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Loader Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:23:31 --> Config Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:23:31 --> URI Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Router Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Output Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Session Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Security Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:23:31 --> Session routines successfully run
DEBUG - 2014-06-13 04:23:31 --> Input Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:23:31 --> Language Class Initialized
ERROR - 2014-06-13 04:23:31 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:23:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:23:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:23:31 --> Loader Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:23:31 --> Email Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Session Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:23:31 --> Session routines successfully run
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
ERROR - 2014-06-13 04:23:31 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:23:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:23:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Controller Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:31 --> Email Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:23:31 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:31 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Final output sent to browser
DEBUG - 2014-06-13 04:23:31 --> Total execution time: 0.0922
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Controller Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:23:31 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:23:31 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:23:31 --> Final output sent to browser
DEBUG - 2014-06-13 04:23:31 --> Total execution time: 0.0848
DEBUG - 2014-06-13 04:24:29 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:29 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:29 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:29 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:24:29 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:29 --> Session routines successfully run
ERROR - 2014-06-13 04:24:29 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:29 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:29 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:29 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:29 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:29 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:29 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:29 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:24:29 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:24:29 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:24:29 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:29 --> Total execution time: 0.0931
DEBUG - 2014-06-13 04:24:33 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:33 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:33 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:33 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:33 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:33 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:33 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:24:33 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:33 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:33 --> Session routines successfully run
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: form_helper
ERROR - 2014-06-13 04:24:33 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:33 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:33 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:33 --> Session routines successfully run
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
ERROR - 2014-06-13 04:24:33 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:33 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:33 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:33 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:33 --> Total execution time: 0.1085
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:33 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:33 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:33 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:33 --> Total execution time: 0.1190
DEBUG - 2014-06-13 04:24:34 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:34 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:34 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:24:34 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:34 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:34 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:34 --> Session routines successfully run
DEBUG - 2014-06-13 04:24:34 --> Router Class Initialized
ERROR - 2014-06-13 04:24:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:34 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:34 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:34 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:24:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:34 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:34 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:34 --> Session routines successfully run
DEBUG - 2014-06-13 04:24:35 --> Pagination Class Initialized
ERROR - 2014-06-13 04:24:35 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:35 --> Final output sent to browser
ERROR - 2014-06-13 04:24:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:35 --> Total execution time: 0.0806
DEBUG - 2014-06-13 04:24:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:35 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:35 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:35 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:35 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:35 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:35 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:35 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:35 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:35 --> Total execution time: 0.1021
DEBUG - 2014-06-13 04:24:45 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:45 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:45 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:45 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:24:45 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:45 --> Session routines successfully run
ERROR - 2014-06-13 04:24:45 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:45 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:45 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:45 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:45 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:45 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:45 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:45 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:45 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:45 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:24:45 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:24:45 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:24:45 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:45 --> Total execution time: 0.0848
DEBUG - 2014-06-13 04:24:47 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:47 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:47 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:24:47 --> Config Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:24:47 --> URI Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Router Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Output Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Security Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Input Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:24:47 --> Language Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:47 --> Loader Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Session routines successfully run
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: form_helper
ERROR - 2014-06-13 04:24:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:47 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:47 --> Session Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:24:47 --> Session routines successfully run
ERROR - 2014-06-13 04:24:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:24:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:47 --> Email Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:24:47 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:24:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:47 --> Total execution time: 0.0878
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Model Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Controller Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:24:47 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:24:47 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:24:47 --> Final output sent to browser
DEBUG - 2014-06-13 04:24:47 --> Total execution time: 0.0764
DEBUG - 2014-06-13 04:25:12 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:12 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:12 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:12 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:12 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:12 --> Session routines successfully run
ERROR - 2014-06-13 04:25:12 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:25:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:12 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:12 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:12 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:12 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:12 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:12 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:12 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:12 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:25:12 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:25:12 --> File loaded: application/views/includes/menu_upper.php
ERROR - 2014-06-13 04:25:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\system\helpers\form_helper.php 453
DEBUG - 2014-06-13 04:25:12 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:25:12 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:12 --> Total execution time: 0.0887
DEBUG - 2014-06-13 04:25:18 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:18 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:18 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:18 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:18 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:18 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:18 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:18 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:18 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:18 --> Session routines successfully run
ERROR - 2014-06-13 04:25:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:25:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:18 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:18 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:18 --> Session routines successfully run
DEBUG - 2014-06-13 04:25:18 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:18 --> Pagination Class Initialized
ERROR - 2014-06-13 04:25:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:25:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:18 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:18 --> Total execution time: 0.0845
DEBUG - 2014-06-13 04:25:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:18 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:18 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:18 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:25:18 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:18 --> Total execution time: 0.1112
DEBUG - 2014-06-13 04:25:20 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:20 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:20 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:20 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:20 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:20 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:20 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:20 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:20 --> Session routines successfully run
ERROR - 2014-06-13 04:25:20 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:25:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:20 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:20 --> Session routines successfully run
DEBUG - 2014-06-13 04:25:20 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-13 04:25:20 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
ERROR - 2014-06-13 04:25:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:20 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:20 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:20 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
ERROR - 2014-06-13 04:25:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-13 04:25:20 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:20 --> Total execution time: 0.1183
DEBUG - 2014-06-13 04:25:20 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:20 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:20 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:20 --> Pagination Class Initialized
ERROR - 2014-06-13 04:25:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 224
DEBUG - 2014-06-13 04:25:20 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:20 --> Total execution time: 0.1082
DEBUG - 2014-06-13 04:25:27 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:27 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:27 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:27 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:27 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:27 --> Session routines successfully run
ERROR - 2014-06-13 04:25:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:25:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:27 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:27 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:27 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:27 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:27 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:25:27 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:25:27 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:25:27 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:25:27 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:27 --> Total execution time: 0.0833
DEBUG - 2014-06-13 04:25:31 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:31 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:31 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Loader Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:31 --> Config Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:25:31 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:31 --> URI Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Router Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Output Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Security Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Input Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:31 --> Language Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Session routines successfully run
ERROR - 2014-06-13 04:25:31 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:31 --> Loader Class Initialized
ERROR - 2014-06-13 04:25:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:25:31 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Session Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:25:31 --> Session routines successfully run
ERROR - 2014-06-13 04:25:31 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:25:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:25:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:25:31 --> Email Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Model Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Controller Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:25:31 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:31 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:25:31 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:31 --> Total execution time: 0.0757
DEBUG - 2014-06-13 04:25:31 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:25:31 --> Final output sent to browser
DEBUG - 2014-06-13 04:25:31 --> Total execution time: 0.1080
DEBUG - 2014-06-13 04:28:56 --> Config Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:28:56 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:28:56 --> URI Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Router Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Output Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Security Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Input Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:28:56 --> Language Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Loader Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:28:56 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:28:56 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Session Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:28:56 --> Session routines successfully run
ERROR - 2014-06-13 04:28:56 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:28:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:28:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:28:56 --> Email Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:28:56 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:28:56 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:28:56 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:28:56 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Controller Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:28:56 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:28:56 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:28:56 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:28:56 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:28:56 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:28:56 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:28:56 --> Final output sent to browser
DEBUG - 2014-06-13 04:28:56 --> Total execution time: 0.0755
DEBUG - 2014-06-13 04:28:59 --> Config Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:28:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:28:59 --> URI Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Router Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Output Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Security Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Input Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:28:59 --> Language Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Loader Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:28:59 --> Config Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:28:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:28:59 --> URI Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Router Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Output Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Security Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Input Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:28:59 --> Language Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Loader Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Session Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:28:59 --> Session routines successfully run
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: form_helper
ERROR - 2014-06-13 04:28:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:28:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:28:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:28:59 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Email Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:28:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Controller Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:28:59 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:28:59 --> Session Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:28:59 --> Session routines successfully run
DEBUG - 2014-06-13 04:28:59 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Final output sent to browser
DEBUG - 2014-06-13 04:28:59 --> Total execution time: 0.0997
ERROR - 2014-06-13 04:28:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:28:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:28:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:28:59 --> Email Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:28:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Model Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Controller Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:28:59 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:28:59 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:28:59 --> Final output sent to browser
DEBUG - 2014-06-13 04:28:59 --> Total execution time: 0.1047
DEBUG - 2014-06-13 04:29:11 --> Config Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:29:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:29:11 --> URI Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Router Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Output Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Security Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Input Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:29:11 --> Language Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Loader Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:29:11 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:29:11 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Session Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:29:11 --> Session routines successfully run
ERROR - 2014-06-13 04:29:11 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:29:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:29:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:29:11 --> Email Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:29:11 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:29:11 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:11 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:29:11 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Controller Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:11 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:29:11 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:29:11 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:29:11 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:29:11 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:29:11 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:29:11 --> Final output sent to browser
DEBUG - 2014-06-13 04:29:11 --> Total execution time: 0.0802
DEBUG - 2014-06-13 04:29:15 --> Config Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:29:15 --> URI Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Router Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Output Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Security Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Input Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:29:15 --> Language Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Loader Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:29:15 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Session Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:29:15 --> Session routines successfully run
ERROR - 2014-06-13 04:29:15 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:29:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:29:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:29:15 --> Email Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:29:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:15 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:29:15 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Controller Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:15 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:29:15 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Final output sent to browser
DEBUG - 2014-06-13 04:29:15 --> Total execution time: 0.0805
DEBUG - 2014-06-13 04:29:15 --> Config Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:29:15 --> URI Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Router Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Output Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Security Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Input Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:29:15 --> Language Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Loader Class Initialized
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:29:15 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:29:15 --> Database Driver Class Initialized
ERROR - 2014-06-13 04:29:15 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-13 04:29:16 --> Session Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:29:16 --> Session routines successfully run
ERROR - 2014-06-13 04:29:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:29:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:29:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:29:16 --> Email Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:29:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:29:16 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:29:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Controller Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:16 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:29:16 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:29:16 --> Final output sent to browser
DEBUG - 2014-06-13 04:29:16 --> Total execution time: 1.3383
DEBUG - 2014-06-13 04:29:17 --> Config Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:29:17 --> URI Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Router Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Config Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:29:17 --> Output Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Security Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Input Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:29:17 --> URI Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Language Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Loader Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Router Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:29:17 --> Output Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Security Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:29:17 --> Input Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:29:17 --> Language Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Loader Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:29:17 --> Session Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:29:17 --> Session routines successfully run
ERROR - 2014-06-13 04:29:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:29:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:29:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:29:17 --> Email Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Session Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Controller Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:29:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:17 --> Session routines successfully run
DEBUG - 2014-06-13 04:29:17 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:29:17 --> Pagination Class Initialized
ERROR - 2014-06-13 04:29:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:29:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:29:17 --> Final output sent to browser
DEBUG - 2014-06-13 04:29:17 --> Total execution time: 0.0696
DEBUG - 2014-06-13 04:29:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:29:17 --> Email Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Controller Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:17 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:29:17 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:29:17 --> Final output sent to browser
DEBUG - 2014-06-13 04:29:17 --> Total execution time: 0.1043
DEBUG - 2014-06-13 04:29:52 --> Config Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Hooks Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Utf8 Class Initialized
DEBUG - 2014-06-13 04:29:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-13 04:29:52 --> URI Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Router Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Output Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Security Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Input Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-13 04:29:52 --> Language Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Loader Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Helper loaded: url_helper
DEBUG - 2014-06-13 04:29:52 --> Helper loaded: form_helper
DEBUG - 2014-06-13 04:29:52 --> Database Driver Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Session Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Helper loaded: string_helper
DEBUG - 2014-06-13 04:29:52 --> Session routines successfully run
ERROR - 2014-06-13 04:29:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-13 04:29:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-13 04:29:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-13 04:29:52 --> Email Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-13 04:29:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-13 04:29:52 --> Helper loaded: language_helper
DEBUG - 2014-06-13 04:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Helper loaded: date_helper
DEBUG - 2014-06-13 04:29:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Model Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Controller Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-13 04:29:52 --> Form Validation Class Initialized
DEBUG - 2014-06-13 04:29:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-13 04:29:52 --> Pagination Class Initialized
DEBUG - 2014-06-13 04:29:52 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-13 04:29:52 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-13 04:29:52 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-13 04:29:52 --> Final output sent to browser
DEBUG - 2014-06-13 04:29:52 --> Total execution time: 0.0807
DEBUG - 2014-06-13 18:52:31 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-13 18:52:31 --> Final output sent to browser
DEBUG - 2014-06-13 18:52:31 --> Total execution time: 0.3418
DEBUG - 2014-06-13 19:45:01 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-13 19:45:01 --> Final output sent to browser
DEBUG - 2014-06-13 19:45:01 --> Total execution time: 0.1269
DEBUG - 2014-06-13 20:48:29 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-13 20:48:29 --> Final output sent to browser
DEBUG - 2014-06-13 20:48:29 --> Total execution time: 0.0947
DEBUG - 2014-06-13 21:25:21 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-13 21:25:21 --> Final output sent to browser
DEBUG - 2014-06-13 21:25:21 --> Total execution time: 0.1006
DEBUG - 2014-06-13 21:30:30 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-13 21:30:30 --> Final output sent to browser
DEBUG - 2014-06-13 21:30:30 --> Total execution time: 0.0968
DEBUG - 2014-06-13 21:41:12 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-13 21:41:12 --> Final output sent to browser
DEBUG - 2014-06-13 21:41:12 --> Total execution time: 0.1101
