<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-14 01:39:34 --> Config Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:39:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:39:34 --> URI Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Router Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Output Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Security Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Input Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:39:34 --> Language Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Loader Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:39:34 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:39:34 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Session Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:39:34 --> Session routines successfully run
ERROR - 2014-07-14 01:39:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:39:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:39:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:39:34 --> Email Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:39:34 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:39:34 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:39:34 --> Model Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Model Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:39:34 --> Model Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Model Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Controller Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:39:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:39:34 --> Pagination Class Initialized
ERROR - 2014-07-14 01:39:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:39:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:39:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:39:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-14 01:39:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-14 01:39:34 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-14 01:39:34 --> Final output sent to browser
DEBUG - 2014-07-14 01:39:34 --> Total execution time: 0.1973
DEBUG - 2014-07-14 01:44:17 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:17 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:17 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:17 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:17 --> Session routines successfully run
ERROR - 2014-07-14 01:44:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:17 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:17 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:17 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:17 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:17 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:17 --> Pagination Class Initialized
ERROR - 2014-07-14 01:44:17 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:17 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-14 01:44:17 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-14 01:44:17 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-14 01:44:17 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-14 01:44:17 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:17 --> Total execution time: 0.1746
DEBUG - 2014-07-14 01:44:18 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:18 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:18 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:18 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:18 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:18 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:18 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:18 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Global POST and COOKIE data sanitized
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Input Class Initialized
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:18 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:18 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:18 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:18 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:18 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:18 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:18 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Global POST and COOKIE data sanitized
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Language Class Initialized
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:18 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:18 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:18 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:18 --> Total execution time: 0.1291
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:18 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Form Validation Class Initialized
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Pagination Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:18 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:18 --> Pagination Class Initialized
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:19 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:19 --> Total execution time: 0.1917
DEBUG - 2014-07-14 01:44:19 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:19 --> Total execution time: 0.1871
DEBUG - 2014-07-14 01:44:19 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:19 --> Total execution time: 0.2275
DEBUG - 2014-07-14 01:44:26 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:26 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:26 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:26 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:26 --> Session routines successfully run
ERROR - 2014-07-14 01:44:26 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:26 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:26 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:26 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:26 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:26 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:26 --> Pagination Class Initialized
ERROR - 2014-07-14 01:44:26 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:26 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:26 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-14 01:44:26 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-14 01:44:26 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-14 01:44:26 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-14 01:44:26 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:26 --> Total execution time: 0.1040
DEBUG - 2014-07-14 01:44:27 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:27 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:27 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:27 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:27 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:27 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:27 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:27 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:27 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:27 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:27 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language Class Initialized
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:27 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:27 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:27 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:27 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:27 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:27 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:27 --> Session routines successfully run
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:27 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:27 --> Session routines successfully run
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: date_helper
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: cookie_helper
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:27 --> Total execution time: 0.1345
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Pagination Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Pagination Class Initialized
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Form Validation Class Initialized
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Pagination Class Initialized
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:27 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:27 --> Total execution time: 0.1092
DEBUG - 2014-07-14 01:44:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:27 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:27 --> Total execution time: 0.1320
DEBUG - 2014-07-14 01:44:27 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:27 --> Total execution time: 0.1578
DEBUG - 2014-07-14 01:44:32 --> Config Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Hooks Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Utf8 Class Initialized
DEBUG - 2014-07-14 01:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 01:44:32 --> URI Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Router Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Output Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Security Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Input Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 01:44:32 --> Language Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Loader Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Helper loaded: url_helper
DEBUG - 2014-07-14 01:44:32 --> Helper loaded: form_helper
DEBUG - 2014-07-14 01:44:32 --> Database Driver Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Session Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Helper loaded: string_helper
DEBUG - 2014-07-14 01:44:32 --> Session routines successfully run
ERROR - 2014-07-14 01:44:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-14 01:44:32 --> Email Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-14 01:44:32 --> Helper loaded: cookie_helper
DEBUG - 2014-07-14 01:44:32 --> Helper loaded: language_helper
DEBUG - 2014-07-14 01:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:32 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Helper loaded: date_helper
DEBUG - 2014-07-14 01:44:32 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Model Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Controller Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-14 01:44:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 01:44:32 --> Pagination Class Initialized
ERROR - 2014-07-14 01:44:32 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-14 01:44:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-14 01:44:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-14 01:44:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-14 01:44:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-14 01:44:32 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-14 01:44:32 --> Final output sent to browser
DEBUG - 2014-07-14 01:44:32 --> Total execution time: 0.1301
