<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-12 03:07:50 --> Config Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:07:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:07:50 --> URI Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Router Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Output Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Security Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Input Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:07:50 --> Language Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Loader Class Initialized
DEBUG - 2014-06-12 03:07:50 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:07:50 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:07:50 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:07:50 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:07:51 --> Session Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:07:51 --> A session cookie was not found.
DEBUG - 2014-06-12 03:07:51 --> Session routines successfully run
ERROR - 2014-06-12 03:07:51 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:07:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:07:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:07:51 --> Email Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Controller Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:51 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:07:51 --> Config Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:07:51 --> URI Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Router Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Output Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Security Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Input Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:07:51 --> Language Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Loader Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:07:51 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Session Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:07:51 --> Session routines successfully run
ERROR - 2014-06-12 03:07:51 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:07:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:07:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:07:51 --> Email Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Controller Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:51 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:07:51 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:07:51 --> File loaded: application/views/auth/login.php
DEBUG - 2014-06-12 03:07:51 --> Final output sent to browser
DEBUG - 2014-06-12 03:07:51 --> Total execution time: 0.0707
DEBUG - 2014-06-12 03:07:51 --> Config Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:07:51 --> URI Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Router Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Output Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Security Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Input Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:07:51 --> Language Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Loader Class Initialized
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:07:51 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:07:51 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:07:51 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:07:52 --> Session Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:07:52 --> Session routines successfully run
ERROR - 2014-06-12 03:07:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:07:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:07:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:07:52 --> Email Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:07:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:07:52 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Controller Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:52 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:07:52 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-06-12 03:07:52 --> 404 Page Not Found --> auth/js
DEBUG - 2014-06-12 03:07:55 --> Config Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:07:55 --> URI Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Router Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Output Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Security Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Input Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:07:55 --> Language Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Loader Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:07:55 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:07:55 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Session Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:07:55 --> Session routines successfully run
ERROR - 2014-06-12 03:07:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:07:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:07:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:07:55 --> Email Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:07:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:07:55 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:07:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:07:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Controller Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:55 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:07:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:07:55 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-06-12 03:07:56 --> Config Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:07:56 --> URI Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Router Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Output Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Security Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Input Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:07:56 --> Language Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Loader Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:07:56 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Session Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:07:56 --> Session routines successfully run
ERROR - 2014-06-12 03:07:56 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:07:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:07:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:07:56 --> Email Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Controller Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:56 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:07:56 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:07:56 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:07:56 --> Config Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:07:56 --> URI Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Router Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Output Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Security Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Input Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:07:56 --> Language Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Loader Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:07:56 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Session Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:07:56 --> Session routines successfully run
ERROR - 2014-06-12 03:07:56 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:07:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:07:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:07:56 --> Email Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Model Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Controller Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:07:56 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:07:56 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-06-12 03:07:56 --> 404 Page Not Found --> auth/js
DEBUG - 2014-06-12 03:11:18 --> Config Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:11:18 --> URI Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Router Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Output Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Security Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Input Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:11:18 --> Language Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Loader Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:11:18 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:11:18 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Session Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:11:18 --> Session routines successfully run
ERROR - 2014-06-12 03:11:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:11:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:11:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:11:18 --> Email Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:11:18 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:11:18 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:11:18 --> Model Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Model Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:11:18 --> Model Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Model Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Controller Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:11:18 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:11:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:11:18 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:11:18 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:13:36 --> Config Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:13:36 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:13:36 --> URI Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Router Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Output Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Security Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Input Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:13:36 --> Language Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Loader Class Initialized
DEBUG - 2014-06-12 03:13:36 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:13:37 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:13:37 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:13:37 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:13:38 --> Session Class Initialized
DEBUG - 2014-06-12 03:13:38 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:13:38 --> Session routines successfully run
ERROR - 2014-06-12 03:13:38 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:13:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:13:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:13:38 --> Email Class Initialized
DEBUG - 2014-06-12 03:13:38 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:13:38 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:13:38 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:13:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:13:38 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:38 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:38 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:13:39 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:39 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:39 --> Controller Class Initialized
DEBUG - 2014-06-12 03:13:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:13:39 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:13:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:13:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:13:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:13:55 --> Config Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:13:55 --> URI Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Router Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Output Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Security Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Input Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:13:55 --> Language Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Loader Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:13:55 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:13:55 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Session Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:13:55 --> Session routines successfully run
ERROR - 2014-06-12 03:13:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:13:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:13:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:13:55 --> Email Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:13:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:13:55 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:13:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:13:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:13:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Model Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Controller Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:13:55 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:13:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:13:55 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:13:55 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:14:04 --> Config Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:14:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:14:04 --> URI Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Router Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Output Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Security Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Input Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:14:04 --> Language Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Loader Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:14:04 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:14:04 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Session Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:14:04 --> Session routines successfully run
ERROR - 2014-06-12 03:14:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:14:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:14:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:14:04 --> Email Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:14:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:14:04 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:14:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:14:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:14:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Controller Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:14:04 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:14:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:14:04 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:14:04 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:14:36 --> Config Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:14:36 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:14:36 --> URI Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Router Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Output Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Security Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Input Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:14:36 --> Language Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Loader Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:14:36 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:14:36 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Session Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:14:36 --> Session routines successfully run
ERROR - 2014-06-12 03:14:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:14:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:14:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:14:36 --> Email Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:14:36 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:14:36 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:14:36 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:14:36 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Model Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Controller Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:14:36 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:14:36 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:14:36 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:14:36 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:17:25 --> Config Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:17:25 --> URI Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Router Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Output Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Security Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Input Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:17:25 --> Language Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Loader Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:17:25 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:17:25 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Session Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:17:25 --> Session routines successfully run
ERROR - 2014-06-12 03:17:25 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:17:25 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:17:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:17:25 --> Email Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:17:25 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:17:25 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:17:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:17:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Controller Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:17:25 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:17:25 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:17:25 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:17:25 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:18:34 --> Config Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:18:34 --> URI Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Router Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Output Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Security Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Input Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:18:34 --> Language Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Loader Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:18:34 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:18:34 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Session Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:18:34 --> Session routines successfully run
ERROR - 2014-06-12 03:18:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:18:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:18:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:18:34 --> Email Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:18:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:18:34 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Controller Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:18:34 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:18:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:18:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:18:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:21:07 --> Config Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:21:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:21:07 --> URI Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Router Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Output Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Security Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Input Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:21:07 --> Language Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Loader Class Initialized
DEBUG - 2014-06-12 03:21:07 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:21:08 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:21:08 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:21:08 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:21:09 --> Session Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:21:09 --> Session routines successfully run
ERROR - 2014-06-12 03:21:09 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:21:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:21:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:21:09 --> Email Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:21:09 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:21:09 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:21:09 --> Model Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Model Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:21:09 --> Model Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Model Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Controller Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:21:09 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:21:09 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:21:09 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:21:09 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:23:06 --> Config Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:23:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:23:06 --> URI Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Router Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Output Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Security Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Input Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:23:06 --> Language Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Loader Class Initialized
DEBUG - 2014-06-12 03:23:06 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:23:06 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:23:06 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:23:06 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:23:07 --> Session Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:23:07 --> Session routines successfully run
ERROR - 2014-06-12 03:23:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:23:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:23:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:23:07 --> Email Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:23:07 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:23:07 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:23:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:23:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:23:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Controller Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:23:07 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:23:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:23:07 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:23:07 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:23:24 --> Config Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:23:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:23:24 --> URI Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Router Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Output Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Security Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Input Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:23:24 --> Language Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Loader Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:23:24 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:23:24 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Session Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:23:24 --> Session routines successfully run
ERROR - 2014-06-12 03:23:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:23:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:23:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:23:24 --> Email Class Initialized
DEBUG - 2014-06-12 03:23:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:23:24 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:23:24 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:23:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:23:24 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:25 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:23:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:25 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:25 --> Controller Class Initialized
DEBUG - 2014-06-12 03:23:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:23:25 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:23:25 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:23:25 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:23:25 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:23:46 --> Config Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:23:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:23:46 --> URI Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Router Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Output Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Security Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Input Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:23:46 --> Language Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Loader Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:23:46 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:23:46 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Session Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:23:46 --> Session routines successfully run
ERROR - 2014-06-12 03:23:46 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:23:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:23:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:23:46 --> Email Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:23:46 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:23:46 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:23:46 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:23:46 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Model Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Controller Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:23:46 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:23:46 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:23:46 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:23:46 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:33:54 --> Config Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:33:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:33:54 --> URI Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Router Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Output Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Security Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Input Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:33:54 --> Language Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Loader Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:33:54 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:33:54 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Session Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:33:54 --> Session routines successfully run
ERROR - 2014-06-12 03:33:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:33:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:33:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:33:54 --> Email Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:33:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:33:54 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:33:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Model Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Controller Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:33:54 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:33:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:33:54 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:33:54 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:36:25 --> Config Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:36:25 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:36:25 --> URI Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Router Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Output Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Security Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Input Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:36:25 --> Language Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Loader Class Initialized
DEBUG - 2014-06-12 03:36:25 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:36:26 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:36:26 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:36:26 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:36:27 --> Session Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:36:27 --> Session routines successfully run
ERROR - 2014-06-12 03:36:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:36:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:36:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:36:27 --> Email Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:36:27 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:36:27 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:36:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:36:27 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:36:27 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Controller Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:36:27 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:36:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:36:27 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:36:27 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:36:41 --> Config Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:36:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:36:41 --> URI Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Router Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Output Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Security Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Input Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:36:41 --> Language Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Loader Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:36:41 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:36:41 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Session Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:36:41 --> Session routines successfully run
ERROR - 2014-06-12 03:36:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:36:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:36:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:36:41 --> Email Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:36:41 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:36:41 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:36:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:36:41 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:36:41 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Model Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Controller Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:36:41 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:36:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:36:41 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:36:41 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:37:01 --> Config Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:37:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:37:01 --> URI Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Router Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Output Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Security Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Input Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:37:01 --> Language Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Loader Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:37:01 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:37:01 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Session Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:37:01 --> Session routines successfully run
ERROR - 2014-06-12 03:37:01 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:37:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:37:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:37:01 --> Email Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:37:01 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:37:01 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:37:01 --> Model Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Model Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:37:01 --> Model Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Model Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Controller Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:37:01 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:37:01 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:37:01 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:37:01 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:40:04 --> Config Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:40:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:40:04 --> URI Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Router Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Output Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Security Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Input Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:40:04 --> Language Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Loader Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:40:04 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:40:04 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Session Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:40:04 --> Session routines successfully run
ERROR - 2014-06-12 03:40:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:40:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:40:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:40:04 --> Email Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:40:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:40:04 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:40:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:40:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Controller Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:40:04 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:40:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:40:04 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:40:04 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:42:31 --> Config Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:42:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:42:31 --> URI Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Router Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Output Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Security Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Input Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:42:31 --> Language Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Loader Class Initialized
DEBUG - 2014-06-12 03:42:31 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:42:31 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:42:31 --> Database Driver Class Initialized
ERROR - 2014-06-12 03:42:31 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 03:42:32 --> Session Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:42:32 --> Session routines successfully run
ERROR - 2014-06-12 03:42:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:42:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:42:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:42:32 --> Email Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:42:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:42:32 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:42:32 --> Model Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Model Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:42:32 --> Model Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Model Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Controller Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:42:32 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:42:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:42:33 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:42:33 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:45:42 --> Config Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:45:42 --> URI Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Router Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Output Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Security Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Input Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:45:42 --> Language Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Loader Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:45:42 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:45:42 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Session Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:45:42 --> Session routines successfully run
ERROR - 2014-06-12 03:45:42 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:45:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:45:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:45:42 --> Email Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:45:42 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:45:42 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:45:42 --> Model Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Model Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:45:42 --> Model Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Model Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Controller Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:45:42 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:45:42 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:45:42 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:45:42 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:48:16 --> Config Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:48:16 --> URI Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Router Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Output Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Security Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Input Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:48:16 --> Language Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Loader Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:48:16 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:48:16 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Session Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:48:16 --> Session routines successfully run
ERROR - 2014-06-12 03:48:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:48:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:48:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:48:16 --> Email Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:48:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:48:16 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:48:16 --> Model Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Model Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:48:16 --> Model Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Model Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Controller Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:48:16 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:48:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:48:16 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:48:16 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:49:07 --> Config Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:49:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:49:07 --> URI Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Router Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Output Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Security Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Input Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:49:07 --> Language Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Loader Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:49:07 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:49:07 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Session Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:49:07 --> Session routines successfully run
ERROR - 2014-06-12 03:49:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:49:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:49:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:49:07 --> Email Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:49:07 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:49:07 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Controller Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:49:07 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:49:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:49:07 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:49:07 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:49:21 --> Config Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:49:21 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:49:21 --> URI Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Router Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Output Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Security Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Input Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:49:21 --> Language Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Loader Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:49:21 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:49:21 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Session Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:49:21 --> Session routines successfully run
ERROR - 2014-06-12 03:49:21 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:49:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:49:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:49:21 --> Email Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:49:21 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:49:21 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:49:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:49:21 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:49:21 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Model Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Controller Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:49:21 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:49:21 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:49:21 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:49:21 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:50:29 --> Config Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:50:29 --> URI Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Router Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Output Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Security Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Input Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:50:29 --> Language Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Loader Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:50:29 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:50:29 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Session Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:50:29 --> Session routines successfully run
ERROR - 2014-06-12 03:50:29 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:50:29 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:50:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:50:29 --> Email Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:50:29 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:50:29 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:50:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:29 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:50:29 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Controller Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:29 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:50:29 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:50:29 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:50:29 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:50:34 --> Config Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:50:34 --> URI Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Router Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Output Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Security Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Input Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:50:34 --> Language Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Loader Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:50:34 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:50:34 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Session Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:50:34 --> Session routines successfully run
ERROR - 2014-06-12 03:50:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:50:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:50:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:50:34 --> Email Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:50:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:50:34 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:50:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Controller Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:34 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:50:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:50:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:50:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:50:49 --> Config Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:50:49 --> URI Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Router Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Output Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Security Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Input Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:50:49 --> Language Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Loader Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:50:49 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:50:49 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Session Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:50:49 --> Session routines successfully run
ERROR - 2014-06-12 03:50:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:50:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:50:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:50:49 --> Email Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:50:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:50:49 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:50:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:49 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:50:49 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Controller Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:49 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:50:49 --> Pagination Class Initialized
DEBUG - 2014-06-12 03:50:49 --> Final output sent to browser
DEBUG - 2014-06-12 03:50:49 --> Total execution time: 0.0986
DEBUG - 2014-06-12 03:50:52 --> Config Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:50:52 --> URI Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Router Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Output Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Security Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Input Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:50:52 --> Language Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Loader Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:50:52 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:50:52 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Session Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:50:52 --> Session routines successfully run
ERROR - 2014-06-12 03:50:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:50:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:50:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:50:52 --> Email Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:50:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:50:52 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:50:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Model Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Controller Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:50:52 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:50:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:50:52 --> Pagination Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Config Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:54:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:54:10 --> URI Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Router Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Output Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Security Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Input Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:54:10 --> Language Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Loader Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:54:10 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:54:10 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Session Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:54:10 --> Session routines successfully run
ERROR - 2014-06-12 03:54:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:54:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:54:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:54:10 --> Email Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:54:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:54:10 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:54:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:54:10 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:54:10 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Controller Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:54:10 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:54:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:54:10 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:54:10 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:54:35 --> Config Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:54:35 --> URI Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Router Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Output Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Security Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Input Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:54:35 --> Language Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Loader Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:54:35 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:54:35 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Session Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:54:35 --> Session routines successfully run
ERROR - 2014-06-12 03:54:35 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:54:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:54:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:54:35 --> Email Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:54:35 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:54:35 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:54:35 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:54:35 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Model Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Controller Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:54:35 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:54:35 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:54:35 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:54:35 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:56:48 --> Config Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:56:48 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:56:48 --> URI Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Router Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Output Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Security Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Input Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:56:48 --> Language Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Loader Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:56:48 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:56:48 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Session Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:56:48 --> Session routines successfully run
ERROR - 2014-06-12 03:56:48 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:56:48 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:56:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:56:48 --> Email Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:56:48 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:56:48 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:56:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:56:48 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:56:48 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Controller Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:56:48 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:56:48 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:56:48 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:56:48 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:56:59 --> Config Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:56:59 --> URI Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Router Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Output Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Security Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Input Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:56:59 --> Language Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Loader Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:56:59 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:56:59 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Session Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:56:59 --> Session routines successfully run
ERROR - 2014-06-12 03:56:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:56:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:56:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:56:59 --> Email Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:56:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:56:59 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:56:59 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:56:59 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Model Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Controller Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:56:59 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:56:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:56:59 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:56:59 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 03:57:04 --> Config Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:57:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:57:04 --> URI Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Router Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Output Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Security Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Input Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:57:04 --> Language Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Loader Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:57:04 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:57:04 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Session Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:57:04 --> Session routines successfully run
ERROR - 2014-06-12 03:57:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:57:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:57:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:57:04 --> Email Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:57:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:57:04 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:57:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:57:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Controller Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:57:04 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:57:04 --> Pagination Class Initialized
DEBUG - 2014-06-12 03:57:04 --> Final output sent to browser
DEBUG - 2014-06-12 03:57:04 --> Total execution time: 0.0843
DEBUG - 2014-06-12 03:57:06 --> Config Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:57:06 --> URI Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Router Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Output Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Security Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Input Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:57:06 --> Language Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Loader Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:57:06 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:57:06 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Session Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:57:06 --> Session routines successfully run
ERROR - 2014-06-12 03:57:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:57:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:57:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:57:06 --> Email Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:57:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:57:06 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:57:06 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:57:06 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Controller Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:57:06 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:57:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:57:06 --> Pagination Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Config Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Hooks Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Utf8 Class Initialized
DEBUG - 2014-06-12 03:57:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 03:57:08 --> URI Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Router Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Output Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Security Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Input Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 03:57:08 --> Language Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Loader Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Helper loaded: url_helper
DEBUG - 2014-06-12 03:57:08 --> Helper loaded: form_helper
DEBUG - 2014-06-12 03:57:08 --> Database Driver Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Session Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Helper loaded: string_helper
DEBUG - 2014-06-12 03:57:08 --> Session routines successfully run
ERROR - 2014-06-12 03:57:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 03:57:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 03:57:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 03:57:08 --> Email Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 03:57:08 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 03:57:08 --> Helper loaded: language_helper
DEBUG - 2014-06-12 03:57:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:57:08 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Helper loaded: date_helper
DEBUG - 2014-06-12 03:57:08 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Model Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Controller Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 03:57:08 --> Form Validation Class Initialized
DEBUG - 2014-06-12 03:57:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 03:57:08 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 03:57:08 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:07:51 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:51 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:51 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:51 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:51 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:51 --> Session routines successfully run
ERROR - 2014-06-12 04:07:51 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:51 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:51 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:51 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:51 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:51 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:51 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:52 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:07:52 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-12 04:07:52 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:07:52 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-12 04:07:52 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:52 --> Total execution time: 0.2322
DEBUG - 2014-06-12 04:07:52 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:52 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:52 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:52 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:52 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:52 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:52 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:52 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:52 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:52 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:52 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:52 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:52 --> Session routines successfully run
DEBUG - 2014-06-12 04:07:52 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language Class Initialized
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:52 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:52 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:52 --> Session routines successfully run
DEBUG - 2014-06-12 04:07:52 --> Email Class Initialized
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:52 --> Session routines successfully run
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:52 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:52 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:52 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Session routines successfully run
DEBUG - 2014-06-12 04:07:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Form Validation Class Initialized
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:52 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Total execution time: 0.2437
DEBUG - 2014-06-12 04:07:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:52 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:52 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:52 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:52 --> Total execution time: 0.3100
DEBUG - 2014-06-12 04:07:52 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:52 --> Total execution time: 0.3276
DEBUG - 2014-06-12 04:07:52 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:52 --> Total execution time: 0.3134
DEBUG - 2014-06-12 04:07:54 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:54 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:54 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:54 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:54 --> Session routines successfully run
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:54 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:54 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:07:54 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-12 04:07:54 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:07:54 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-12 04:07:54 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:54 --> Total execution time: 0.1058
DEBUG - 2014-06-12 04:07:54 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:54 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:54 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:54 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:54 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:54 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:54 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:54 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Config Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:54 --> URI Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:54 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Router Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Output Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Security Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:54 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Input Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session routines successfully run
DEBUG - 2014-06-12 04:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:07:54 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Loader Class Initialized
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: string_helper
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:54 --> Loader Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:07:54 --> Session routines successfully run
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:54 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:54 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:54 --> Session Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Session routines successfully run
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:07:54 --> Session routines successfully run
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:07:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:07:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:54 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:54 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Email Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:54 --> Total execution time: 0.1639
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Total execution time: 0.1351
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:07:54 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Model Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Controller Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:07:54 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:07:54 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:54 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:07:54 --> Total execution time: 0.1527
DEBUG - 2014-06-12 04:07:54 --> Final output sent to browser
DEBUG - 2014-06-12 04:07:54 --> Total execution time: 0.1424
DEBUG - 2014-06-12 04:08:03 --> Config Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:08:03 --> URI Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Router Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Output Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Security Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Input Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:08:03 --> Language Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Loader Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:08:03 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:08:03 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Session Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:08:03 --> Session routines successfully run
ERROR - 2014-06-12 04:08:03 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:08:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:08:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:08:03 --> Email Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:08:03 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:08:03 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:08:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:08:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Controller Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:03 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:08:03 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:08:03 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:08:03 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:08:03 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:08:03 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:08:03 --> Final output sent to browser
DEBUG - 2014-06-12 04:08:03 --> Total execution time: 0.1122
DEBUG - 2014-06-12 04:08:06 --> Config Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:08:06 --> URI Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Router Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Output Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Security Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Input Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:08:06 --> Language Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Loader Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:08:06 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:08:06 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Session Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:08:06 --> Session routines successfully run
ERROR - 2014-06-12 04:08:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:08:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:08:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:08:06 --> Email Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:08:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:08:06 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:08:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Controller Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:06 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:08:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:08:06 --> Pagination Class Initialized
ERROR - 2014-06-12 04:08:06 --> 404 Page Not Found --> report_controller/home
DEBUG - 2014-06-12 04:08:34 --> Config Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:08:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:08:34 --> URI Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Router Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Output Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Security Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Input Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:08:34 --> Language Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Loader Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:08:34 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:08:34 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Session Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:08:34 --> Session routines successfully run
ERROR - 2014-06-12 04:08:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:08:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:08:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:08:34 --> Email Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:08:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:08:34 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:08:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Controller Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:34 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:08:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:08:34 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:08:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:08:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:08:34 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:08:34 --> Final output sent to browser
DEBUG - 2014-06-12 04:08:34 --> Total execution time: 0.0769
DEBUG - 2014-06-12 04:08:47 --> Config Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:08:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:08:47 --> URI Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Router Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Output Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Security Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Input Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:08:47 --> Language Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Loader Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:08:47 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:08:47 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Session Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:08:47 --> Session routines successfully run
ERROR - 2014-06-12 04:08:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:08:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:08:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:08:47 --> Email Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:08:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:08:47 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:08:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:08:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Controller Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:08:47 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:08:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:08:47 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:08:47 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:08:47 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:08:47 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:08:47 --> Final output sent to browser
DEBUG - 2014-06-12 04:08:47 --> Total execution time: 0.0794
DEBUG - 2014-06-12 04:09:14 --> Config Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:09:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:09:14 --> URI Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Router Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Output Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Security Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Input Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:09:14 --> Language Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Loader Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:09:14 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:09:14 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Session Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:09:14 --> Session routines successfully run
ERROR - 2014-06-12 04:09:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:09:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:09:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:09:14 --> Email Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:09:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:09:14 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:09:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:09:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Controller Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:09:14 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:09:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:09:14 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:09:14 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:09:14 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:09:14 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:09:14 --> Final output sent to browser
DEBUG - 2014-06-12 04:09:14 --> Total execution time: 0.0844
DEBUG - 2014-06-12 04:11:05 --> Config Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:11:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:11:05 --> URI Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Router Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Output Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Security Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Input Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:11:05 --> Language Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Loader Class Initialized
DEBUG - 2014-06-12 04:11:05 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:11:05 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:11:05 --> Database Driver Class Initialized
ERROR - 2014-06-12 04:11:05 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-12 04:11:06 --> Session Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:11:06 --> Session routines successfully run
ERROR - 2014-06-12 04:11:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:11:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:11:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:11:06 --> Email Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:11:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:11:06 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:11:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:11:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Controller Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:11:06 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:11:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:11:06 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:11:06 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:11:06 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:11:06 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:11:06 --> Final output sent to browser
DEBUG - 2014-06-12 04:11:06 --> Total execution time: 1.1407
DEBUG - 2014-06-12 04:11:39 --> Config Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:11:39 --> URI Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Router Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Output Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Security Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Input Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:11:39 --> Language Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Loader Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:11:39 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:11:39 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Session Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:11:39 --> Session routines successfully run
ERROR - 2014-06-12 04:11:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:11:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:11:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:11:39 --> Email Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:11:39 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:11:39 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:11:39 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:11:39 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Controller Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:11:39 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:11:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:11:39 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:11:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:11:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:11:39 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:11:39 --> Final output sent to browser
DEBUG - 2014-06-12 04:11:39 --> Total execution time: 0.1114
DEBUG - 2014-06-12 04:11:50 --> Config Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:11:50 --> URI Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Router Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Output Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Security Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Input Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:11:50 --> Language Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Loader Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:11:50 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:11:50 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Session Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:11:50 --> Session routines successfully run
ERROR - 2014-06-12 04:11:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:11:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:11:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:11:50 --> Email Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:11:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:11:50 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:11:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Controller Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:11:50 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:11:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:11:50 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:11:50 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:11:50 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:11:50 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:11:50 --> Final output sent to browser
DEBUG - 2014-06-12 04:11:50 --> Total execution time: 0.0922
DEBUG - 2014-06-12 04:14:23 --> Config Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:14:23 --> URI Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Router Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Output Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Security Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Input Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:14:23 --> Language Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Loader Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:14:23 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:14:23 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Session Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:14:23 --> Session routines successfully run
ERROR - 2014-06-12 04:14:23 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:14:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:14:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:14:23 --> Email Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:14:23 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:14:23 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:14:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:14:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Controller Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:14:23 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:14:23 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:14:23 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:14:23 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:14:23 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:14:23 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:14:23 --> Final output sent to browser
DEBUG - 2014-06-12 04:14:23 --> Total execution time: 0.1095
DEBUG - 2014-06-12 04:18:34 --> Config Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:18:34 --> URI Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Router Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Output Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Security Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Input Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:18:34 --> Language Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Loader Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:18:34 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:18:34 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Session Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:18:34 --> Session routines successfully run
ERROR - 2014-06-12 04:18:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:18:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:18:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:18:34 --> Email Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:18:34 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:18:34 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Model Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Controller Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:18:34 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:18:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:18:34 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:18:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:18:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:18:34 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:18:34 --> Final output sent to browser
DEBUG - 2014-06-12 04:18:34 --> Total execution time: 0.1022
DEBUG - 2014-06-12 04:19:57 --> Config Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:19:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:19:57 --> URI Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Router Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Output Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Security Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Input Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:19:57 --> Language Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Loader Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:19:57 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:19:57 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Session Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:19:57 --> Session routines successfully run
ERROR - 2014-06-12 04:19:57 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:19:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:19:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:19:57 --> Email Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:19:57 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:19:57 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:19:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:19:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:19:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Controller Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:19:57 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:19:57 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:19:57 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:19:57 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:19:57 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:19:57 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:19:57 --> Final output sent to browser
DEBUG - 2014-06-12 04:19:57 --> Total execution time: 0.0953
DEBUG - 2014-06-12 04:20:03 --> Config Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:20:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:20:03 --> URI Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Router Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Output Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Security Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Input Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:20:03 --> Language Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Loader Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:20:03 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:20:03 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Session Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:20:03 --> Session routines successfully run
ERROR - 2014-06-12 04:20:03 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:20:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:20:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:20:03 --> Email Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:20:03 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:20:03 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:20:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:20:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Controller Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:20:03 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:20:03 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:20:03 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:20:04 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:20:04 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:20:04 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:20:04 --> Final output sent to browser
DEBUG - 2014-06-12 04:20:04 --> Total execution time: 0.0913
DEBUG - 2014-06-12 04:20:16 --> Config Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:20:16 --> URI Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Router Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Output Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Security Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Input Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:20:16 --> Language Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Loader Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:20:16 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:20:16 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Session Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:20:16 --> Session routines successfully run
ERROR - 2014-06-12 04:20:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:20:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:20:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:20:16 --> Email Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:20:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:20:16 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:20:16 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:20:16 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Model Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Controller Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:20:16 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:20:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:20:16 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:20:16 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:20:16 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:20:16 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:20:16 --> Final output sent to browser
DEBUG - 2014-06-12 04:20:16 --> Total execution time: 0.0960
DEBUG - 2014-06-12 04:22:00 --> Config Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:22:00 --> URI Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Router Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Output Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Security Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Input Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:22:00 --> Language Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Loader Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:22:00 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:22:00 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Session Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:22:00 --> Session routines successfully run
ERROR - 2014-06-12 04:22:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:22:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:22:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:22:00 --> Email Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:22:00 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:22:00 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:00 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:22:00 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Controller Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:00 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:22:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:22:00 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:22:00 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:22:00 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:22:00 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:22:00 --> Final output sent to browser
DEBUG - 2014-06-12 04:22:00 --> Total execution time: 0.0797
DEBUG - 2014-06-12 04:22:17 --> Config Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:22:17 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:22:17 --> URI Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Router Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Output Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Security Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Input Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:22:17 --> Language Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Loader Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:22:17 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:22:17 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Session Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:22:17 --> Session routines successfully run
ERROR - 2014-06-12 04:22:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:22:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:22:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:22:17 --> Email Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:22:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:22:17 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:17 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:22:17 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Controller Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:17 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:22:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:22:17 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:22:17 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:22:17 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:22:17 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:22:17 --> Final output sent to browser
DEBUG - 2014-06-12 04:22:17 --> Total execution time: 0.0879
DEBUG - 2014-06-12 04:22:36 --> Config Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:22:36 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:22:36 --> URI Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Router Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Output Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Security Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Input Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:22:36 --> Language Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Loader Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:22:36 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:22:36 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Session Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:22:36 --> Session routines successfully run
ERROR - 2014-06-12 04:22:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:22:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:22:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:22:36 --> Email Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:22:36 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:22:36 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:36 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:22:36 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Controller Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:36 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:22:36 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:22:36 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:22:36 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:22:36 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:22:36 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:22:36 --> Final output sent to browser
DEBUG - 2014-06-12 04:22:36 --> Total execution time: 0.0847
DEBUG - 2014-06-12 04:22:55 --> Config Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:22:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:22:55 --> URI Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Router Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Output Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Security Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Input Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:22:55 --> Language Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Loader Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:22:55 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:22:55 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Session Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:22:55 --> Session routines successfully run
ERROR - 2014-06-12 04:22:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:22:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:22:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:22:55 --> Email Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:22:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:22:55 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:55 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:22:55 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Model Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Controller Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:22:55 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:22:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:22:55 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:22:55 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:22:55 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:22:55 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:22:55 --> Final output sent to browser
DEBUG - 2014-06-12 04:22:55 --> Total execution time: 0.0874
DEBUG - 2014-06-12 04:28:20 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:20 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Router Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Output Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Security Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Input Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:28:20 --> Language Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Loader Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:28:20 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:28:20 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Session Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:28:20 --> Session routines successfully run
ERROR - 2014-06-12 04:28:20 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:28:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:28:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:28:20 --> Email Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:28:20 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:28:20 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:28:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:28:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Controller Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:28:20 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:28:20 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:28:20 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:28:20 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:28:20 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:28:20 --> Final output sent to browser
DEBUG - 2014-06-12 04:28:20 --> Total execution time: 0.0855
DEBUG - 2014-06-12 04:28:20 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:20 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:20 --> Router Class Initialized
ERROR - 2014-06-12 04:28:20 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:28:21 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:21 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:21 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:21 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:21 --> Router Class Initialized
ERROR - 2014-06-12 04:28:21 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:28:50 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:50 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Router Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Output Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Security Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Input Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:28:50 --> Language Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Loader Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:28:50 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:28:50 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Session Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:28:50 --> Session routines successfully run
ERROR - 2014-06-12 04:28:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:28:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:28:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:28:50 --> Email Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:28:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:28:50 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:28:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:28:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Controller Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:28:50 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:28:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:28:50 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:28:50 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:28:50 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:28:50 --> Final output sent to browser
DEBUG - 2014-06-12 04:28:50 --> Total execution time: 0.0899
DEBUG - 2014-06-12 04:28:51 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:51 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:51 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:51 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:51 --> Router Class Initialized
ERROR - 2014-06-12 04:28:51 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:28:51 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:51 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:51 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:51 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:51 --> Router Class Initialized
ERROR - 2014-06-12 04:28:51 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:28:57 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:57 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Router Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Output Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Security Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Input Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:28:57 --> Language Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Loader Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:28:57 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:28:57 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Session Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:28:57 --> Session routines successfully run
ERROR - 2014-06-12 04:28:57 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:28:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:28:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:28:57 --> Email Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:28:57 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:28:57 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:28:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:28:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:28:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Model Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Controller Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:28:57 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:28:57 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:28:57 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:28:57 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:28:57 --> Final output sent to browser
DEBUG - 2014-06-12 04:28:57 --> Total execution time: 0.0871
DEBUG - 2014-06-12 04:28:57 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:57 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:57 --> Router Class Initialized
ERROR - 2014-06-12 04:28:57 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:28:58 --> Config Class Initialized
DEBUG - 2014-06-12 04:28:58 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:28:58 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:28:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:28:58 --> URI Class Initialized
DEBUG - 2014-06-12 04:28:58 --> Router Class Initialized
ERROR - 2014-06-12 04:28:58 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:29:07 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:07 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Router Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Output Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Security Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Input Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:29:07 --> Language Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Loader Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:29:07 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:29:07 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Session Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:29:07 --> Session routines successfully run
ERROR - 2014-06-12 04:29:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:29:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:29:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:29:07 --> Email Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:29:07 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:29:07 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:29:07 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:29:07 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Controller Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:29:07 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:29:07 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:29:07 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:29:07 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:29:07 --> Final output sent to browser
DEBUG - 2014-06-12 04:29:07 --> Total execution time: 0.0996
DEBUG - 2014-06-12 04:29:07 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:07 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:07 --> Router Class Initialized
ERROR - 2014-06-12 04:29:07 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:29:08 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:08 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:08 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:08 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:08 --> Router Class Initialized
ERROR - 2014-06-12 04:29:08 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:29:19 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:19 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Router Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Output Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Security Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Input Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:29:19 --> Language Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Loader Class Initialized
DEBUG - 2014-06-12 04:29:19 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:29:19 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:29:20 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Session Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:29:20 --> Session routines successfully run
ERROR - 2014-06-12 04:29:20 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:29:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:29:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:29:20 --> Email Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:29:20 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:29:20 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:29:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:29:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:29:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Controller Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:29:20 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:29:20 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:29:20 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:29:20 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:29:20 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:29:20 --> Final output sent to browser
DEBUG - 2014-06-12 04:29:20 --> Total execution time: 0.1069
DEBUG - 2014-06-12 04:29:20 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:20 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Router Class Initialized
ERROR - 2014-06-12 04:29:20 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:29:20 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:20 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:20 --> Router Class Initialized
ERROR - 2014-06-12 04:29:20 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:29:47 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:47 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Router Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Output Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Security Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Input Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:29:47 --> Language Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Loader Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:29:47 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:29:47 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Session Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:29:47 --> Session routines successfully run
ERROR - 2014-06-12 04:29:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:29:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:29:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:29:47 --> Email Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:29:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:29:47 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:29:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:29:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Model Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Controller Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:29:47 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:29:47 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:29:47 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:29:47 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:29:47 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:29:47 --> Final output sent to browser
DEBUG - 2014-06-12 04:29:47 --> Total execution time: 0.0788
DEBUG - 2014-06-12 04:29:47 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:47 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Router Class Initialized
ERROR - 2014-06-12 04:29:47 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:29:47 --> Config Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:29:47 --> URI Class Initialized
DEBUG - 2014-06-12 04:29:47 --> Router Class Initialized
ERROR - 2014-06-12 04:29:47 --> 404 Page Not Found --> jquery.confirm.js
DEBUG - 2014-06-12 04:33:23 --> Config Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:33:23 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:33:23 --> URI Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Router Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Output Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Security Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Input Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:33:23 --> Language Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Loader Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:33:23 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:33:23 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Session Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:33:23 --> Session routines successfully run
ERROR - 2014-06-12 04:33:23 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:33:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:33:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:33:23 --> Email Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:33:23 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:33:23 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:33:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:33:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Model Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Controller Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:33:23 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:33:23 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:33:23 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:33:23 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:33:23 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:33:23 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:33:23 --> Final output sent to browser
DEBUG - 2014-06-12 04:33:23 --> Total execution time: 0.0927
DEBUG - 2014-06-12 04:34:14 --> Config Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:34:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:34:14 --> URI Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Router Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Output Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Security Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Input Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:34:14 --> Language Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Loader Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:34:14 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:34:14 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Session Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:34:14 --> Session routines successfully run
ERROR - 2014-06-12 04:34:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:34:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:34:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:34:14 --> Email Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:34:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:34:14 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:34:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:34:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Controller Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:34:14 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:34:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:34:14 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:34:14 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:34:14 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:34:14 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:34:14 --> Final output sent to browser
DEBUG - 2014-06-12 04:34:14 --> Total execution time: 0.0990
DEBUG - 2014-06-12 04:34:27 --> Config Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Hooks Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Utf8 Class Initialized
DEBUG - 2014-06-12 04:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-12 04:34:27 --> URI Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Router Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Output Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Security Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Input Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-12 04:34:27 --> Language Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Loader Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Helper loaded: url_helper
DEBUG - 2014-06-12 04:34:27 --> Helper loaded: form_helper
DEBUG - 2014-06-12 04:34:27 --> Database Driver Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Session Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Helper loaded: string_helper
DEBUG - 2014-06-12 04:34:27 --> Session routines successfully run
ERROR - 2014-06-12 04:34:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-12 04:34:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-12 04:34:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-12 04:34:27 --> Email Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-12 04:34:27 --> Helper loaded: cookie_helper
DEBUG - 2014-06-12 04:34:27 --> Helper loaded: language_helper
DEBUG - 2014-06-12 04:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:34:27 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Helper loaded: date_helper
DEBUG - 2014-06-12 04:34:27 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Model Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Controller Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-12 04:34:27 --> Form Validation Class Initialized
DEBUG - 2014-06-12 04:34:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-12 04:34:27 --> Pagination Class Initialized
DEBUG - 2014-06-12 04:34:27 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-12 04:34:27 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-12 04:34:27 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-12 04:34:27 --> Final output sent to browser
DEBUG - 2014-06-12 04:34:27 --> Total execution time: 0.1021
DEBUG - 2014-06-12 21:39:55 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-12 21:39:55 --> Final output sent to browser
DEBUG - 2014-06-12 21:39:55 --> Total execution time: 0.3406
