<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-13 23:22:44 --> Config Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:22:44 --> URI Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Router Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Output Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Security Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Input Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:22:44 --> Language Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Loader Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:22:44 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:22:44 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Session Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:22:44 --> Session routines successfully run
ERROR - 2014-07-13 23:22:44 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:22:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:22:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:22:44 --> Email Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:22:44 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:22:44 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:22:44 --> Model Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Model Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:22:44 --> Model Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Model Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Controller Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:22:44 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:22:44 --> Pagination Class Initialized
ERROR - 2014-07-13 23:22:44 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:22:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:22:44 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:22:44 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:22:44 --> XSS Filtering completed
DEBUG - 2014-07-13 23:22:44 --> XSS Filtering completed
DEBUG - 2014-07-13 23:22:44 --> XSS Filtering completed
DEBUG - 2014-07-13 23:22:44 --> XSS Filtering completed
DEBUG - 2014-07-13 23:22:44 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:22:44 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:22:44 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:22:44 --> Final output sent to browser
DEBUG - 2014-07-13 23:22:44 --> Total execution time: 0.1598
DEBUG - 2014-07-13 23:23:00 --> Config Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:23:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:23:00 --> URI Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Router Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Output Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Security Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Input Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:23:00 --> Language Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Loader Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:23:00 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:23:00 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Session Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:23:00 --> Session routines successfully run
ERROR - 2014-07-13 23:23:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:23:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:23:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:23:00 --> Email Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:23:00 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:23:00 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:23:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:23:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:23:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Controller Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:23:00 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:23:00 --> Pagination Class Initialized
ERROR - 2014-07-13 23:23:00 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:23:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:23:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:23:00 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:23:00 --> XSS Filtering completed
DEBUG - 2014-07-13 23:23:00 --> XSS Filtering completed
DEBUG - 2014-07-13 23:23:00 --> XSS Filtering completed
DEBUG - 2014-07-13 23:23:00 --> XSS Filtering completed
DEBUG - 2014-07-13 23:23:00 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:23:00 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:23:00 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:23:00 --> Final output sent to browser
DEBUG - 2014-07-13 23:23:00 --> Total execution time: 0.1658
DEBUG - 2014-07-13 23:31:24 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:24 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:24 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:24 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:24 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:24 --> Session routines successfully run
ERROR - 2014-07-13 23:31:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:24 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:24 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:24 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:24 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:24 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:24 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:24 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:24 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:24 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:24 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:31:24 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:24 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:24 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:24 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:24 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:31:24 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:31:24 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:31:24 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:24 --> Total execution time: 0.1067
DEBUG - 2014-07-13 23:31:35 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:35 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:35 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:35 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:35 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:35 --> Session routines successfully run
ERROR - 2014-07-13 23:31:35 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:35 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:35 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:35 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:35 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:35 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:35 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:35 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:35 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:35 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:35 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:35 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:31:35 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:31:35 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:31:35 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:35 --> Total execution time: 0.1146
DEBUG - 2014-07-13 23:31:38 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:38 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:38 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:38 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:38 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:38 --> Session routines successfully run
ERROR - 2014-07-13 23:31:38 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:38 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:38 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:38 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:38 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:38 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:38 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:38 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:38 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:38 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:38 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:31:38 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:31:38 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:31:38 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:31:38 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:38 --> Total execution time: 0.1043
DEBUG - 2014-07-13 23:31:39 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:39 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:39 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:39 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:39 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:39 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:39 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:39 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:39 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:39 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:39 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:39 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:39 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:39 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:39 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Session routines successfully run
DEBUG - 2014-07-13 23:31:39 --> Database Driver Class Initialized
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:39 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:39 --> Session routines successfully run
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:39 --> Session routines successfully run
DEBUG - 2014-07-13 23:31:39 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: cookie_helper
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: language_helper
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:39 --> Session routines successfully run
DEBUG - 2014-07-13 23:31:39 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:39 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Form Validation Class Initialized
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:39 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Total execution time: 0.1228
DEBUG - 2014-07-13 23:31:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:39 --> Total execution time: 0.1454
DEBUG - 2014-07-13 23:31:39 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:39 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:39 --> Total execution time: 0.1372
DEBUG - 2014-07-13 23:31:39 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:39 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:39 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:39 --> Total execution time: 0.1784
DEBUG - 2014-07-13 23:31:40 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:40 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:40 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:40 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:40 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:40 --> Session routines successfully run
ERROR - 2014-07-13 23:31:40 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:40 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:40 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:40 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:40 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:40 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:40 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:40 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-07-13 23:31:40 --> Severity: Notice  --> Undefined variable: additional_data C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 88
DEBUG - 2014-07-13 23:31:40 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:31:40 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:31:40 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:31:40 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:40 --> Total execution time: 0.0978
DEBUG - 2014-07-13 23:31:58 --> Config Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:31:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:31:58 --> URI Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Router Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Output Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Security Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Input Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:31:58 --> Language Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Loader Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:31:58 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:31:58 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Session Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:31:58 --> Session routines successfully run
ERROR - 2014-07-13 23:31:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:31:58 --> Email Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:31:58 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:31:58 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:31:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:31:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Controller Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:31:58 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:31:58 --> Pagination Class Initialized
ERROR - 2014-07-13 23:31:58 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:31:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:31:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:31:58 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:31:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:31:58 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:31:58 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:31:58 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:31:58 --> Final output sent to browser
DEBUG - 2014-07-13 23:31:58 --> Total execution time: 0.0825
DEBUG - 2014-07-13 23:33:04 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:04 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:04 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:04 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:04 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:04 --> Session routines successfully run
ERROR - 2014-07-13 23:33:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:04 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:04 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:04 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:04 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:04 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:04 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:04 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:04 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:04 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:33:04 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:33:04 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:33:04 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:04 --> Total execution time: 0.0892
DEBUG - 2014-07-13 23:33:07 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:07 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:07 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:07 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:07 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:07 --> Session routines successfully run
ERROR - 2014-07-13 23:33:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:07 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:07 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:07 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:07 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:07 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:07 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:07 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:07 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:07 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:33:07 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:33:07 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:33:07 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:33:07 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:07 --> Total execution time: 0.1199
DEBUG - 2014-07-13 23:33:08 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:08 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:08 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:08 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:08 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:08 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:08 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:08 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:08 --> Session routines successfully run
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:08 --> Router Class Initialized
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Output Class Initialized
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:08 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:08 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:08 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:08 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:08 --> Session routines successfully run
DEBUG - 2014-07-13 23:33:08 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:08 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:08 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:08 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/ion_auth_lang.php
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:08 --> Total execution time: 0.0912
DEBUG - 2014-07-13 23:33:08 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:08 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:08 --> Session routines successfully run
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:08 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:08 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:08 --> Total execution time: 0.1265
DEBUG - 2014-07-13 23:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:08 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:08 --> Session routines successfully run
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:08 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:08 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Total execution time: 0.1218
DEBUG - 2014-07-13 23:33:08 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:08 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:08 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:08 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:08 --> Total execution time: 0.1308
DEBUG - 2014-07-13 23:33:10 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:10 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:10 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:10 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:10 --> Session routines successfully run
ERROR - 2014-07-13 23:33:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:10 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:10 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:10 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:10 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:10 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:10 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:10 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:10 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:33:10 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:33:10 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:33:10 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:10 --> Total execution time: 0.0904
DEBUG - 2014-07-13 23:33:12 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:12 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:12 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:12 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:12 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:12 --> Session routines successfully run
ERROR - 2014-07-13 23:33:12 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:12 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:12 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:12 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:12 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:12 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:12 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:12 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:12 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:33:12 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:33:12 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:33:12 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:12 --> Total execution time: 0.0849
DEBUG - 2014-07-13 23:33:21 --> Config Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:33:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:33:21 --> URI Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Router Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Output Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Security Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Input Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:33:21 --> Language Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Loader Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:33:21 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:33:21 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Session Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:33:21 --> Session routines successfully run
ERROR - 2014-07-13 23:33:21 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:33:21 --> Email Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:33:21 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:33:21 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:21 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:33:21 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Model Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Controller Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:33:21 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:33:21 --> Pagination Class Initialized
ERROR - 2014-07-13 23:33:21 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:33:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:33:21 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:33:21 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:33:21 --> XSS Filtering completed
DEBUG - 2014-07-13 23:33:21 --> XSS Filtering completed
DEBUG - 2014-07-13 23:33:21 --> XSS Filtering completed
DEBUG - 2014-07-13 23:33:21 --> XSS Filtering completed
DEBUG - 2014-07-13 23:33:21 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:33:21 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:33:21 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:33:21 --> Final output sent to browser
DEBUG - 2014-07-13 23:33:21 --> Total execution time: 0.1008
DEBUG - 2014-07-13 23:34:06 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:06 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:06 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:06 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:06 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:06 --> Session routines successfully run
ERROR - 2014-07-13 23:34:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:06 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:06 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:06 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:06 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:06 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:06 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:06 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:06 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:06 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:34:06 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:34:06 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:34:06 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:06 --> Total execution time: 0.0894
DEBUG - 2014-07-13 23:34:12 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:12 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:12 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:12 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:12 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:12 --> Session routines successfully run
ERROR - 2014-07-13 23:34:12 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:12 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:12 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:12 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:12 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:12 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:12 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:12 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:12 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:34:12 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:34:12 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:34:12 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:12 --> Total execution time: 0.0865
DEBUG - 2014-07-13 23:34:16 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:16 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:16 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:16 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:16 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:16 --> Session routines successfully run
ERROR - 2014-07-13 23:34:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:16 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:16 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:16 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:16 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:16 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:16 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:16 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:16 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:16 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:34:16 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:34:16 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:34:16 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:34:16 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:16 --> Total execution time: 0.1044
DEBUG - 2014-07-13 23:34:17 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:17 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:17 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:17 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:17 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:17 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:17 --> Session routines successfully run
ERROR - 2014-07-13 23:34:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:18 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:18 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:18 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:18 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:18 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:18 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:18 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:18 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:18 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:18 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:18 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:18 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:18 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:18 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:18 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:18 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:18 --> Session routines successfully run
DEBUG - 2014-07-13 23:34:18 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:18 --> Total execution time: 0.1167
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:18 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:18 --> Session routines successfully run
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:18 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: date_helper
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:18 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:18 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:18 --> Total execution time: 0.1297
DEBUG - 2014-07-13 23:34:18 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:18 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:18 --> Total execution time: 0.1417
DEBUG - 2014-07-13 23:34:18 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:18 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:18 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:18 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:18 --> Database Driver Class Initialized
ERROR - 2014-07-13 23:34:18 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-13 23:34:19 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:19 --> Session routines successfully run
ERROR - 2014-07-13 23:34:19 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:19 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:19 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:19 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:19 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:19 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:19 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:19 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:19 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:19 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:19 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:19 --> Total execution time: 1.1781
DEBUG - 2014-07-13 23:34:27 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:27 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:27 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:27 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:27 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:27 --> Session routines successfully run
ERROR - 2014-07-13 23:34:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:27 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:27 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:27 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:27 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:27 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:27 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:27 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:27 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:27 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:34:27 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:34:27 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:34:27 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:27 --> Total execution time: 0.0869
DEBUG - 2014-07-13 23:34:39 --> Config Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:34:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:34:39 --> URI Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Router Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Output Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Security Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Input Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:34:39 --> Language Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Loader Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:34:39 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:34:39 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Session Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:34:39 --> Session routines successfully run
ERROR - 2014-07-13 23:34:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:34:39 --> Email Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:34:39 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:34:39 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:34:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Controller Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:34:39 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:34:39 --> Pagination Class Initialized
ERROR - 2014-07-13 23:34:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:34:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:34:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:34:39 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:34:39 --> XSS Filtering completed
DEBUG - 2014-07-13 23:34:39 --> XSS Filtering completed
DEBUG - 2014-07-13 23:34:39 --> XSS Filtering completed
DEBUG - 2014-07-13 23:34:39 --> XSS Filtering completed
DEBUG - 2014-07-13 23:34:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:34:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:34:39 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:34:39 --> Final output sent to browser
DEBUG - 2014-07-13 23:34:39 --> Total execution time: 0.0966
DEBUG - 2014-07-13 23:41:23 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:23 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:23 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:23 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:23 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:23 --> Session routines successfully run
ERROR - 2014-07-13 23:41:23 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:23 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:23 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:23 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:23 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:23 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:23 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:23 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:23 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:23 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:23 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:23 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:41:23 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:41:23 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:41:23 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:23 --> Total execution time: 0.1319
DEBUG - 2014-07-13 23:41:32 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:32 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:32 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:32 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:32 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:32 --> Session routines successfully run
ERROR - 2014-07-13 23:41:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:32 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:32 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:32 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:32 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:32 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:32 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:32 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:32 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:41:32 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:41:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:41:32 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:41:32 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:32 --> Total execution time: 0.1256
DEBUG - 2014-07-13 23:41:33 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:33 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:33 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:33 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:33 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:33 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:33 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:33 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:33 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:33 --> Security Class Initialized
ERROR - 2014-07-13 23:41:33 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:33 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:33 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:33 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:33 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:33 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:33 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:33 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:33 --> Session routines successfully run
ERROR - 2014-07-13 23:41:33 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:33 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:33 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:33 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:33 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:34 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:34 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:34 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: form_helper
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:34 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:34 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:34 --> Total execution time: 0.1453
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:34 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:34 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:34 --> Total execution time: 0.1484
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:34 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:34 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:34 --> Total execution time: 0.1579
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:34 --> Total execution time: 0.1979
DEBUG - 2014-07-13 23:41:34 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:34 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:34 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:34 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:34 --> Session routines successfully run
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:34 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:34 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:34 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:41:34 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:41:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:41:34 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:41:34 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:34 --> Total execution time: 0.1283
DEBUG - 2014-07-13 23:41:36 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:36 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:36 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:36 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:36 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:36 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:36 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:36 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:36 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:36 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:36 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:36 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:36 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:36 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:36 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:36 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:36 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:36 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: string_helper
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:36 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:36 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:36 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: cookie_helper
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:36 --> Form Validation Class Initialized
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:36 --> Session routines successfully run
DEBUG - 2014-07-13 23:41:36 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Final output sent to browser
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Total execution time: 0.1489
DEBUG - 2014-07-13 23:41:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:36 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:36 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Form Validation Class Initialized
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:36 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:36 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:36 --> Total execution time: 0.2259
DEBUG - 2014-07-13 23:41:36 --> Total execution time: 0.1667
DEBUG - 2014-07-13 23:41:36 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:36 --> Total execution time: 0.2133
DEBUG - 2014-07-13 23:41:38 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:38 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:38 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:38 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:38 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:38 --> Session routines successfully run
ERROR - 2014-07-13 23:41:38 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:38 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:38 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:38 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:38 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:38 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:39 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:39 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:39 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:39 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:39 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:41:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:41:39 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:41:39 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:39 --> Total execution time: 0.0783
DEBUG - 2014-07-13 23:41:50 --> Config Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:41:50 --> URI Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Router Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Output Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Security Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Input Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:41:50 --> Language Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Loader Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:41:50 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:41:50 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Session Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:41:50 --> Session routines successfully run
ERROR - 2014-07-13 23:41:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:41:50 --> Email Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:41:50 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:41:50 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:41:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Controller Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:41:50 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:41:50 --> Pagination Class Initialized
ERROR - 2014-07-13 23:41:50 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:41:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:41:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:41:50 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:41:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:41:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:41:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:41:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:41:50 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:41:50 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:41:50 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:41:50 --> Final output sent to browser
DEBUG - 2014-07-13 23:41:50 --> Total execution time: 0.0851
DEBUG - 2014-07-13 23:45:34 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:34 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:34 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:34 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:34 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:34 --> Session routines successfully run
ERROR - 2014-07-13 23:45:34 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:34 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:34 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:34 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:34 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:34 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:34 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:34 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:34 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:34 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:45:34 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:45:34 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:45:34 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:34 --> Total execution time: 0.1099
DEBUG - 2014-07-13 23:45:36 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:36 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:36 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:36 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:36 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:36 --> Session routines successfully run
ERROR - 2014-07-13 23:45:36 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:36 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:36 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:36 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:36 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:36 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:36 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:36 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:36 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:36 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:45:36 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:45:36 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:45:36 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:36 --> Total execution time: 0.1207
DEBUG - 2014-07-13 23:45:40 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:40 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:40 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:40 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:40 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:40 --> Session routines successfully run
ERROR - 2014-07-13 23:45:40 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:40 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:40 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:40 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:40 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:40 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:40 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:40 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:40 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:45:40 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:45:40 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:45:40 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:45:40 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:40 --> Total execution time: 0.1050
DEBUG - 2014-07-13 23:45:41 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:41 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:41 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:41 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:41 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:41 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:41 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:41 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:41 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:41 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:41 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:41 --> Session routines successfully run
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:41 --> Loader Class Initialized
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:41 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:41 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:41 --> Session routines successfully run
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Database Driver Class Initialized
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:41 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:41 --> Session routines successfully run
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:41 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:41 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:41 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:41 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:41 --> Total execution time: 0.1036
DEBUG - 2014-07-13 23:45:41 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:41 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:41 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:41 --> Total execution time: 0.1327
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:41 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:41 --> Total execution time: 0.1097
DEBUG - 2014-07-13 23:45:41 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:41 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:41 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:41 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:41 --> Database Driver Class Initialized
ERROR - 2014-07-13 23:45:42 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-13 23:45:43 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:43 --> Session routines successfully run
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:43 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:43 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:43 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:43 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:43 --> Total execution time: 1.2185
DEBUG - 2014-07-13 23:45:43 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:43 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:43 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:43 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:43 --> Session routines successfully run
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:43 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:43 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:43 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:43 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:43 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:45:43 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:45:43 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:45:43 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:43 --> Total execution time: 0.0890
DEBUG - 2014-07-13 23:45:50 --> Config Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:45:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:45:50 --> URI Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Router Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Output Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Security Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Input Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:45:50 --> Language Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Loader Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:45:50 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:45:50 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Session Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:45:50 --> Session routines successfully run
ERROR - 2014-07-13 23:45:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:45:50 --> Email Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:45:50 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:45:50 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:45:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:45:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Controller Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:45:50 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:45:50 --> Pagination Class Initialized
ERROR - 2014-07-13 23:45:50 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:45:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:45:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:45:50 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:45:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:45:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:45:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:45:50 --> XSS Filtering completed
DEBUG - 2014-07-13 23:45:50 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:45:50 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:45:50 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:45:50 --> Final output sent to browser
DEBUG - 2014-07-13 23:45:50 --> Total execution time: 0.1805
DEBUG - 2014-07-13 23:46:00 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:00 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:00 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:00 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:00 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:00 --> Session routines successfully run
ERROR - 2014-07-13 23:46:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:00 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:00 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:00 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:00 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:00 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:00 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:00 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:46:00 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:46:00 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:46:00 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:00 --> Total execution time: 0.1041
DEBUG - 2014-07-13 23:46:43 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:43 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:43 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:43 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:43 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:43 --> Session routines successfully run
ERROR - 2014-07-13 23:46:43 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:43 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:43 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:43 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:43 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:43 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:43 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:43 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:43 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:46:43 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:46:43 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-13 23:46:43 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:43 --> Total execution time: 0.1018
DEBUG - 2014-07-13 23:46:45 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:45 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:45 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:45 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:45 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:45 --> Session routines successfully run
ERROR - 2014-07-13 23:46:45 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:45 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:45 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:45 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:45 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:45 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:45 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:45 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:45 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:45 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:45 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:46:45 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:46:45 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:46:45 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:46:45 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:45 --> Total execution time: 0.0963
DEBUG - 2014-07-13 23:46:47 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:47 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:47 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:47 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:47 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:47 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:47 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:47 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:47 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:47 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:47 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:47 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:47 --> Language Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Loader Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:47 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:47 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:47 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:47 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:47 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:47 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:47 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> UTF-8 Support Enabled
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:47 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:47 --> Total execution time: 0.1121
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:47 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:47 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:47 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:47 --> Session routines successfully run
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:47 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:47 --> Total execution time: 0.1780
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:47 --> Total execution time: 0.1863
DEBUG - 2014-07-13 23:46:47 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:47 --> Total execution time: 0.1804
DEBUG - 2014-07-13 23:46:47 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:47 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:47 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:47 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:47 --> Session routines successfully run
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:47 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:47 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:47 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:47 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:46:47 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-07-13 23:46:47 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:46:47 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-07-13 23:46:47 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:47 --> Total execution time: 0.1088
DEBUG - 2014-07-13 23:46:49 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:49 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:49 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:49 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:49 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:49 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:49 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:49 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:49 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:49 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:49 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:49 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:49 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:49 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:49 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:49 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: form_helper
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:49 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:49 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:49 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session routines successfully run
DEBUG - 2014-07-13 23:46:49 --> Form Validation Class Initialized
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:49 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:49 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:49 --> Total execution time: 0.1234
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:49 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:49 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Form Validation Class Initialized
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Pagination Class Initialized
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:49 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:49 --> Total execution time: 0.1499
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:49 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:49 --> Total execution time: 0.1452
DEBUG - 2014-07-13 23:46:49 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:49 --> Total execution time: 0.1336
DEBUG - 2014-07-13 23:46:50 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:50 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:50 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:50 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:50 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:50 --> Session routines successfully run
ERROR - 2014-07-13 23:46:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:50 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:50 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:50 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:50 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:50 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:50 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:50 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:46:50 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:46:50 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:46:50 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:50 --> Total execution time: 0.0774
DEBUG - 2014-07-13 23:46:58 --> Config Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Hooks Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Utf8 Class Initialized
DEBUG - 2014-07-13 23:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-13 23:46:58 --> URI Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Router Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Output Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Security Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Input Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-13 23:46:58 --> Language Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Loader Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Helper loaded: url_helper
DEBUG - 2014-07-13 23:46:58 --> Helper loaded: form_helper
DEBUG - 2014-07-13 23:46:58 --> Database Driver Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Session Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Helper loaded: string_helper
DEBUG - 2014-07-13 23:46:58 --> Session routines successfully run
ERROR - 2014-07-13 23:46:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-13 23:46:58 --> Email Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-13 23:46:58 --> Helper loaded: cookie_helper
DEBUG - 2014-07-13 23:46:58 --> Helper loaded: language_helper
DEBUG - 2014-07-13 23:46:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Helper loaded: date_helper
DEBUG - 2014-07-13 23:46:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Model Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Controller Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-13 23:46:58 --> Form Validation Class Initialized
DEBUG - 2014-07-13 23:46:58 --> Pagination Class Initialized
ERROR - 2014-07-13 23:46:58 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-13 23:46:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-13 23:46:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-13 23:46:58 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-07-13 23:46:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:46:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:46:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:46:58 --> XSS Filtering completed
DEBUG - 2014-07-13 23:46:58 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-13 23:46:58 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-13 23:46:58 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-07-13 23:46:58 --> Final output sent to browser
DEBUG - 2014-07-13 23:46:58 --> Total execution time: 0.1816
