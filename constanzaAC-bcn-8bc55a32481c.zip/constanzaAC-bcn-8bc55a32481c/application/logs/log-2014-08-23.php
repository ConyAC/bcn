<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-23 06:21:32 --> Config Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Hooks Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Utf8 Class Initialized
DEBUG - 2014-08-23 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-23 06:21:32 --> URI Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Router Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Output Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Security Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Input Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-23 06:21:32 --> Language Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Loader Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Helper loaded: url_helper
DEBUG - 2014-08-23 06:21:32 --> Helper loaded: form_helper
DEBUG - 2014-08-23 06:21:32 --> Database Driver Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Session Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Helper loaded: string_helper
DEBUG - 2014-08-23 06:21:32 --> Session routines successfully run
ERROR - 2014-08-23 06:21:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-08-23 06:21:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-08-23 06:21:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-08-23 06:21:32 --> Email Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-08-23 06:21:32 --> Helper loaded: cookie_helper
DEBUG - 2014-08-23 06:21:32 --> Helper loaded: language_helper
DEBUG - 2014-08-23 06:21:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-23 06:21:32 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Helper loaded: date_helper
DEBUG - 2014-08-23 06:21:32 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Controller Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-08-23 06:21:32 --> Form Validation Class Initialized
DEBUG - 2014-08-23 06:21:32 --> Pagination Class Initialized
ERROR - 2014-08-23 06:21:32 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-08-23 06:21:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-08-23 06:21:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-08-23 06:21:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-08-23 06:21:32 --> File loaded: application/views/includes/modals_product.php
DEBUG - 2014-08-23 06:21:32 --> File loaded: application/views/pages/js/allocate_prod.php
DEBUG - 2014-08-23 06:21:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-08-23 06:21:32 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-08-23 06:21:32 --> Final output sent to browser
DEBUG - 2014-08-23 06:21:32 --> Total execution time: 0.1862
DEBUG - 2014-08-23 06:21:38 --> Config Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Hooks Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Utf8 Class Initialized
DEBUG - 2014-08-23 06:21:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-23 06:21:38 --> URI Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Router Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Output Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Security Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Input Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-23 06:21:38 --> Language Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Loader Class Initialized
DEBUG - 2014-08-23 06:21:38 --> Helper loaded: url_helper
DEBUG - 2014-08-23 06:21:38 --> Helper loaded: form_helper
DEBUG - 2014-08-23 06:21:38 --> Database Driver Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Session Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Helper loaded: string_helper
DEBUG - 2014-08-23 06:21:39 --> Session routines successfully run
ERROR - 2014-08-23 06:21:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-08-23 06:21:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-08-23 06:21:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-08-23 06:21:39 --> Email Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-08-23 06:21:39 --> Helper loaded: cookie_helper
DEBUG - 2014-08-23 06:21:39 --> Helper loaded: language_helper
DEBUG - 2014-08-23 06:21:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-23 06:21:39 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Helper loaded: date_helper
DEBUG - 2014-08-23 06:21:39 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Model Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Controller Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-08-23 06:21:39 --> Form Validation Class Initialized
DEBUG - 2014-08-23 06:21:39 --> Pagination Class Initialized
ERROR - 2014-08-23 06:21:39 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-08-23 06:21:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-08-23 06:21:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-08-23 06:21:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-08-23 06:21:39 --> File loaded: application/views/includes/modals_product.php
DEBUG - 2014-08-23 06:21:39 --> File loaded: application/views/pages/js/allocate_prod.php
DEBUG - 2014-08-23 06:21:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-08-23 06:21:39 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-08-23 06:21:39 --> Final output sent to browser
DEBUG - 2014-08-23 06:21:39 --> Total execution time: 1.1338
DEBUG - 2014-08-23 06:22:17 --> Config Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Hooks Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Utf8 Class Initialized
DEBUG - 2014-08-23 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-23 06:22:17 --> URI Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Router Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Output Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Security Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Input Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-23 06:22:17 --> Language Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Loader Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Helper loaded: url_helper
DEBUG - 2014-08-23 06:22:17 --> Helper loaded: form_helper
DEBUG - 2014-08-23 06:22:17 --> Database Driver Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Session Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Helper loaded: string_helper
DEBUG - 2014-08-23 06:22:17 --> Session routines successfully run
ERROR - 2014-08-23 06:22:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-08-23 06:22:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-08-23 06:22:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-08-23 06:22:17 --> Email Class Initialized
DEBUG - 2014-08-23 06:22:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-08-23 06:22:17 --> Helper loaded: cookie_helper
DEBUG - 2014-08-23 06:22:17 --> Helper loaded: language_helper
DEBUG - 2014-08-23 06:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-08-23 06:22:17 --> Model Class Initialized
DEBUG - 2014-08-23 06:22:18 --> Model Class Initialized
DEBUG - 2014-08-23 06:22:18 --> Helper loaded: date_helper
DEBUG - 2014-08-23 06:22:18 --> Model Class Initialized
DEBUG - 2014-08-23 06:22:18 --> Model Class Initialized
DEBUG - 2014-08-23 06:22:18 --> Controller Class Initialized
DEBUG - 2014-08-23 06:22:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-08-23 06:22:18 --> Form Validation Class Initialized
DEBUG - 2014-08-23 06:22:18 --> Pagination Class Initialized
ERROR - 2014-08-23 06:22:18 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-08-23 06:22:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-08-23 06:22:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-08-23 06:22:18 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-08-23 06:22:18 --> File loaded: application/views/includes/modals_product.php
DEBUG - 2014-08-23 06:22:18 --> File loaded: application/views/pages/js/allocate_prod.php
DEBUG - 2014-08-23 06:22:18 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-08-23 06:22:18 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-08-23 06:22:18 --> Final output sent to browser
DEBUG - 2014-08-23 06:22:18 --> Total execution time: 0.0890
