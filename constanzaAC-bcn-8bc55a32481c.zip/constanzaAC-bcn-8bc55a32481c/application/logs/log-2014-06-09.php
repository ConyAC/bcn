<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-09 00:00:26 --> Config Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:00:26 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:00:26 --> URI Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Router Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Output Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Security Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Input Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:00:26 --> Language Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Loader Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:00:26 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:00:26 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Session Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:00:26 --> Session routines successfully run
ERROR - 2014-06-09 00:00:26 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:00:26 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:00:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:00:26 --> Email Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:00:26 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:00:26 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:00:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:00:26 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:00:26 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Controller Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:00:26 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:00:26 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:00:26 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:00:26 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:00:26 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:00:26 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:00:26 --> Final output sent to browser
DEBUG - 2014-06-09 00:00:26 --> Total execution time: 0.0831
DEBUG - 2014-06-09 00:00:50 --> Config Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:00:50 --> URI Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Router Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Output Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Security Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Input Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:00:50 --> Language Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Loader Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:00:50 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:00:50 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Session Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:00:50 --> Session routines successfully run
ERROR - 2014-06-09 00:00:50 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:00:50 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:00:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:00:50 --> Email Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:00:50 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:00:50 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:00:50 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:00:50 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Controller Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:00:50 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:00:50 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:00:50 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:00:50 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:00:50 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:00:50 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:00:50 --> Final output sent to browser
DEBUG - 2014-06-09 00:00:50 --> Total execution time: 0.0895
DEBUG - 2014-06-09 00:00:59 --> Config Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:00:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:00:59 --> URI Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Router Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Output Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Security Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Input Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:00:59 --> Language Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Loader Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:00:59 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:00:59 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Session Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:00:59 --> Session routines successfully run
ERROR - 2014-06-09 00:00:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:00:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:00:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:00:59 --> Email Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:00:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:00:59 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:00:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:00:59 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:00:59 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Model Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Controller Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:00:59 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:00:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:00:59 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:00:59 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:00:59 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:00:59 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:00:59 --> Final output sent to browser
DEBUG - 2014-06-09 00:00:59 --> Total execution time: 0.1007
DEBUG - 2014-06-09 00:01:06 --> Config Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:01:06 --> URI Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Router Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Output Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Security Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Input Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:01:06 --> Language Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Loader Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:01:06 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:01:06 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Session Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:01:06 --> Session routines successfully run
ERROR - 2014-06-09 00:01:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:01:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:01:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:01:06 --> Email Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:01:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:01:06 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:01:06 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:01:06 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Controller Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:01:06 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:01:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:01:06 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:01:06 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:01:06 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:01:06 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:01:06 --> Final output sent to browser
DEBUG - 2014-06-09 00:01:06 --> Total execution time: 0.1108
DEBUG - 2014-06-09 00:01:16 --> Config Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:01:16 --> URI Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Router Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Output Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Security Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Input Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:01:16 --> Language Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Loader Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:01:16 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:01:16 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Session Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:01:16 --> Session routines successfully run
ERROR - 2014-06-09 00:01:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:01:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:01:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:01:16 --> Email Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:01:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:01:16 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:01:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:01:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:01:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Controller Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:01:16 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:01:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:01:16 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:01:17 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:01:17 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:01:17 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:01:17 --> Final output sent to browser
DEBUG - 2014-06-09 00:01:17 --> Total execution time: 0.0926
DEBUG - 2014-06-09 00:01:32 --> Config Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:01:32 --> URI Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Router Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Output Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Security Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Input Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:01:32 --> Language Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Loader Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:01:32 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:01:32 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Session Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:01:32 --> Session routines successfully run
ERROR - 2014-06-09 00:01:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:01:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:01:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:01:32 --> Email Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:01:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:01:32 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:01:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:01:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Controller Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:01:32 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:01:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:01:32 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:01:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:01:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:01:32 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:01:32 --> Final output sent to browser
DEBUG - 2014-06-09 00:01:32 --> Total execution time: 0.0788
DEBUG - 2014-06-09 00:02:07 --> Config Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:02:07 --> URI Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Router Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Output Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Security Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Input Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:02:07 --> Language Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Loader Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:02:07 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:02:07 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Session Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:02:07 --> Session routines successfully run
ERROR - 2014-06-09 00:02:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:02:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:02:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:02:07 --> Email Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:02:07 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:02:07 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:02:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:02:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:02:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Controller Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:02:07 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:02:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:02:07 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:02:07 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:02:07 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:02:07 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:02:07 --> Final output sent to browser
DEBUG - 2014-06-09 00:02:07 --> Total execution time: 0.0852
DEBUG - 2014-06-09 00:02:38 --> Config Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:02:38 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:02:38 --> URI Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Router Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Output Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Security Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Input Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:02:38 --> Language Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Loader Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:02:38 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:02:38 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Session Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:02:38 --> Session routines successfully run
ERROR - 2014-06-09 00:02:38 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:02:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:02:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:02:38 --> Email Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:02:38 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:02:38 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:02:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:02:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Controller Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:02:38 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:02:38 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:02:38 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:02:38 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:02:38 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:02:38 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:02:38 --> Final output sent to browser
DEBUG - 2014-06-09 00:02:38 --> Total execution time: 0.0767
DEBUG - 2014-06-09 00:04:09 --> Config Class Initialized
DEBUG - 2014-06-09 00:04:09 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:04:09 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:04:09 --> URI Class Initialized
DEBUG - 2014-06-09 00:04:09 --> Router Class Initialized
DEBUG - 2014-06-09 00:04:09 --> Output Class Initialized
DEBUG - 2014-06-09 00:04:09 --> Security Class Initialized
DEBUG - 2014-06-09 00:04:09 --> Input Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:04:10 --> Language Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Loader Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:04:10 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:04:10 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Session Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:04:10 --> Session routines successfully run
ERROR - 2014-06-09 00:04:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:04:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:04:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:04:10 --> Email Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:04:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:04:10 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:04:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:04:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:04:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Controller Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:04:10 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:04:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:04:10 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:04:10 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:04:10 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:04:10 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:04:10 --> Final output sent to browser
DEBUG - 2014-06-09 00:04:10 --> Total execution time: 0.0800
DEBUG - 2014-06-09 00:05:32 --> Config Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:05:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:05:32 --> URI Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Router Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Output Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Security Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Input Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:05:32 --> Language Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Loader Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:05:32 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:05:32 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Session Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:05:32 --> Session routines successfully run
ERROR - 2014-06-09 00:05:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:05:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:05:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:05:32 --> Email Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:05:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:05:32 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:05:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:05:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Controller Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:05:32 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:05:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:05:32 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:05:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:05:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:05:32 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:05:32 --> Final output sent to browser
DEBUG - 2014-06-09 00:05:32 --> Total execution time: 0.0900
DEBUG - 2014-06-09 00:05:55 --> Config Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:05:55 --> URI Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Router Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Output Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Security Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Input Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:05:55 --> Language Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Loader Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:05:55 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:05:55 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Session Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:05:55 --> Session routines successfully run
ERROR - 2014-06-09 00:05:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:05:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:05:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:05:55 --> Email Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:05:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:05:55 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:05:55 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:05:55 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Model Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Controller Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:05:55 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:05:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:05:55 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:05:55 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:05:55 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:05:55 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:05:55 --> Final output sent to browser
DEBUG - 2014-06-09 00:05:55 --> Total execution time: 0.0869
DEBUG - 2014-06-09 00:42:03 --> Config Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:42:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:42:03 --> URI Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Router Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Output Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Security Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Input Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:42:03 --> Language Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Loader Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:42:03 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:42:03 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Session Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:42:03 --> Session routines successfully run
ERROR - 2014-06-09 00:42:03 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:42:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:42:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:42:03 --> Email Class Initialized
DEBUG - 2014-06-09 00:42:03 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:42:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:42:04 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:42:04 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:04 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:04 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:42:04 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:04 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:04 --> Controller Class Initialized
DEBUG - 2014-06-09 00:42:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:42:04 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:42:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:42:04 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:42:04 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:42:04 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:42:04 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:42:04 --> Final output sent to browser
DEBUG - 2014-06-09 00:42:04 --> Total execution time: 0.0841
DEBUG - 2014-06-09 00:42:13 --> Config Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:42:13 --> URI Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Router Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Output Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Security Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Input Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:42:13 --> Language Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Loader Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:42:13 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:42:13 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Session Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:42:13 --> Session routines successfully run
ERROR - 2014-06-09 00:42:13 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:42:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:42:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:42:13 --> Email Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:42:13 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:42:13 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:42:13 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:42:13 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Controller Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:42:13 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:42:13 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:42:13 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:42:13 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:42:13 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:42:13 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:42:13 --> Final output sent to browser
DEBUG - 2014-06-09 00:42:13 --> Total execution time: 0.0918
DEBUG - 2014-06-09 00:42:32 --> Config Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:42:32 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:42:32 --> URI Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Router Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Output Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Security Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Input Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:42:32 --> Language Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Loader Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:42:32 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:42:32 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Session Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:42:32 --> Session routines successfully run
ERROR - 2014-06-09 00:42:32 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:42:32 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:42:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:42:32 --> Email Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:42:32 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:42:32 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:42:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:42:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Model Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Controller Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:42:32 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:42:32 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:42:32 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:42:32 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:42:32 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:42:32 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:42:32 --> Final output sent to browser
DEBUG - 2014-06-09 00:42:32 --> Total execution time: 0.0827
DEBUG - 2014-06-09 00:44:09 --> Config Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:44:09 --> URI Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Router Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Output Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Security Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Input Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:44:09 --> Language Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Loader Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:44:09 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:44:09 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Session Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:44:09 --> Session routines successfully run
ERROR - 2014-06-09 00:44:09 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:44:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:44:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:44:09 --> Email Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:44:09 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:44:09 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:44:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:44:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:44:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Controller Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:44:09 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:44:09 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:44:09 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:44:09 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:44:09 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:44:09 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:44:09 --> Final output sent to browser
DEBUG - 2014-06-09 00:44:09 --> Total execution time: 0.0810
DEBUG - 2014-06-09 00:45:38 --> Config Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:45:38 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:45:38 --> URI Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Router Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Output Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Security Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Input Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:45:38 --> Language Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Loader Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:45:38 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:45:38 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Session Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:45:38 --> Session routines successfully run
ERROR - 2014-06-09 00:45:38 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:45:38 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:45:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:45:38 --> Email Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:45:38 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:45:38 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:45:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:45:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:45:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Model Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Controller Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:45:38 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:45:38 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:45:38 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:45:38 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:45:38 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:45:38 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:45:38 --> Final output sent to browser
DEBUG - 2014-06-09 00:45:38 --> Total execution time: 0.0789
DEBUG - 2014-06-09 00:46:05 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:05 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:05 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:05 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:05 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:05 --> Session routines successfully run
ERROR - 2014-06-09 00:46:05 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:05 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:05 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:05 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:05 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:05 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:05 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:05 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:05 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:46:05 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:46:07 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:07 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:07 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:07 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:07 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:07 --> Session routines successfully run
ERROR - 2014-06-09 00:46:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:07 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:07 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:07 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:07 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:07 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:46:07 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:46:07 --> File loaded: application/views/auth/index.php
DEBUG - 2014-06-09 00:46:07 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:07 --> Total execution time: 0.1217
DEBUG - 2014-06-09 00:46:09 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:09 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:09 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:09 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:09 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:09 --> Session routines successfully run
ERROR - 2014-06-09 00:46:09 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:09 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:09 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:09 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:09 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:09 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:09 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:46:09 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:46:09 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:46:09 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-06-09 00:46:09 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:09 --> Total execution time: 0.0804
DEBUG - 2014-06-09 00:46:10 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:10 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:10 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:10 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:10 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:10 --> Session routines successfully run
ERROR - 2014-06-09 00:46:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:10 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:10 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:10 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:10 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:46:10 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:46:10 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-09 00:46:10 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:46:10 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-09 00:46:10 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:10 --> Total execution time: 0.1124
DEBUG - 2014-06-09 00:46:11 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:11 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:11 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:11 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:11 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:11 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:11 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:11 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:11 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Config Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:46:11 --> URI Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Router Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:11 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Output Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:11 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Session routines successfully run
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:11 --> Session routines successfully run
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: url_helper
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:11 --> Security Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Input Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:46:11 --> Language Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:11 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Loader Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:46:11 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Session Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Session routines successfully run
DEBUG - 2014-06-09 00:46:11 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Session Class Initialized
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: string_helper
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:11 --> Session routines successfully run
DEBUG - 2014-06-09 00:46:11 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:46:11 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:46:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:46:11 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:11 --> Total execution time: 0.1235
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Email Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:46:11 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:11 --> Total execution time: 0.1365
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Model Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Controller Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:46:11 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:11 --> Total execution time: 0.1348
DEBUG - 2014-06-09 00:46:11 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:46:11 --> Final output sent to browser
DEBUG - 2014-06-09 00:46:11 --> Total execution time: 0.1264
DEBUG - 2014-06-09 00:49:16 --> Config Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:49:16 --> URI Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Router Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Output Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Security Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Input Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:49:16 --> Language Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Loader Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:49:16 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:49:16 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Session Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:49:16 --> Session routines successfully run
ERROR - 2014-06-09 00:49:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:49:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:49:16 --> Email Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:49:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:49:16 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:49:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Controller Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:16 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:49:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:49:16 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:49:16 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:49:16 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:49:16 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 00:49:16 --> Final output sent to browser
DEBUG - 2014-06-09 00:49:16 --> Total execution time: 0.0825
DEBUG - 2014-06-09 00:49:21 --> Config Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:49:21 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:49:21 --> URI Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Router Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Output Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Security Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Input Class Initialized
DEBUG - 2014-06-09 00:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:49:21 --> Language Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Loader Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:49:22 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Session Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:49:22 --> Session routines successfully run
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:49:22 --> Email Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Controller Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:49:22 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 00:49:22 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-09 00:49:22 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 00:49:22 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-09 00:49:22 --> Final output sent to browser
DEBUG - 2014-06-09 00:49:22 --> Total execution time: 0.1011
DEBUG - 2014-06-09 00:49:22 --> Config Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:49:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:49:22 --> URI Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Router Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Output Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Security Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Input Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:49:22 --> Language Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Loader Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:49:22 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Session Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:49:22 --> Session routines successfully run
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:22 --> Config Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:49:22 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:49:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:49:22 --> Config Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:49:22 --> URI Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Email Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Router Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:49:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:49:22 --> URI Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Output Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Router Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Security Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Output Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Input Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:49:22 --> Language Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Security Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Controller Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Input Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:49:22 --> Language Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Loader Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:49:22 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Final output sent to browser
DEBUG - 2014-06-09 00:49:22 --> Total execution time: 0.0705
DEBUG - 2014-06-09 00:49:22 --> Loader Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:49:22 --> Config Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Hooks Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Utf8 Class Initialized
DEBUG - 2014-06-09 00:49:22 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:49:22 --> URI Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Router Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Output Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Security Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Input Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 00:49:22 --> Language Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Loader Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: url_helper
DEBUG - 2014-06-09 00:49:22 --> Session Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Session Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: form_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:49:22 --> Session routines successfully run
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:49:22 --> Database Driver Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Session Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:49:22 --> Session routines successfully run
DEBUG - 2014-06-09 00:49:22 --> Email Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/ion_auth_lang.php
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:49:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: string_helper
DEBUG - 2014-06-09 00:49:22 --> Session routines successfully run
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Email Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: language_helper
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-09 00:49:22 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Controller Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Email Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: language_helper
DEBUG - 2014-06-09 00:49:22 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Controller Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Final output sent to browser
DEBUG - 2014-06-09 00:49:22 --> Total execution time: 0.1058
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Helper loaded: date_helper
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Final output sent to browser
DEBUG - 2014-06-09 00:49:22 --> Total execution time: 0.0994
DEBUG - 2014-06-09 00:49:22 --> Model Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Controller Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 00:49:22 --> Form Validation Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 00:49:22 --> Pagination Class Initialized
DEBUG - 2014-06-09 00:49:22 --> Final output sent to browser
DEBUG - 2014-06-09 00:49:22 --> Total execution time: 0.1196
DEBUG - 2014-06-09 01:01:58 --> Config Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:01:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 01:01:58 --> URI Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Router Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Output Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Security Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Input Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:01:58 --> Language Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Loader Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:01:58 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:01:58 --> Database Driver Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Session Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:01:58 --> Session routines successfully run
ERROR - 2014-06-09 01:01:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 01:01:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:01:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:01:58 --> Email Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:01:58 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:01:58 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:01:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:58 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:01:58 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Controller Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:58 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:01:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:01:58 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:01:58 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 01:01:58 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-09 01:01:59 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 01:01:59 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-09 01:01:59 --> Final output sent to browser
DEBUG - 2014-06-09 01:01:59 --> Total execution time: 0.0978
DEBUG - 2014-06-09 01:01:59 --> Config Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 01:01:59 --> URI Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Router Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Output Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Security Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Input Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:01:59 --> Language Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Loader Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:01:59 --> Database Driver Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Session Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:01:59 --> Config Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Session routines successfully run
DEBUG - 2014-06-09 01:01:59 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:01:59 --> UTF-8 Support Enabled
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:01:59 --> URI Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:01:59 --> Router Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Email Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Output Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> Security Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Input Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:01:59 --> Language Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Config Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:01:59 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Loader Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Config Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:01:59 --> URI Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 01:01:59 --> Controller Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:01:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> URI Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Router Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Router Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Output Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Final output sent to browser
DEBUG - 2014-06-09 01:01:59 --> Total execution time: 0.0709
DEBUG - 2014-06-09 01:01:59 --> Security Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Input Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:01:59 --> Database Driver Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Output Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Session Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Security Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:01:59 --> Session routines successfully run
DEBUG - 2014-06-09 01:01:59 --> Loader Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Input Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:01:59 --> Language Class Initialized
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:01:59 --> Loader Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:01:59 --> Email Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Database Driver Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Session Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:01:59 --> Session routines successfully run
DEBUG - 2014-06-09 01:01:59 --> Database Driver Class Initialized
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:01:59 --> Session Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:01:59 --> Session routines successfully run
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:01:59 --> Email Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:01:59 --> Controller Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:01:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
ERROR - 2014-06-09 01:01:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:01:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:01:59 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Email Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Controller Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> Final output sent to browser
DEBUG - 2014-06-09 01:01:59 --> Total execution time: 0.1003
DEBUG - 2014-06-09 01:01:59 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Final output sent to browser
DEBUG - 2014-06-09 01:01:59 --> Total execution time: 0.0904
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Model Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Controller Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:01:59 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:01:59 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:01:59 --> Final output sent to browser
DEBUG - 2014-06-09 01:01:59 --> Total execution time: 0.1201
DEBUG - 2014-06-09 01:03:00 --> Config Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:03:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 01:03:00 --> URI Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Router Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Output Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Security Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Input Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:03:00 --> Language Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Loader Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:03:00 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:03:00 --> Database Driver Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Session Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:03:00 --> Session routines successfully run
ERROR - 2014-06-09 01:03:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 01:03:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:03:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:03:00 --> Email Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:03:00 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:03:00 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:03:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:03:00 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:03:00 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Controller Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:03:00 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:03:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:03:00 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:03:00 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-09 01:03:00 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-09 01:03:00 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-09 01:03:00 --> Final output sent to browser
DEBUG - 2014-06-09 01:03:00 --> Total execution time: 0.0890
DEBUG - 2014-06-09 01:03:04 --> Config Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Hooks Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Utf8 Class Initialized
DEBUG - 2014-06-09 01:03:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-09 01:03:04 --> URI Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Router Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Output Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Security Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Input Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-09 01:03:04 --> Language Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Loader Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Helper loaded: url_helper
DEBUG - 2014-06-09 01:03:04 --> Helper loaded: form_helper
DEBUG - 2014-06-09 01:03:04 --> Database Driver Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Session Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Helper loaded: string_helper
DEBUG - 2014-06-09 01:03:04 --> Session routines successfully run
ERROR - 2014-06-09 01:03:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-09 01:03:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-09 01:03:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-09 01:03:04 --> Email Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-09 01:03:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-09 01:03:04 --> Helper loaded: language_helper
DEBUG - 2014-06-09 01:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:03:04 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Helper loaded: date_helper
DEBUG - 2014-06-09 01:03:04 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Model Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Controller Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-09 01:03:04 --> Form Validation Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-09 01:03:04 --> Pagination Class Initialized
DEBUG - 2014-06-09 01:03:04 --> Final output sent to browser
DEBUG - 2014-06-09 01:03:04 --> Total execution time: 0.3826
