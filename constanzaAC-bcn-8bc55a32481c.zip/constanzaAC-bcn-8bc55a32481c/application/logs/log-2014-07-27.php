<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-27 02:06:30 --> Config Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Hooks Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Utf8 Class Initialized
DEBUG - 2014-07-27 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-27 02:06:30 --> URI Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Router Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Output Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Security Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Input Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-27 02:06:30 --> Language Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Loader Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Helper loaded: url_helper
DEBUG - 2014-07-27 02:06:30 --> Helper loaded: form_helper
DEBUG - 2014-07-27 02:06:30 --> Database Driver Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Session Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Helper loaded: string_helper
DEBUG - 2014-07-27 02:06:30 --> Session routines successfully run
ERROR - 2014-07-27 02:06:30 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-27 02:06:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-27 02:06:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-07-27 02:06:30 --> Email Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-07-27 02:06:30 --> Helper loaded: cookie_helper
DEBUG - 2014-07-27 02:06:30 --> Helper loaded: language_helper
DEBUG - 2014-07-27 02:06:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 02:06:30 --> Model Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Model Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Helper loaded: date_helper
DEBUG - 2014-07-27 02:06:30 --> Model Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Model Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Controller Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-07-27 02:06:30 --> Form Validation Class Initialized
DEBUG - 2014-07-27 02:06:30 --> Pagination Class Initialized
ERROR - 2014-07-27 02:06:30 --> Severity: Warning  --> include_once(application/core/LanguageLoader.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
ERROR - 2014-07-27 02:06:30 --> Severity: Warning  --> include_once(): Failed opening 'application/core/LanguageLoader.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 400
DEBUG - 2014-07-27 02:06:30 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-07-27 02:06:30 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-07-27 02:06:30 --> File loaded: application/views/includes/modals_product.php
DEBUG - 2014-07-27 02:06:30 --> File loaded: application/views/pages/js/allocate_prod.php
DEBUG - 2014-07-27 02:06:30 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-07-27 02:06:30 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-07-27 02:06:30 --> Final output sent to browser
DEBUG - 2014-07-27 02:06:30 --> Total execution time: 0.2215
