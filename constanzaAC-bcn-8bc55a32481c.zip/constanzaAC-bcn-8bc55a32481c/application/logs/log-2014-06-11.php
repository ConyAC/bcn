<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-11 03:32:09 --> Config Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:32:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:32:09 --> URI Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Router Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Output Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Security Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Input Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:32:09 --> Language Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Loader Class Initialized
DEBUG - 2014-06-11 03:32:09 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:32:09 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:32:10 --> Database Driver Class Initialized
ERROR - 2014-06-11 03:32:10 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 03:32:13 --> Session Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:32:13 --> A session cookie was not found.
DEBUG - 2014-06-11 03:32:13 --> Session routines successfully run
ERROR - 2014-06-11 03:32:13 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:32:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:32:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:32:13 --> Email Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:32:13 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:32:13 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:32:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:13 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:32:13 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Controller Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:13 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:32:13 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:32:13 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Config Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:32:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:32:14 --> URI Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Router Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Output Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Security Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Input Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:32:14 --> Language Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Loader Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:32:14 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Session Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:32:14 --> Session routines successfully run
ERROR - 2014-06-11 03:32:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:32:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:32:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:32:14 --> Email Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Controller Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:14 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:32:14 --> Config Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:32:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:32:14 --> URI Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Router Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Output Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Security Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Input Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:32:14 --> Language Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Loader Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:32:14 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Session Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:32:14 --> Session routines successfully run
ERROR - 2014-06-11 03:32:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:32:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:32:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:32:14 --> Email Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Controller Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:14 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:32:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:32:14 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:32:14 --> File loaded: application/views/auth/login.php
DEBUG - 2014-06-11 03:32:14 --> Final output sent to browser
DEBUG - 2014-06-11 03:32:14 --> Total execution time: 0.0679
DEBUG - 2014-06-11 03:32:27 --> Config Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:32:27 --> URI Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Router Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Output Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Security Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Input Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:32:27 --> Language Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Loader Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:32:27 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:32:27 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Session Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:32:27 --> Session routines successfully run
ERROR - 2014-06-11 03:32:27 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:32:27 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:32:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:32:27 --> Email Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:32:27 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:32:27 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:27 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:32:27 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Controller Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:27 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:32:27 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:32:27 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-06-11 03:32:28 --> Config Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:32:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:32:28 --> URI Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Router Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Output Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Security Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Input Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:32:28 --> Language Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Loader Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:32:28 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:32:28 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Session Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:32:28 --> Session routines successfully run
ERROR - 2014-06-11 03:32:28 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:32:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:32:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:32:28 --> Email Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:32:28 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:32:28 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:32:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Controller Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:32:28 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:32:28 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:32:28 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:32:28 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:33:58 --> Config Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:33:58 --> URI Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Router Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Output Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Security Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Input Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:33:58 --> Language Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Loader Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:33:58 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:33:58 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Session Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:33:58 --> Session routines successfully run
ERROR - 2014-06-11 03:33:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:33:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:33:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:33:58 --> Email Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:33:58 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:33:58 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:33:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:33:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Controller Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:33:58 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:33:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:33:58 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:33:58 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:33:58 --> File loaded: application/views/auth/index.php
DEBUG - 2014-06-11 03:33:58 --> Final output sent to browser
DEBUG - 2014-06-11 03:33:58 --> Total execution time: 0.0983
DEBUG - 2014-06-11 03:34:01 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:34:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:34:01 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:01 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:34:01 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:01 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:01 --> Session routines successfully run
ERROR - 2014-06-11 03:34:01 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:34:01 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:01 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:01 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:01 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:34:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:01 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:01 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:01 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:01 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:34:01 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:34:01 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:34:01 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:34:01 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-06-11 03:34:01 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:01 --> Total execution time: 0.0915
DEBUG - 2014-06-11 03:34:03 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:34:03 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:03 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:03 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:03 --> Session routines successfully run
ERROR - 2014-06-11 03:34:03 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:34:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:03 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:03 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:34:03 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:34:03 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:34:03 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-11 03:34:03 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:34:03 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-11 03:34:03 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:03 --> Total execution time: 0.1061
DEBUG - 2014-06-11 03:34:03 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:34:03 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:03 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:03 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:34:03 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:03 --> Session routines successfully run
DEBUG - 2014-06-11 03:34:03 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Utf8 Class Initialized
ERROR - 2014-06-11 03:34:03 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:03 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:03 --> UTF-8 Support Enabled
ERROR - 2014-06-11 03:34:03 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:03 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:03 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:03 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:34:03 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:03 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:03 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:34:03 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:03 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:34:03 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Database Driver Class Initialized
ERROR - 2014-06-11 03:34:03 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 03:34:03 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:03 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:03 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:34:03 --> Total execution time: 0.1255
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: url_helper
ERROR - 2014-06-11 03:34:03 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 03:34:03 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:03 --> Database Driver Class Initialized
ERROR - 2014-06-11 03:34:03 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 03:34:04 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:04 --> Session routines successfully run
ERROR - 2014-06-11 03:34:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:04 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:04 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:04 --> Session routines successfully run
DEBUG - 2014-06-11 03:34:04 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-06-11 03:34:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:04 --> Pagination Class Initialized
ERROR - 2014-06-11 03:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:04 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:04 --> Session routines successfully run
DEBUG - 2014-06-11 03:34:04 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: language_helper
ERROR - 2014-06-11 03:34:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:34:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:04 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:34:04 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:34:04 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:04 --> Total execution time: 1.2704
DEBUG - 2014-06-11 03:34:04 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:04 --> Total execution time: 1.2931
DEBUG - 2014-06-11 03:34:04 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:04 --> Total execution time: 1.2972
DEBUG - 2014-06-11 03:34:08 --> Config Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:34:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:34:08 --> URI Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Router Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Output Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Security Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Input Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:34:08 --> Language Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Loader Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:34:08 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:34:08 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Session Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:34:08 --> Session routines successfully run
ERROR - 2014-06-11 03:34:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:34:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:34:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:34:08 --> Email Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:34:08 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:34:08 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:34:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Controller Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:34:08 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:34:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:34:08 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:34:08 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:34:08 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:34:08 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 03:34:08 --> Final output sent to browser
DEBUG - 2014-06-11 03:34:08 --> Total execution time: 0.0802
DEBUG - 2014-06-11 03:35:39 --> Config Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:35:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:35:39 --> URI Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Router Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Output Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Security Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Input Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:35:39 --> Language Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Loader Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:35:39 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:35:39 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Session Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:35:39 --> Session routines successfully run
ERROR - 2014-06-11 03:35:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:35:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:35:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:35:39 --> Email Class Initialized
DEBUG - 2014-06-11 03:35:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:35:39 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:35:39 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:35:39 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Controller Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:35:40 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:35:40 --> Config Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:35:40 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:35:40 --> URI Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Router Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Output Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Security Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Input Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:35:40 --> Language Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Loader Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:35:40 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Session Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:35:40 --> Session routines successfully run
ERROR - 2014-06-11 03:35:40 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:35:40 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:35:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:35:40 --> Email Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Model Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Controller Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:35:40 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:35:40 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:35:40 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:35:40 --> File loaded: application/views/auth/login.php
DEBUG - 2014-06-11 03:35:40 --> Final output sent to browser
DEBUG - 2014-06-11 03:35:40 --> Total execution time: 0.0719
DEBUG - 2014-06-11 03:36:20 --> Config Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:36:20 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:36:20 --> URI Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Router Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Output Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Security Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Input Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:36:20 --> Language Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Loader Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:36:20 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:36:20 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Session Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:36:20 --> Session routines successfully run
ERROR - 2014-06-11 03:36:20 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:36:20 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:36:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:36:20 --> Email Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:36:20 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:36:20 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:36:20 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:36:20 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Controller Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:36:20 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:36:20 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:36:20 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-06-11 03:36:21 --> Config Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:36:21 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:36:21 --> URI Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Router Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Output Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Security Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Input Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:36:21 --> Language Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Loader Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:36:21 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:36:21 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Session Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:36:21 --> Session routines successfully run
ERROR - 2014-06-11 03:36:21 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:36:21 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:36:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:36:21 --> Email Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:36:21 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:36:21 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:36:21 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:36:21 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Model Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Controller Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:36:21 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:36:21 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:36:21 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:36:21 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:38:45 --> Config Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:38:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:38:45 --> URI Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Router Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Output Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Security Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Input Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:38:45 --> Language Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Loader Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:38:45 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:38:45 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Session Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:38:45 --> Session routines successfully run
ERROR - 2014-06-11 03:38:45 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:38:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:38:45 --> Email Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:38:45 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:38:45 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:38:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Controller Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:45 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:38:45 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:38:45 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:38:45 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:38:47 --> Config Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:38:47 --> URI Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Router Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Output Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Security Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Input Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:38:47 --> Language Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Loader Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:38:47 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Session Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:38:47 --> Session routines successfully run
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:38:47 --> Email Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Controller Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:38:47 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:38:47 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-11 03:38:47 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:38:47 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-11 03:38:47 --> Final output sent to browser
DEBUG - 2014-06-11 03:38:47 --> Total execution time: 0.1169
DEBUG - 2014-06-11 03:38:47 --> Config Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:38:47 --> URI Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Router Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Output Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Config Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Security Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Input Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:38:47 --> Language Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Config Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:38:47 --> URI Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Loader Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Router Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Output Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:38:47 --> Security Class Initialized
DEBUG - 2014-06-11 03:38:47 --> URI Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Input Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:38:47 --> Language Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Router Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:38:47 --> Loader Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:38:47 --> Config Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:38:47 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:38:47 --> Output Class Initialized
DEBUG - 2014-06-11 03:38:47 --> URI Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Security Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:38:47 --> Router Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Input Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:38:47 --> Output Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Security Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Input Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:38:47 --> Loader Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:38:47 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Session Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Loader Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:38:47 --> Session routines successfully run
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:38:47 --> Session Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:38:47 --> Session routines successfully run
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: form_helper
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:47 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:47 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Session Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Email Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:38:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:38:47 --> Session routines successfully run
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:47 --> Email Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:38:47 --> Email Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:38:47 --> Controller Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Session Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:38:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:38:47 --> Session routines successfully run
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Controller Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Final output sent to browser
DEBUG - 2014-06-11 03:38:47 --> Total execution time: 0.1303
DEBUG - 2014-06-11 03:38:47 --> Form Validation Class Initialized
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:38:47 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:38:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Controller Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Email Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:38:47 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Final output sent to browser
DEBUG - 2014-06-11 03:38:47 --> Final output sent to browser
DEBUG - 2014-06-11 03:38:47 --> Total execution time: 0.1311
DEBUG - 2014-06-11 03:38:47 --> Total execution time: 0.1434
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Model Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Controller Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:38:47 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:38:47 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:38:47 --> Final output sent to browser
DEBUG - 2014-06-11 03:38:47 --> Total execution time: 0.1331
DEBUG - 2014-06-11 03:41:10 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:10 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:10 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:10 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:10 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:10 --> Session routines successfully run
ERROR - 2014-06-11 03:41:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:10 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:10 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:10 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:10 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:41:10 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:10 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:41:10 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 03:41:10 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:10 --> Total execution time: 0.0822
DEBUG - 2014-06-11 03:41:49 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:49 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:49 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:49 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:49 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:49 --> Session routines successfully run
ERROR - 2014-06-11 03:41:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:49 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:49 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:49 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:49 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:49 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:49 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:49 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:41:51 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:51 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:51 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:51 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:51 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:51 --> Session routines successfully run
ERROR - 2014-06-11 03:41:51 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:51 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:51 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:51 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:51 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:51 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:51 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:51 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:51 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:51 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:51 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:41:51 --> File loaded: application/views/auth/index.php
DEBUG - 2014-06-11 03:41:51 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:51 --> Total execution time: 0.1921
DEBUG - 2014-06-11 03:41:53 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:53 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:53 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:53 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:53 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:53 --> Session routines successfully run
ERROR - 2014-06-11 03:41:53 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:53 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:53 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:53 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:53 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:53 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:53 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:53 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:53 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:41:53 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:53 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:41:53 --> File loaded: application/views/pages/admin_product.php
DEBUG - 2014-06-11 03:41:53 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:53 --> Total execution time: 0.0909
DEBUG - 2014-06-11 03:41:55 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:55 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:55 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:55 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:55 --> Session routines successfully run
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:55 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:41:55 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:55 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-11 03:41:55 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:41:55 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-11 03:41:55 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:55 --> Total execution time: 0.1139
DEBUG - 2014-06-11 03:41:55 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:55 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:55 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:55 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:55 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:55 --> Session routines successfully run
DEBUG - 2014-06-11 03:41:55 --> Security Class Initialized
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:55 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:55 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:55 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:55 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:55 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:55 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:55 --> Session routines successfully run
DEBUG - 2014-06-11 03:41:55 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Pagination Class Initialized
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:55 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Final output sent to browser
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:55 --> Total execution time: 0.0831
DEBUG - 2014-06-11 03:41:55 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:55 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:55 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:55 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:55 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:55 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:55 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:55 --> Session routines successfully run
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:55 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/auth_lang.php
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:55 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:55 --> Total execution time: 0.1058
DEBUG - 2014-06-11 03:41:55 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:55 --> Session routines successfully run
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:55 --> Total execution time: 0.1088
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:55 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:55 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:41:55 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:55 --> Total execution time: 0.1040
DEBUG - 2014-06-11 03:41:57 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:57 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:57 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:57 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:57 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:57 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:57 --> Session routines successfully run
ERROR - 2014-06-11 03:41:57 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:57 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:57 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:57 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:57 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:57 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:57 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:57 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:57 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:57 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:57 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:41:58 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:58 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:58 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:58 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:58 --> Session routines successfully run
ERROR - 2014-06-11 03:41:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:58 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:58 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:58 --> Config Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:41:58 --> URI Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Router Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Output Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Security Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Input Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:41:58 --> Language Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Loader Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:41:58 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Session Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:41:58 --> Session routines successfully run
ERROR - 2014-06-11 03:41:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:41:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:41:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:41:58 --> Email Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Model Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Controller Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:41:58 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:41:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:41:58 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:41:58 --> File loaded: application/views/auth/login.php
DEBUG - 2014-06-11 03:41:58 --> Final output sent to browser
DEBUG - 2014-06-11 03:41:58 --> Total execution time: 0.0800
DEBUG - 2014-06-11 03:42:16 --> Config Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:42:16 --> URI Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Router Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Output Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Security Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Input Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:42:16 --> Language Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Loader Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:42:16 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Session Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:42:16 --> Session routines successfully run
ERROR - 2014-06-11 03:42:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:42:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:42:16 --> Email Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Controller Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:42:16 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:42:16 --> Language file loaded: language/spanish/form_validation_lang.php
DEBUG - 2014-06-11 03:42:16 --> Config Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:42:16 --> URI Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Router Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Output Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Security Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Input Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:42:16 --> Language Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Loader Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:42:16 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Session Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:42:16 --> Session routines successfully run
ERROR - 2014-06-11 03:42:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:42:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:42:16 --> Email Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Controller Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:42:16 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:42:16 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:42:16 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:42:16 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:42:28 --> Config Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:42:28 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:42:28 --> URI Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Router Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Output Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Security Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Input Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:42:28 --> Language Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Loader Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:42:28 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:42:28 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Session Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:42:28 --> Session routines successfully run
ERROR - 2014-06-11 03:42:28 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:42:28 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:42:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:42:28 --> Email Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:42:28 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:42:28 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:42:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:42:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Model Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Controller Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:42:28 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:42:28 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:42:28 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:42:28 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:42:28 --> File loaded: application/views/auth/index.php
DEBUG - 2014-06-11 03:42:28 --> Final output sent to browser
DEBUG - 2014-06-11 03:42:28 --> Total execution time: 0.1892
DEBUG - 2014-06-11 03:44:41 --> Config Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:44:41 --> URI Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Router Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Output Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Security Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Input Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:44:41 --> Language Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Loader Class Initialized
DEBUG - 2014-06-11 03:44:41 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:44:41 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:44:42 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Session Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:44:42 --> Session routines successfully run
ERROR - 2014-06-11 03:44:42 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:44:42 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:44:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:44:42 --> Email Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:44:42 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:44:42 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:42 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:44:42 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Controller Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:42 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:44:42 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:44:42 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:44:43 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:44:43 --> File loaded: application/views/includes/js/utilities.php
DEBUG - 2014-06-11 03:44:43 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:44:43 --> File loaded: application/views/pages/reports.php
DEBUG - 2014-06-11 03:44:43 --> Final output sent to browser
DEBUG - 2014-06-11 03:44:43 --> Total execution time: 2.1637
DEBUG - 2014-06-11 03:44:44 --> Config Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Config Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:44:44 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:44:44 --> URI Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Router Class Initialized
DEBUG - 2014-06-11 03:44:44 --> URI Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Router Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Output Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Output Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Security Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Security Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Input Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:44:44 --> Input Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Language Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Config Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:44:44 --> Language Class Initialized
DEBUG - 2014-06-11 03:44:44 --> URI Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Router Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Config Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:44:44 --> URI Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Router Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Output Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Security Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Input Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Loader Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:44:44 --> Output Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Loader Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:44:44 --> Security Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:44:44 --> Language Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Input Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:44:44 --> Language Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Session Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:44:44 --> Session routines successfully run
ERROR - 2014-06-11 03:44:44 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:44:44 --> Loader Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:44:44 --> Loader Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:44:44 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Session Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:44:44 --> Session routines successfully run
ERROR - 2014-06-11 03:44:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:44:44 --> Config file loaded: application/config/ion_auth.php
ERROR - 2014-06-11 03:44:44 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:44:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:44:44 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:44:44 --> Email Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Email Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:44:44 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:44:44 --> Session Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:44:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:44 --> Session routines successfully run
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:44:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
ERROR - 2014-06-11 03:44:44 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:44:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:44:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Email Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:44:44 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Controller Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Controller Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:44 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:44:44 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:44:44 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Final output sent to browser
DEBUG - 2014-06-11 03:44:44 --> Final output sent to browser
DEBUG - 2014-06-11 03:44:44 --> Total execution time: 0.1661
DEBUG - 2014-06-11 03:44:44 --> Controller Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:44 --> Total execution time: 0.1458
DEBUG - 2014-06-11 03:44:44 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:44:44 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:44:44 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Final output sent to browser
DEBUG - 2014-06-11 03:44:45 --> Total execution time: 0.1699
DEBUG - 2014-06-11 03:44:45 --> Session Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:44:45 --> Session routines successfully run
ERROR - 2014-06-11 03:44:45 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:44:45 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:44:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:44:45 --> Email Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:44:45 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:44:45 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:44:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Model Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Controller Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:44:45 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:44:45 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:44:45 --> Final output sent to browser
DEBUG - 2014-06-11 03:44:45 --> Total execution time: 0.2520
DEBUG - 2014-06-11 03:49:01 --> Config Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:49:01 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:49:01 --> URI Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Router Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Output Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Security Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Input Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:49:01 --> Language Class Initialized
DEBUG - 2014-06-11 03:49:01 --> Loader Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:49:02 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:49:02 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Session Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:49:02 --> Session routines successfully run
ERROR - 2014-06-11 03:49:02 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:49:02 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:49:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:49:02 --> Email Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:49:02 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:49:02 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:49:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:02 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:49:02 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Controller Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:02 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:49:02 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:49:02 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:49:02 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:49:02 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:49:02 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 03:49:02 --> Final output sent to browser
DEBUG - 2014-06-11 03:49:02 --> Total execution time: 1.0765
DEBUG - 2014-06-11 03:49:07 --> Config Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:49:07 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:49:07 --> URI Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Router Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Output Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Security Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Input Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:49:07 --> Language Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Loader Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:49:07 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:49:07 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Session Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:49:07 --> Session routines successfully run
ERROR - 2014-06-11 03:49:07 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:49:07 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:49:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:49:07 --> Email Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:49:07 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:49:07 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:49:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Controller Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:07 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:49:07 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:49:07 --> Final output sent to browser
DEBUG - 2014-06-11 03:49:07 --> Total execution time: 0.1392
DEBUG - 2014-06-11 03:49:10 --> Config Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:49:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:49:10 --> URI Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Router Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Output Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Security Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Input Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:49:10 --> Language Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Loader Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:49:10 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:49:10 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Session Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:49:10 --> Session routines successfully run
ERROR - 2014-06-11 03:49:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:49:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:49:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:49:10 --> Email Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:49:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:49:10 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:49:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Controller Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:10 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:49:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:49:10 --> Pagination Class Initialized
ERROR - 2014-06-11 03:49:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 03:49:10 --> Final output sent to browser
DEBUG - 2014-06-11 03:49:10 --> Total execution time: 0.2040
DEBUG - 2014-06-11 03:49:14 --> Config Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:49:14 --> URI Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Router Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Output Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Security Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Input Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:49:14 --> Language Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Loader Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:49:14 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:49:14 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Session Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:49:14 --> Session routines successfully run
ERROR - 2014-06-11 03:49:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:49:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:49:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:49:14 --> Email Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:49:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:49:14 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:49:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:49:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Controller Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:49:14 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:49:14 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:49:14 --> Final output sent to browser
DEBUG - 2014-06-11 03:49:14 --> Total execution time: 0.1076
DEBUG - 2014-06-11 03:54:08 --> Config Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:54:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:54:08 --> URI Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Router Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Output Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Security Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Input Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:54:08 --> Language Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Loader Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:54:08 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:54:08 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Session Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:54:08 --> Session routines successfully run
ERROR - 2014-06-11 03:54:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:54:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:54:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:54:08 --> Email Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:54:08 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:54:08 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:54:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:54:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Controller Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:54:08 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:54:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:54:08 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:54:08 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 03:54:08 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 03:54:08 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 03:54:08 --> Final output sent to browser
DEBUG - 2014-06-11 03:54:08 --> Total execution time: 0.0800
DEBUG - 2014-06-11 03:54:14 --> Config Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:54:14 --> URI Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Router Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Output Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Security Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Input Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:54:14 --> Language Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Loader Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:54:14 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:54:14 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Session Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:54:14 --> Session routines successfully run
ERROR - 2014-06-11 03:54:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:54:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:54:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:54:14 --> Email Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:54:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:54:14 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:54:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:54:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Controller Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:54:14 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:54:14 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:54:14 --> Final output sent to browser
DEBUG - 2014-06-11 03:54:14 --> Total execution time: 0.0796
DEBUG - 2014-06-11 03:54:16 --> Config Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Hooks Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Utf8 Class Initialized
DEBUG - 2014-06-11 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 03:54:16 --> URI Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Router Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Output Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Security Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Input Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 03:54:16 --> Language Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Loader Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Helper loaded: url_helper
DEBUG - 2014-06-11 03:54:16 --> Helper loaded: form_helper
DEBUG - 2014-06-11 03:54:16 --> Database Driver Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Session Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Helper loaded: string_helper
DEBUG - 2014-06-11 03:54:16 --> Session routines successfully run
ERROR - 2014-06-11 03:54:16 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 03:54:16 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 03:54:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 03:54:16 --> Email Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 03:54:16 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 03:54:16 --> Helper loaded: language_helper
DEBUG - 2014-06-11 03:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:54:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:16 --> Helper loaded: date_helper
DEBUG - 2014-06-11 03:54:17 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:17 --> Model Class Initialized
DEBUG - 2014-06-11 03:54:17 --> Controller Class Initialized
DEBUG - 2014-06-11 03:54:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 03:54:17 --> Form Validation Class Initialized
DEBUG - 2014-06-11 03:54:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 03:54:17 --> Pagination Class Initialized
DEBUG - 2014-06-11 03:54:17 --> Final output sent to browser
DEBUG - 2014-06-11 03:54:17 --> Total execution time: 0.0829
DEBUG - 2014-06-11 04:30:41 --> Config Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Hooks Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Utf8 Class Initialized
DEBUG - 2014-06-11 04:30:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 04:30:41 --> URI Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Router Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Output Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Security Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Input Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 04:30:41 --> Language Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Loader Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Helper loaded: url_helper
DEBUG - 2014-06-11 04:30:41 --> Helper loaded: form_helper
DEBUG - 2014-06-11 04:30:41 --> Database Driver Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Session Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Helper loaded: string_helper
DEBUG - 2014-06-11 04:30:41 --> Session routines successfully run
ERROR - 2014-06-11 04:30:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 04:30:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 04:30:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 04:30:41 --> Email Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 04:30:41 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 04:30:41 --> Helper loaded: language_helper
DEBUG - 2014-06-11 04:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 04:30:41 --> Model Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Model Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Helper loaded: date_helper
DEBUG - 2014-06-11 04:30:41 --> Model Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Model Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Controller Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 04:30:41 --> Form Validation Class Initialized
DEBUG - 2014-06-11 04:30:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 04:30:41 --> Pagination Class Initialized
DEBUG - 2014-06-11 04:30:41 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 04:30:41 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 04:30:41 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 04:30:41 --> Final output sent to browser
DEBUG - 2014-06-11 04:30:41 --> Total execution time: 0.1259
DEBUG - 2014-06-11 04:32:49 --> Config Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Hooks Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Utf8 Class Initialized
DEBUG - 2014-06-11 04:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 04:32:49 --> URI Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Router Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Output Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Security Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Input Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 04:32:49 --> Language Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Loader Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Helper loaded: url_helper
DEBUG - 2014-06-11 04:32:49 --> Helper loaded: form_helper
DEBUG - 2014-06-11 04:32:49 --> Database Driver Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Session Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Helper loaded: string_helper
DEBUG - 2014-06-11 04:32:49 --> Session routines successfully run
ERROR - 2014-06-11 04:32:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 04:32:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 04:32:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 04:32:49 --> Email Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 04:32:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 04:32:49 --> Helper loaded: language_helper
DEBUG - 2014-06-11 04:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 04:32:49 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Helper loaded: date_helper
DEBUG - 2014-06-11 04:32:49 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Controller Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 04:32:49 --> Form Validation Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 04:32:49 --> Pagination Class Initialized
DEBUG - 2014-06-11 04:32:49 --> Final output sent to browser
DEBUG - 2014-06-11 04:32:49 --> Total execution time: 0.0787
DEBUG - 2014-06-11 04:32:52 --> Config Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Hooks Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Utf8 Class Initialized
DEBUG - 2014-06-11 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 04:32:52 --> URI Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Router Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Output Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Security Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Input Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 04:32:52 --> Language Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Loader Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Helper loaded: url_helper
DEBUG - 2014-06-11 04:32:52 --> Helper loaded: form_helper
DEBUG - 2014-06-11 04:32:52 --> Database Driver Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Session Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Helper loaded: string_helper
DEBUG - 2014-06-11 04:32:52 --> Session routines successfully run
ERROR - 2014-06-11 04:32:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 04:32:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 04:32:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 04:32:52 --> Email Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 04:32:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 04:32:52 --> Helper loaded: language_helper
DEBUG - 2014-06-11 04:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 04:32:52 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Helper loaded: date_helper
DEBUG - 2014-06-11 04:32:52 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Model Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Controller Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 04:32:52 --> Form Validation Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 04:32:52 --> Pagination Class Initialized
DEBUG - 2014-06-11 04:32:52 --> Final output sent to browser
DEBUG - 2014-06-11 04:32:52 --> Total execution time: 0.0735
DEBUG - 2014-06-11 05:00:13 --> Config Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:00:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:00:13 --> URI Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Router Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Output Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Security Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Input Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:00:13 --> Language Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Loader Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:00:13 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:00:13 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Session Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:00:13 --> Session routines successfully run
ERROR - 2014-06-11 05:00:13 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:00:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:00:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:00:13 --> Email Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:00:13 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:00:13 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:00:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:00:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Controller Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:00:13 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:00:13 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:00:13 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:00:13 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:00:13 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:00:13 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:00:13 --> Final output sent to browser
DEBUG - 2014-06-11 05:00:13 --> Total execution time: 0.0804
DEBUG - 2014-06-11 05:00:17 --> Config Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:00:17 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:00:17 --> URI Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Router Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Output Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Security Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Input Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:00:17 --> Language Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Loader Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:00:17 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:00:17 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Session Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:00:17 --> Session routines successfully run
ERROR - 2014-06-11 05:00:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:00:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:00:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:00:17 --> Email Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:00:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:00:17 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:00:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:00:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:00:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Controller Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:00:17 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:00:17 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:00:17 --> Final output sent to browser
DEBUG - 2014-06-11 05:00:17 --> Total execution time: 0.0831
DEBUG - 2014-06-11 05:00:18 --> Config Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:00:18 --> URI Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Router Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Output Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Security Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Input Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:00:18 --> Language Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Loader Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:00:18 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:00:18 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Session Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:00:18 --> Session routines successfully run
ERROR - 2014-06-11 05:00:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:00:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:00:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:00:18 --> Email Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:00:18 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:00:18 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:00:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:00:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:00:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Controller Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:00:18 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:00:18 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:00:18 --> Final output sent to browser
DEBUG - 2014-06-11 05:00:18 --> Total execution time: 0.0820
DEBUG - 2014-06-11 05:01:49 --> Config Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:01:49 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:01:49 --> URI Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Router Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Output Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Security Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Input Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:01:49 --> Language Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Loader Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:01:49 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:01:49 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Session Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:01:49 --> Session routines successfully run
ERROR - 2014-06-11 05:01:49 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:01:49 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:01:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:01:49 --> Email Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:01:49 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:01:49 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:01:49 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:01:49 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Controller Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:01:49 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:01:49 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:01:49 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:01:49 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:01:49 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:01:49 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:01:49 --> Final output sent to browser
DEBUG - 2014-06-11 05:01:49 --> Total execution time: 0.0922
DEBUG - 2014-06-11 05:01:52 --> Config Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:01:52 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:01:52 --> URI Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Router Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Output Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Security Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Input Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:01:52 --> Language Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Loader Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:01:52 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:01:52 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Session Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:01:52 --> Session routines successfully run
ERROR - 2014-06-11 05:01:52 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:01:52 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:01:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:01:52 --> Email Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:01:52 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:01:52 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:01:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:01:52 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:01:52 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Controller Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:01:52 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:01:52 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:01:52 --> Pagination Class Initialized
ERROR - 2014-06-11 05:01:52 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:01:52 --> Final output sent to browser
DEBUG - 2014-06-11 05:01:52 --> Total execution time: 0.0972
DEBUG - 2014-06-11 05:01:54 --> Config Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:01:54 --> URI Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Router Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Output Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Security Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Input Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:01:54 --> Language Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Loader Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:01:54 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:01:54 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Session Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:01:54 --> Session routines successfully run
ERROR - 2014-06-11 05:01:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:01:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:01:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:01:54 --> Email Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:01:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:01:54 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:01:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:01:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:01:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Controller Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:01:54 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:01:54 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:01:54 --> Final output sent to browser
DEBUG - 2014-06-11 05:01:54 --> Total execution time: 0.0796
DEBUG - 2014-06-11 05:02:13 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:13 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:13 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:13 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:13 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:13 --> Session routines successfully run
ERROR - 2014-06-11 05:02:13 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:13 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:13 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:13 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:13 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:13 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:13 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:13 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:02:13 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:02:13 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:02:13 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:02:13 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:13 --> Total execution time: 0.0880
DEBUG - 2014-06-11 05:02:38 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:38 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:38 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:38 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:38 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:38 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:38 --> Database Driver Class Initialized
ERROR - 2014-06-11 05:02:38 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 05:02:39 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:39 --> Session routines successfully run
ERROR - 2014-06-11 05:02:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:39 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:39 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:39 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:39 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:39 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:02:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:02:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:02:39 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:02:39 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:39 --> Total execution time: 1.1429
DEBUG - 2014-06-11 05:02:43 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:43 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:43 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:43 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:43 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:43 --> Session routines successfully run
ERROR - 2014-06-11 05:02:43 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:43 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:43 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:43 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:44 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:44 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:44 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:02:44 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:44 --> Total execution time: 0.0866
DEBUG - 2014-06-11 05:02:45 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:45 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:45 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:45 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:46 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:46 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:46 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:46 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:46 --> Session routines successfully run
ERROR - 2014-06-11 05:02:46 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:46 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:46 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:46 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:46 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:46 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:02:46 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:46 --> Total execution time: 0.0857
DEBUG - 2014-06-11 05:02:53 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:53 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:53 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:53 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:53 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:53 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:53 --> Session routines successfully run
ERROR - 2014-06-11 05:02:53 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:53 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:53 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:53 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:53 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:53 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:53 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:53 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:53 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:53 --> Pagination Class Initialized
ERROR - 2014-06-11 05:02:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:02:53 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:53 --> Total execution time: 0.0802
DEBUG - 2014-06-11 05:02:56 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:56 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:56 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:56 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:56 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:56 --> Session routines successfully run
ERROR - 2014-06-11 05:02:56 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:56 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:56 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:56 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:56 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:56 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:56 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:56 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:56 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:56 --> Pagination Class Initialized
ERROR - 2014-06-11 05:02:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:02:56 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:56 --> Total execution time: 0.0795
DEBUG - 2014-06-11 05:02:59 --> Config Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:02:59 --> URI Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Router Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Output Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Security Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Input Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:02:59 --> Language Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Loader Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:02:59 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:02:59 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Session Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:02:59 --> Session routines successfully run
ERROR - 2014-06-11 05:02:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:02:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:02:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:02:59 --> Email Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:02:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:02:59 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:02:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Controller Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:02:59 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:02:59 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:02:59 --> Final output sent to browser
DEBUG - 2014-06-11 05:02:59 --> Total execution time: 0.0859
DEBUG - 2014-06-11 05:04:54 --> Config Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:04:54 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:04:54 --> URI Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Router Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Output Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Security Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Input Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:04:54 --> Language Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Loader Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:04:54 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:04:54 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Session Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:04:54 --> Session routines successfully run
ERROR - 2014-06-11 05:04:54 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:04:54 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:04:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:04:54 --> Email Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:04:54 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:04:54 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:04:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:04:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Model Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Controller Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:04:54 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:04:54 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:04:54 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:04:54 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:04:54 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:04:54 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:04:54 --> Final output sent to browser
DEBUG - 2014-06-11 05:04:54 --> Total execution time: 0.0865
DEBUG - 2014-06-11 05:05:31 --> Config Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:05:31 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:05:31 --> URI Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Router Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Output Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Security Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Input Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:05:31 --> Language Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Loader Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:05:31 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:05:31 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Session Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:05:31 --> Session routines successfully run
ERROR - 2014-06-11 05:05:31 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:05:31 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:05:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:05:31 --> Email Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:05:31 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:05:31 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:05:31 --> Model Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Model Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:05:31 --> Model Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Model Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Controller Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:05:31 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:05:31 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:05:31 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:05:31 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:05:31 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:05:31 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:05:31 --> Final output sent to browser
DEBUG - 2014-06-11 05:05:31 --> Total execution time: 0.0805
DEBUG - 2014-06-11 05:06:06 --> Config Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:06:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:06:06 --> URI Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Router Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Output Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Security Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Input Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:06:06 --> Language Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Loader Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:06:06 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:06:06 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Session Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:06:06 --> Session routines successfully run
ERROR - 2014-06-11 05:06:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:06:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:06:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:06:06 --> Email Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:06:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:06:06 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:06:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:06:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Controller Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:06:06 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:06:06 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:06:06 --> Final output sent to browser
DEBUG - 2014-06-11 05:06:06 --> Total execution time: 0.0716
DEBUG - 2014-06-11 05:06:09 --> Config Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:06:09 --> URI Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Router Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Output Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Security Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Input Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:06:09 --> Language Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Loader Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:06:09 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:06:09 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Session Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:06:09 --> Session routines successfully run
ERROR - 2014-06-11 05:06:09 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:06:09 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:06:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:06:09 --> Email Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:06:09 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:06:09 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:06:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:06:09 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:06:09 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Model Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Controller Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:06:09 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:06:09 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:06:09 --> Final output sent to browser
DEBUG - 2014-06-11 05:06:09 --> Total execution time: 0.0745
DEBUG - 2014-06-11 05:09:39 --> Config Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:09:39 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:09:39 --> URI Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Router Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Output Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Security Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Input Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:09:39 --> Language Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Loader Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:09:39 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:09:39 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Session Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:09:39 --> Session routines successfully run
ERROR - 2014-06-11 05:09:39 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:09:39 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:09:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:09:39 --> Email Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:09:39 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:09:39 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:09:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:09:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Controller Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:09:39 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:09:39 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:09:39 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:09:39 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:09:39 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:09:39 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:09:39 --> Final output sent to browser
DEBUG - 2014-06-11 05:09:39 --> Total execution time: 0.0825
DEBUG - 2014-06-11 05:09:44 --> Config Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:09:44 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:09:44 --> URI Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Router Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Output Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Security Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Input Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:09:44 --> Language Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Loader Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:09:44 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:09:44 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Session Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:09:44 --> Session routines successfully run
ERROR - 2014-06-11 05:09:44 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:09:44 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:09:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:09:44 --> Email Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:09:44 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:09:44 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:09:44 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:09:44 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Controller Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:09:44 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:09:44 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:09:44 --> Pagination Class Initialized
ERROR - 2014-06-11 05:09:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:09:44 --> Final output sent to browser
DEBUG - 2014-06-11 05:09:44 --> Total execution time: 0.0774
DEBUG - 2014-06-11 05:09:46 --> Config Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:09:46 --> URI Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Router Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Output Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Security Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Input Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:09:46 --> Language Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Loader Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:09:46 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:09:46 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Session Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:09:46 --> Session routines successfully run
ERROR - 2014-06-11 05:09:46 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:09:46 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:09:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:09:46 --> Email Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:09:46 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:09:46 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:09:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:09:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:09:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Model Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Controller Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:09:46 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:09:46 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:09:46 --> Final output sent to browser
DEBUG - 2014-06-11 05:09:46 --> Total execution time: 0.0743
DEBUG - 2014-06-11 05:14:12 --> Config Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:14:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:14:12 --> URI Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Router Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Output Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Security Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Input Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:14:12 --> Language Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Loader Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:14:12 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:14:12 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Session Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:14:12 --> Session routines successfully run
ERROR - 2014-06-11 05:14:12 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:14:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:14:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:14:12 --> Email Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:14:12 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:14:12 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:14:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:14:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:14:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Controller Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:14:12 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:14:12 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:14:12 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:14:12 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:14:12 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:14:12 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:14:12 --> Final output sent to browser
DEBUG - 2014-06-11 05:14:12 --> Total execution time: 0.0829
DEBUG - 2014-06-11 05:14:41 --> Config Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:14:41 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:14:41 --> URI Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Router Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Output Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Security Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Input Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:14:41 --> Language Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Loader Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:14:41 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:14:41 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Session Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:14:41 --> Session routines successfully run
ERROR - 2014-06-11 05:14:41 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:14:41 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:14:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:14:41 --> Email Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:14:41 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:14:41 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:14:41 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:14:41 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Controller Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:14:41 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:14:41 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:14:41 --> Pagination Class Initialized
ERROR - 2014-06-11 05:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:14:41 --> Final output sent to browser
DEBUG - 2014-06-11 05:14:41 --> Total execution time: 0.0766
DEBUG - 2014-06-11 05:14:43 --> Config Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:14:43 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:14:43 --> URI Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Router Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Output Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Security Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Input Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:14:43 --> Language Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Loader Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:14:43 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:14:43 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Session Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:14:43 --> Session routines successfully run
ERROR - 2014-06-11 05:14:43 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:14:43 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:14:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:14:43 --> Email Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:14:43 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:14:43 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:14:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:14:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Model Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Controller Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:14:43 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:14:43 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:14:43 --> Final output sent to browser
DEBUG - 2014-06-11 05:14:43 --> Total execution time: 0.0736
DEBUG - 2014-06-11 05:19:00 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:00 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:00 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:00 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:00 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:00 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:00 --> Session routines successfully run
ERROR - 2014-06-11 05:19:00 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:00 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:00 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:00 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:00 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:00 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:00 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:00 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:00 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:00 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:19:00 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:19:00 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:19:00 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:19:00 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:00 --> Total execution time: 0.0808
DEBUG - 2014-06-11 05:19:03 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:03 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:03 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:03 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:03 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:03 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:03 --> Database Driver Class Initialized
ERROR - 2014-06-11 05:19:03 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 05:19:04 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:04 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:04 --> Session routines successfully run
ERROR - 2014-06-11 05:19:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:04 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:04 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:04 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:05 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:05 --> Pagination Class Initialized
ERROR - 2014-06-11 05:19:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:19:05 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:05 --> Total execution time: 1.1050
DEBUG - 2014-06-11 05:19:05 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:05 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:05 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:05 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:05 --> Session routines successfully run
ERROR - 2014-06-11 05:19:05 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:05 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:05 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:05 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:19:05 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:05 --> Total execution time: 0.0796
DEBUG - 2014-06-11 05:19:14 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:14 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:14 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:14 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:14 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:14 --> Session routines successfully run
ERROR - 2014-06-11 05:19:14 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:14 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:14 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:14 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:14 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:14 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:14 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:14 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:14 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:14 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:19:14 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:19:14 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:19:14 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:19:14 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:14 --> Total execution time: 0.0754
DEBUG - 2014-06-11 05:19:18 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:18 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:18 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:18 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:18 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:18 --> Session routines successfully run
ERROR - 2014-06-11 05:19:18 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:18 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:18 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:18 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:18 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:18 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:18 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:19:18 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:18 --> Total execution time: 0.0784
DEBUG - 2014-06-11 05:19:55 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:55 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:55 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:55 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:55 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:55 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:55 --> Session routines successfully run
ERROR - 2014-06-11 05:19:55 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:55 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:55 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:55 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:55 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:55 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:55 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:55 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:55 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:55 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:19:55 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:19:55 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:19:55 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:19:55 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:55 --> Total execution time: 0.0999
DEBUG - 2014-06-11 05:19:58 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:58 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:58 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:58 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:58 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:58 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:58 --> Session routines successfully run
ERROR - 2014-06-11 05:19:58 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:58 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:58 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:58 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:58 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:58 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:58 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:58 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:58 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:58 --> Pagination Class Initialized
ERROR - 2014-06-11 05:19:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\CodeIgniter\application\controllers\report_controller.php 208
DEBUG - 2014-06-11 05:19:58 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:58 --> Total execution time: 0.0758
DEBUG - 2014-06-11 05:19:59 --> Config Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:19:59 --> URI Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Router Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Output Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Security Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Input Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:19:59 --> Language Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Loader Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:19:59 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:19:59 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Session Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:19:59 --> Session routines successfully run
ERROR - 2014-06-11 05:19:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:19:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:19:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:19:59 --> Email Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:19:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:19:59 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:19:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:19:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Controller Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:19:59 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:19:59 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:19:59 --> Final output sent to browser
DEBUG - 2014-06-11 05:19:59 --> Total execution time: 0.1165
DEBUG - 2014-06-11 05:24:04 --> Config Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:24:04 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:24:04 --> URI Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Router Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Output Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Security Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Input Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:24:04 --> Language Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Loader Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:24:04 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:24:04 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Session Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:24:04 --> Session routines successfully run
ERROR - 2014-06-11 05:24:04 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:24:04 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:24:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:24:04 --> Email Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:24:04 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:24:04 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:24:04 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:24:04 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Controller Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:24:04 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:24:04 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:24:04 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:24:04 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:24:04 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:24:04 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:24:04 --> Final output sent to browser
DEBUG - 2014-06-11 05:24:04 --> Total execution time: 0.0908
DEBUG - 2014-06-11 05:24:06 --> Config Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:24:06 --> URI Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Router Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Output Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Security Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Input Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:24:06 --> Language Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Loader Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:24:06 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:24:06 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Session Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:24:06 --> Session routines successfully run
ERROR - 2014-06-11 05:24:06 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:24:06 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:24:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:24:06 --> Email Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:24:06 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:24:06 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:24:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:24:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Controller Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:24:06 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:24:06 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:24:06 --> Final output sent to browser
DEBUG - 2014-06-11 05:24:06 --> Total execution time: 0.0862
DEBUG - 2014-06-11 05:24:10 --> Config Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:24:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:24:10 --> URI Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Router Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Output Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Security Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Input Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:24:10 --> Language Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Loader Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:24:10 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:24:10 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Session Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:24:10 --> Session routines successfully run
ERROR - 2014-06-11 05:24:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:24:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:24:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:24:10 --> Email Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:24:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:24:10 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:24:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:24:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Controller Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:24:10 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:24:10 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:24:10 --> Final output sent to browser
DEBUG - 2014-06-11 05:24:10 --> Total execution time: 0.0837
DEBUG - 2014-06-11 05:25:05 --> Config Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:25:05 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:25:05 --> URI Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Router Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Output Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Security Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Input Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:25:05 --> Language Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Loader Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:25:05 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:25:05 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Session Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:25:05 --> Session routines successfully run
ERROR - 2014-06-11 05:25:05 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:25:05 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:25:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:25:05 --> Email Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:25:05 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:25:05 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:25:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Controller Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:05 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:25:05 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:25:05 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:25:05 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:25:05 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:25:05 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:25:05 --> Final output sent to browser
DEBUG - 2014-06-11 05:25:05 --> Total execution time: 0.0959
DEBUG - 2014-06-11 05:25:10 --> Config Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:25:10 --> URI Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Router Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Output Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Security Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Input Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:25:10 --> Language Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Loader Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:25:10 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:25:10 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Session Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:25:10 --> Session routines successfully run
ERROR - 2014-06-11 05:25:10 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:25:10 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:25:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:25:10 --> Email Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:25:10 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:25:10 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:25:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Controller Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:10 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:25:10 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:25:10 --> Final output sent to browser
DEBUG - 2014-06-11 05:25:10 --> Total execution time: 0.0748
DEBUG - 2014-06-11 05:25:12 --> Config Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:25:12 --> URI Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Router Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Output Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Security Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Input Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:25:12 --> Language Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Loader Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:25:12 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:25:12 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Session Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:25:12 --> Session routines successfully run
ERROR - 2014-06-11 05:25:12 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:25:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:25:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:25:12 --> Email Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:25:12 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:25:12 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:25:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Controller Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:12 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:25:12 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:25:12 --> Final output sent to browser
DEBUG - 2014-06-11 05:25:12 --> Total execution time: 0.0851
DEBUG - 2014-06-11 05:25:15 --> Config Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:25:15 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:25:15 --> URI Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Router Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Output Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Security Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Input Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:25:15 --> Language Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Loader Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:25:15 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:25:15 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Session Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:25:15 --> Session routines successfully run
ERROR - 2014-06-11 05:25:15 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:25:15 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:25:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:25:15 --> Email Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:25:15 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:25:15 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:15 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:25:15 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Model Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Controller Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:25:15 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:25:15 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:25:15 --> Final output sent to browser
DEBUG - 2014-06-11 05:25:15 --> Total execution time: 0.0826
DEBUG - 2014-06-11 05:26:08 --> Config Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:26:08 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:26:08 --> URI Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Router Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Output Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Security Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Input Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:26:08 --> Language Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Loader Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:26:08 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:26:08 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Session Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:26:08 --> Session routines successfully run
ERROR - 2014-06-11 05:26:08 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:26:08 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:26:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:26:08 --> Email Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:26:08 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:26:08 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:26:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:26:08 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:26:08 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Controller Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:26:08 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:26:08 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:26:08 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:26:08 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:26:08 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:26:08 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:26:08 --> Final output sent to browser
DEBUG - 2014-06-11 05:26:08 --> Total execution time: 0.0990
DEBUG - 2014-06-11 05:26:24 --> Config Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:26:24 --> URI Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Router Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Output Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Security Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Input Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:26:24 --> Language Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Loader Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:26:24 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:26:24 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Session Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:26:24 --> Session routines successfully run
ERROR - 2014-06-11 05:26:24 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:26:24 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:26:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:26:24 --> Email Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:26:24 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:26:24 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:26:24 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:26:24 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Model Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Controller Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:26:24 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:26:24 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:26:24 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:26:24 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:26:24 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:26:24 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:26:24 --> Final output sent to browser
DEBUG - 2014-06-11 05:26:24 --> Total execution time: 0.0865
DEBUG - 2014-06-11 05:27:59 --> Config Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:27:59 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:27:59 --> URI Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Router Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Output Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Security Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Input Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:27:59 --> Language Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Loader Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:27:59 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:27:59 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Session Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:27:59 --> Session routines successfully run
ERROR - 2014-06-11 05:27:59 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:27:59 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:27:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:27:59 --> Email Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:27:59 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:27:59 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:27:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:27:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Model Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Controller Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:27:59 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:27:59 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:27:59 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:27:59 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:27:59 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:27:59 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:27:59 --> Final output sent to browser
DEBUG - 2014-06-11 05:27:59 --> Total execution time: 0.0813
DEBUG - 2014-06-11 05:28:11 --> Config Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:28:11 --> URI Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Router Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Output Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Security Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Input Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:28:11 --> Language Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Loader Class Initialized
DEBUG - 2014-06-11 05:28:11 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:28:11 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:28:11 --> Database Driver Class Initialized
ERROR - 2014-06-11 05:28:11 --> Severity: Notice  --> mysql_pconnect():  C:\xampp\htdocs\CodeIgniter\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-06-11 05:28:12 --> Session Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:28:12 --> Session routines successfully run
ERROR - 2014-06-11 05:28:12 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:28:12 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:28:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:28:12 --> Email Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:28:12 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:28:12 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:28:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:28:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Controller Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:28:12 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:28:12 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:28:12 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:28:12 --> File loaded: application/views/includes/test_head.php
DEBUG - 2014-06-11 05:28:12 --> File loaded: application/views/includes/menu_upper.php
DEBUG - 2014-06-11 05:28:12 --> File loaded: application/views/pages/create_reports.php
DEBUG - 2014-06-11 05:28:12 --> Final output sent to browser
DEBUG - 2014-06-11 05:28:12 --> Total execution time: 1.1300
DEBUG - 2014-06-11 05:28:17 --> Config Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:28:17 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:28:17 --> URI Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Router Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Output Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Security Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Input Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:28:17 --> Language Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Loader Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:28:17 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:28:17 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Session Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:28:17 --> Session routines successfully run
ERROR - 2014-06-11 05:28:17 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:28:17 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:28:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:28:17 --> Email Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:28:17 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:28:17 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:28:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:28:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Controller Class Initialized
DEBUG - 2014-06-11 05:28:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:28:17 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:28:18 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:28:18 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:28:18 --> Final output sent to browser
DEBUG - 2014-06-11 05:28:18 --> Total execution time: 0.0758
DEBUG - 2014-06-11 05:28:19 --> Config Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Hooks Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Utf8 Class Initialized
DEBUG - 2014-06-11 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2014-06-11 05:28:19 --> URI Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Router Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Output Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Security Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Input Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-06-11 05:28:19 --> Language Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Loader Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Helper loaded: url_helper
DEBUG - 2014-06-11 05:28:19 --> Helper loaded: form_helper
DEBUG - 2014-06-11 05:28:19 --> Database Driver Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Session Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Helper loaded: string_helper
DEBUG - 2014-06-11 05:28:19 --> Session routines successfully run
ERROR - 2014-06-11 05:28:19 --> Severity: Warning  --> include_once(application/core/MY_Ion_auth.php): failed to open stream: No such file or directory C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
ERROR - 2014-06-11 05:28:19 --> Severity: Warning  --> include_once(): Failed opening 'application/core/MY_Ion_auth.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\CodeIgniter\application\config\config.php 380
DEBUG - 2014-06-11 05:28:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2014-06-11 05:28:19 --> Email Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Language file loaded: language/spanish/ion_auth_lang.php
DEBUG - 2014-06-11 05:28:19 --> Helper loaded: cookie_helper
DEBUG - 2014-06-11 05:28:19 --> Helper loaded: language_helper
DEBUG - 2014-06-11 05:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:28:19 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Helper loaded: date_helper
DEBUG - 2014-06-11 05:28:19 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Model Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Controller Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2014-06-11 05:28:19 --> Form Validation Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Language file loaded: language/spanish/auth_lang.php
DEBUG - 2014-06-11 05:28:19 --> Pagination Class Initialized
DEBUG - 2014-06-11 05:28:19 --> Final output sent to browser
DEBUG - 2014-06-11 05:28:19 --> Total execution time: 0.0743
DEBUG - 2014-06-11 21:07:56 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:07:56 --> Final output sent to browser
DEBUG - 2014-06-11 21:07:56 --> Total execution time: 0.1745
DEBUG - 2014-06-11 21:11:18 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:11:18 --> Final output sent to browser
DEBUG - 2014-06-11 21:11:18 --> Total execution time: 0.1080
DEBUG - 2014-06-11 21:13:39 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:13:39 --> Final output sent to browser
DEBUG - 2014-06-11 21:13:39 --> Total execution time: 3.1112
DEBUG - 2014-06-11 21:13:55 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:13:55 --> Final output sent to browser
DEBUG - 2014-06-11 21:13:55 --> Total execution time: 0.1070
DEBUG - 2014-06-11 21:14:04 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:14:04 --> Final output sent to browser
DEBUG - 2014-06-11 21:14:04 --> Total execution time: 0.1084
DEBUG - 2014-06-11 21:14:36 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:14:36 --> Final output sent to browser
DEBUG - 2014-06-11 21:14:36 --> Total execution time: 0.1096
DEBUG - 2014-06-11 21:17:25 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:17:25 --> Final output sent to browser
DEBUG - 2014-06-11 21:17:25 --> Total execution time: 0.1375
DEBUG - 2014-06-11 21:18:34 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:18:34 --> Final output sent to browser
DEBUG - 2014-06-11 21:18:34 --> Total execution time: 0.2102
DEBUG - 2014-06-11 21:21:09 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:21:09 --> Final output sent to browser
DEBUG - 2014-06-11 21:21:09 --> Total execution time: 1.4601
DEBUG - 2014-06-11 21:23:07 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:23:07 --> Final output sent to browser
DEBUG - 2014-06-11 21:23:07 --> Total execution time: 1.4016
DEBUG - 2014-06-11 21:23:25 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:23:25 --> Final output sent to browser
DEBUG - 2014-06-11 21:23:25 --> Total execution time: 0.1078
DEBUG - 2014-06-11 21:23:46 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:23:46 --> Final output sent to browser
DEBUG - 2014-06-11 21:23:46 --> Total execution time: 0.1002
DEBUG - 2014-06-11 21:33:54 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:33:54 --> Final output sent to browser
DEBUG - 2014-06-11 21:33:54 --> Total execution time: 0.1248
DEBUG - 2014-06-11 21:36:27 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:36:27 --> Final output sent to browser
DEBUG - 2014-06-11 21:36:27 --> Total execution time: 1.2516
DEBUG - 2014-06-11 21:36:41 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:36:41 --> Final output sent to browser
DEBUG - 2014-06-11 21:36:41 --> Total execution time: 0.1169
DEBUG - 2014-06-11 21:37:01 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:37:01 --> Final output sent to browser
DEBUG - 2014-06-11 21:37:01 --> Total execution time: 0.1087
DEBUG - 2014-06-11 21:40:04 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:40:04 --> Final output sent to browser
DEBUG - 2014-06-11 21:40:04 --> Total execution time: 0.1108
DEBUG - 2014-06-11 21:42:33 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:42:33 --> Final output sent to browser
DEBUG - 2014-06-11 21:42:33 --> Total execution time: 1.2312
DEBUG - 2014-06-11 21:45:42 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:45:42 --> Final output sent to browser
DEBUG - 2014-06-11 21:45:42 --> Total execution time: 0.1176
DEBUG - 2014-06-11 21:48:16 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:48:16 --> Final output sent to browser
DEBUG - 2014-06-11 21:48:16 --> Total execution time: 0.1066
DEBUG - 2014-06-11 21:49:07 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:49:07 --> Final output sent to browser
DEBUG - 2014-06-11 21:49:07 --> Total execution time: 0.1088
DEBUG - 2014-06-11 21:49:21 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:49:21 --> Final output sent to browser
DEBUG - 2014-06-11 21:49:21 --> Total execution time: 0.1247
DEBUG - 2014-06-11 21:50:29 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:50:29 --> Final output sent to browser
DEBUG - 2014-06-11 21:50:29 --> Total execution time: 0.1132
DEBUG - 2014-06-11 21:50:34 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:50:34 --> Final output sent to browser
DEBUG - 2014-06-11 21:50:34 --> Total execution time: 0.1223
DEBUG - 2014-06-11 21:54:10 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:54:10 --> Final output sent to browser
DEBUG - 2014-06-11 21:54:10 --> Total execution time: 0.1679
DEBUG - 2014-06-11 21:54:35 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:54:35 --> Final output sent to browser
DEBUG - 2014-06-11 21:54:35 --> Total execution time: 0.0999
DEBUG - 2014-06-11 21:56:48 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:56:48 --> Final output sent to browser
DEBUG - 2014-06-11 21:56:48 --> Total execution time: 0.1101
DEBUG - 2014-06-11 21:56:59 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:56:59 --> Final output sent to browser
DEBUG - 2014-06-11 21:56:59 --> Total execution time: 0.1448
DEBUG - 2014-06-11 21:57:08 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-11 21:57:08 --> Final output sent to browser
DEBUG - 2014-06-11 21:57:08 --> Total execution time: 0.1033
