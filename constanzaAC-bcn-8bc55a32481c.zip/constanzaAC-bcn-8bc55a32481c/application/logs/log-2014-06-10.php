<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-06-10 21:32:28 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-10 21:32:28 --> Final output sent to browser
DEBUG - 2014-06-10 21:32:28 --> Total execution time: 0.2805
DEBUG - 2014-06-10 21:36:21 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-10 21:36:21 --> Final output sent to browser
DEBUG - 2014-06-10 21:36:21 --> Total execution time: 0.1264
DEBUG - 2014-06-10 21:38:45 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-10 21:38:45 --> Final output sent to browser
DEBUG - 2014-06-10 21:38:45 --> Total execution time: 0.1071
DEBUG - 2014-06-10 21:41:49 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-10 21:41:49 --> Final output sent to browser
DEBUG - 2014-06-10 21:41:49 --> Total execution time: 0.1080
DEBUG - 2014-06-10 21:41:57 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-10 21:41:57 --> Final output sent to browser
DEBUG - 2014-06-10 21:41:57 --> Total execution time: 0.1759
DEBUG - 2014-06-10 21:42:16 --> File loaded: application/views/pages/home.php
DEBUG - 2014-06-10 21:42:16 --> Final output sent to browser
DEBUG - 2014-06-10 21:42:16 --> Total execution time: 0.0921
