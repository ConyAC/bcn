<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Errors
$lang['error_csrf'] = 'Esta forma no paso nuestras pruebas de seguridad.';

// Login
$lang['login_heading']         = 'INGRESAR';
$lang['login_subheading']      = 'Por favor ingresa con tu email/usuario y contrase&ntildea aqui abajo.';
$lang['login_identity_label']  = 'Correo electr&oacute;nico';
$lang['login_password_label']  = 'Contrase&ntilde;a';
$lang['login_remember_label']  = 'Recu&eacuterdame';
$lang['login_submit_btn']      = 'Iniciar Sesi&oacute;n';
$lang['login_forgot_password'] = 'Olvidaste tu contrase&ntildea?';

// Index
$lang['index_heading']           = 'Administraci&oacuten Usuarios';
$lang['index_subheading']        = 'Abajo esta la lista de usuarios.';
$lang['index_fname_th']          = 'Nombre';
$lang['index_rut_th']		     = 'Rut';
$lang['index_lname_th']          = 'Apellido';
$lang['index_email_th']          = 'Correo electr&oacute;nico';
$lang['index_groups_th']         = 'Grupos';
$lang['index_status_th']         = 'Status';
$lang['index_action_th']         = 'Acciones';
$lang['index_active_link']       = 'Activo';
$lang['index_inactive_link']     = 'Inactivo';
$lang['index_create_user_link']  = 'Crear nuevo usuario';
$lang['index_create_group_link'] = 'Crear nuevo grupo';
$lang['index_logout'] = 'Cerrar Sesi&oacuten';
$lang['index_edit_user'] = 'Editar';
$lang['index_view_user'] = 'Ver';
$lang['index_allocate_product'] = 'Asignar';
$lang['index_status_th'] = 'Activo';
$lang['index_delete_th'] = 'Eliminar';
$lang['index_read_th'] = 'Leer';
$lang['index_cancel_th'] = 'Cancelar';
$lang['index_accept_th'] = 'Aceptar';
$lang['index_delete_user_confirm'] = '&iquest;Est&aacute; seguro de eliminar al usuario seleccionado?';
$lang['index_delete_product_confirm'] = '&iquest;Est&aacute; seguro de eliminar el producto con N&ordm; de Serie ';
$lang['index_title']					="Gesti&oacute;n de Existencias";
$lang['index_confirm_action']					="Confirmar Acci&oacute;n";
$lang['index_export_excel']					="Exportar a Excel";
$lang['index_info']					="Informaci&oacute;n";
$lang['index_no_results_found']					="No se encontraron coincidencias.";
$lang['index_warning']					="Atenci&oacute;n";
$lang['index_no_report']					="No se encontraron reportes din&aacute;micos en la base de datos.";
$lang['index_info_user']					="Informaci&oacute;n Funcionario";
$lang['index_info_prod']					="Informaci&oacute;n Productos asignados";
$lang['index_request']					="Usted no tiene productos asociados, si desea realizar una solicitud haga clic en el siguiente enlace";

// Deactivate User
$lang['deactivate_heading']                  = 'Desactivar usuario';
$lang['deactivate_subheading']               = 'Est&aacute;s seguro que quieres desactivar al usuario \'%s\'';
$lang['deactivate_confirm_y_label']          = 'Si:';
$lang['deactivate_confirm_n_label']          = 'No:';
$lang['deactivate_submit_btn']               = 'Enviar';
$lang['deactivate_validation_confirm_label'] = 'confirmacion';
$lang['deactivate_validation_user_id_label'] = 'identificacion de usuario';

// Create User
$lang['create_user_heading']                           = 'Crear Usuario';
$lang['create_user_subheading']                        = 'Por favor registra la informacion del usuario abajo.';
$lang['create_user_fname_label']                       = 'Nombre';
$lang['create_user_lname_label']                       = 'Apellido';
$lang['create_user_company_label']                     = '&Aacuterea';
$lang['create_user_email_label']                       = 'Email';
$lang['create_user_phone_label']                       = 'Tel&eacute;fono';
$lang['create_user_password_label']                    = 'Contrase&ntildea';
$lang['create_user_password_confirm_label']            = 'Confirmar Contrase&ntildea';
$lang['create_user_submit_btn']                        = 'Crear Usuario';
$lang['create_product_submit_btn']                     = 'Crear Producto';
$lang['create_user_lrut_label']                        = 'Rut';
$lang['create_user_ldate_admission_label']             = 'Fecha de Ingreso';
$lang['create_user_cancel_btn']                        = '  Cancelar   ';

$lang['create_user_validation_fname_label']            = 'Nombre';
$lang['create_user_validation_lname_label']            = 'Apellido';
$lang['create_user_validation_email_label']            = 'Correo electr&oacute;nico';
$lang['create_user_validation_lphone_label']           = 'N&uacute;mero tel&eacute;fonico';
$lang['create_user_validation_phone2_label']           = 'segundo numero telefonico';
$lang['create_user_validation_phone3_label']           = 'tercer numero telefonico';
$lang['create_user_validation_company_label']          = 'nombre de compa&ntildeia';
$lang['create_user_validation_password_label']         = 'Contrase&ntildea';
$lang['create_user_validation_password_confirm_label'] = 'Confirmaci&oacute;n de contrase&ntildea';
$lang['create_user_validation_jobtitle_label']         = 'Cargo';
$lang['create_user_validation_area_label']		   = '&Aacuterea';

$lang['create_user_jobtitle_label']                     = 'Cargo';

// Edit User
$lang['edit_user_heading']                           = 'Editar Usuario';
$lang['edit_user_subheading']                        = 'Por favor registra la informacion del usuario abajo.';
$lang['edit_user_fname_label']                       = 'Nombre';
$lang['edit_user_lname_label']                       = 'Apellido';
$lang['edit_user_company_label']                     = 'Compa&ntildeia';
$lang['edit_user_email_label']                       = 'Email';
$lang['edit_user_phone_label']                       = 'Telefono';
$lang['edit_user_password_label']                    = 'Contrase&ntildea';
$lang['edit_user_password_confirm_label']            = 'Confirmar Contrase&ntildea';
$lang['edit_user_groups_heading']                    = 'Permisos de acceso';
$lang['edit_user_submit_btn']                        = 'Guardar Usuario';
$lang['edit_user_validation_fname_label']            = 'Nombre';
$lang['edit_user_validation_lname_label']            = 'Apellido';
$lang['edit_user_validation_lrut_label']             = 'Rut';
$lang['edit_user_validation_email_label']            = 'Correo electronico';
$lang['edit_user_validation_phone_label']            = 'Numero telefonico';
$lang['edit_user_validation_phone2_label']           = 'Segunda parte del numero telefonico';
$lang['edit_user_validation_phone3_label']           = 'Tercera parte del numero telefonico';
$lang['edit_user_validation_company_label']          = 'Compa&ntildeia';
$lang['edit_user_validation_groups_label']           = 'Grupos';
$lang['edit_user_validation_password_label']         = 'Contrase&ntildea';
$lang['edit_user_validation_password_confirm_label'] = 'Confirmacion de contrase&ntildea';

// Create Group
$lang['create_group_title']                  = 'Crear Grupo';
$lang['create_group_heading']                = 'Crear Grupo';
$lang['create_group_subheading']             = 'Por favor registra la informacion del grupo abajo.';
$lang['create_group_name_label']             = 'Nombre de Grupo:';
$lang['create_group_desc_label']             = 'Descripcion:';
$lang['create_group_submit_btn']             = 'Crear Grupo';
$lang['create_group_validation_name_label']  = 'Nombre de Grupo';
$lang['create_group_validation_desc_label']  = 'Descripcion';

// Edit Group
$lang['edit_group_title']                  = 'Editar Grupo';
$lang['edit_group_saved']                  = 'Grupo Guardado';
$lang['edit_group_heading']                = 'Editar Grupo';
$lang['edit_group_subheading']             = 'Por favor registra la informacion del grupo abajo.';
$lang['edit_group_name_label']             = 'Nombre de Grupo:';
$lang['edit_group_desc_label']             = 'Descripcion:';
$lang['edit_group_submit_btn']             = 'Guardar Grupo';
$lang['edit_group_validation_name_label']  = 'Nombre de Grupo';
$lang['edit_group_validation_desc_label']  = 'Descripcion';

// Change Password
$lang['change_password_heading']                               = 'Cambiar Contrase&ntildea';
$lang['change_password_old_password_label']                    = 'Contrase&ntildea Vieja:';
$lang['change_password_new_password_label']                    = 'Nueva Contrase&ntildea (de al menos %s caracteres de largo):';
$lang['change_password_new_password_confirm_label']            = 'Confirmar Nueva Contrase&ntildea:';
$lang['change_password_submit_btn']                            = 'Cambiar';
$lang['change_password_validation_old_password_label']         = 'Vieja Contrase&ntildea';
$lang['change_password_validation_new_password_label']         = 'Nueva Contrase&ntildea';
$lang['change_password_validation_new_password_confirm_label'] = 'Confirmar Nueva Contrase&ntildea';

// Forgot Password
$lang['forgot_password_heading']                 = 'Olvide Mi Contrase&ntildea';
$lang['forgot_password_subheading']              = 'Por favor ingresa tu %s para que podamos enviarte un email para restablecer tu contrase&ntildea.';
$lang['forgot_password_email_label']             = '%s:';
$lang['forgot_password_submit_btn']              = 'Enviar';
$lang['forgot_password_validation_email_label']  = 'Correo Electronico';
$lang['forgot_password_username_identity_label'] = 'Usuario';
$lang['forgot_password_email_identity_label']    = 'Email';
$lang['forgot_password_email_not_found']         = 'No record of that email address.';

// Reset Password
$lang['reset_password_heading']                               = 'Cambiar Contrase&ntildea';
$lang['reset_password_new_password_label']                    = 'Nueva Contrase&ntildea (de al menos %s caracteres de largo):';
$lang['reset_password_new_password_confirm_label']            = 'Confirmar Nueva Contrase&ntildea:';
$lang['reset_password_submit_btn']                            = 'Guardar';
$lang['reset_password_validation_new_password_label']         = 'Nueva Contrase&ntildea';
$lang['reset_password_validation_new_password_confirm_label'] = 'Confirmar Nueva Contrase&ntildea';

// Activation Email
$lang['email_activate_heading']    = 'Activar cuenta por %s';
$lang['email_activate_subheading'] = 'Por favor ingresa a este link para %s.';
$lang['email_activate_link']       = 'activar tu cuenta';

// Forgot Password Email
$lang['email_forgot_password_heading']    = 'Reestablecer contrase&ntildea para %s';
$lang['email_forgot_password_subheading'] = 'Por favor ingresa a este link para %s.';
$lang['email_forgot_password_link']       = 'Restablecer Tu Contrase&ntildea';

// New Password Email
$lang['email_new_password_heading']    = 'Nueva contrase&ntildea para %s';
$lang['email_new_password_subheading'] = 'Tu contrase&ntildea ha sido restablecida a: %s';
$lang['home_welcome'] = 'Bienvenido(a) ';


//product
$lang['admin_product_heading']           = 'Administraci&oacuten Productos';
$lang['admin_product_create_link']  	 = 'Crear nuevo producto';

//reports
$lang['reports_heading']           = 'Reportes';
$lang['reports_inform_dinamic']    = 'Informes Din&aacutemicos'; 
$lang['reports_inform_static']    = 'Informes Est&aacuteticos ';
$lang['reports_action']            = 'Exportar';
$lang['reports_dinamic']    = 'Din&aacute;mico';
$lang['reports_static']    = 'Est&aacute;tico';
$lang['reports_date']    = 'Fecha de creaci&oacute;n ';
$lang['reports_description']                = 'Descripci&oacuten';

//statistics
$lang['statistics_heading']           = 'Gesti&oacuten';

$lang['back']            = 'Volver';

//create product
$lang['create_product_heading']                           = 'Crear Producto';
$lang['create_product_lquantity_label']                   = 'Cantidad';
$lang['create_product_ltipo_label']                       = 'Tipo';
$lang['create_product_ldescription_label']                = 'Descripci&oacuten';
$lang['create_product_lserie_label']                      = 'N&deg Serie';
$lang['create_product_ldate_label']                       = 'Fecha de compra';
$lang['create_product_limei_label']                       = 'IMEI';
$lang['create_product_lmarca_label']                      = 'Marca';
$lang['create_product_lmodel_label']                      = 'Modelo';
$lang['create_product_lstatus_label']                     = 'Estado';
$lang['create_product_lasig_label']                       = '�Asignado?';
$lang['create_product_lcost_label']                       = 'Costo Unitario';
$lang['create_product_los_label']                         = 'OS';
$lang['create_product_lram_label']                        = 'RAM';
$lang['create_product_lhdd_label']                        = 'HDD';
$lang['create_product_lcpu_label']                        = 'Procesador';
$lang['create_product_luser_assigned_label']              = 'Asignar a';
$lang['create_product_lassigned_label']                   = 'Asignado a';
$lang['create_product_lsearch_label']                     = 'Buscar';
$lang['create_product_cancel_btn']                        = '  Cancelar   ';

$lang['create_product_name_label']                       = 'Producto';
$lang['create_product_tipo_label']                       = 'Tipo';
$lang['create_product_description_label']                = 'Descripci&oacuten';
$lang['create_product_serie_label']                      = 'N� Serie';
$lang['create_product_date_label']                       = 'Fecha de compra';
$lang['create_product_imei_label']                       = 'IMEI';
$lang['create_product_marca_label']                      = 'Marca';
$lang['create_product_model_label']                      = 'Modelo';
$lang['create_product_status_label']                     = 'Estado';
$lang['create_product_asig_label']                       = 'Asignado a';
$lang['create_product_quantity_label']                   = 'Restante';
$lang['create_product_cost_label']                       = 'Costo Unitario';
$lang['create_product_lquantity_label']                  = 'Cantidad';

//Edit product
$lang['edit_product_edit']                               = 'Editar';
$lang['edit_product_delete']                             = 'Eliminar';
$lang['edit_product_heading']                            = 'Editar Producto';
$lang['edit_product_submit_btn']                         = 'Guardar Producto';

$lang['index_permission_th']        					 = 'Permisos';
$lang['index_status_desactive_user']       				 = '&iquest;Desea desactivar al usuario?';
$lang['index_status_activate_user']        				 = '&iquest;Desea activar al usuario?';
$lang['index_message_welcome'] 						     = "Usted ha ingresado al Sistema de Inventario";
$lang['index_quantity'] 						     = "Total / Disponible";

//Send Email
$lang['send_email_heading']                           = 'Solicitar Producto';
$lang['send_email_submit_btn']                        = 'Enviar Solicitud';
$lang['send_email_name']                        	  = 'Nombre Completo';
$lang['send_email_jobtitle']                          = 'Cargo';
$lang['send_email_msg']              	              = 'Mensaje';
$lang['send_email_email']                             = 'Correo';
$lang['send_email_message']			 				  = 'Desea eliminar el mensaje de: ';
$lang['send_email_delete_message']			 		  = 'El mensaje ha sido eliminado con &eacute;xito';

//Varios
$lang['site_success']                             = '&Eacutexito';
$lang['site_error']                               = 'Error';
$lang['site_info']                                = 'Informaci&oacute;n';
$lang['site_correo']                              = 'Correo';
$lang['site_password']                            = 'Contrase&ntildea';
$lang['site_message']							  = 'Bandeja de Entrada';
$lang['site_delete_message_confirm']			  = 'Seguro de eliminar el mensaje seleccionado?';
$lang['site_select_table']			 			  = 'Seleccionar Tabla';
$lang['site_close']                               = 'Cerrar';
$lang['site_faq']                                 = 'FAQ';
$lang['site_graphic']                             = 'Gr&aacute;fico';
$lang['site_print']                               = 'Imprimir';
$lang['site_change']                              = 'Cambiar';
$lang['site_language']                              = 'Idioma';
$lang['site_user']                              = 'Usuario';
$lang['site_quantity']                              = 'Cantidad';
$lang['site_select']			 			  = 'Seleccionar';
$lang['site_request']			 			  = 'Solicitud';
$lang['site_rut']			 			  = 'El rut es inv&aacute;lido';

//Reportes
$lang['create_reports_heading']				      = 'Crear Reporte';
$lang['create_reports_submit_btn']				  = 'Crear Reporte';
$lang['create_reports_table']				 	  = 'Tabla';
$lang['create_reports_name']				 	  = 'Nombre Reporte';
$lang['create_reports_fields']				 	  = 'Campos';
$lang['create_reports_condition']				  = 'Condici&oacuten';
$lang['create_reports_option']				  	  = 'Opciones';
$lang['create_reports_operation']		  		  = 'Operador';
$lang['create_reports_value_operation']		  	  = 'Valor';
$lang['create_reports_value_between']		  	  = '-';
$lang['create_reports_and']		  	              = 'Y';
$lang['create_reports_or']		  	              = 'O';
$lang['create_reports_sort_by']		  	          = 'Ordenar por';
$lang['create_reports_asc']		  	      	      = 'ASC';
$lang['create_reports_desc']		  	      	  = 'DESC';
$lang['create_reports_limit_for']		  	      = 'Limitar por';
$lang['create_reports_asc_desc']		  	      = 'De forma';
$lang['create_reports_andor_cancel']		  	  = 'Cancelar';
$lang['create_reports_join_table']				  = 'Tabla Join';
$lang['create_reports_change_confirm'] = '&iquest;Est&aacute; seguro de fijar como est&aacute;tico el reporte seleccionado?';
$lang['create_reports_delete_confirm'] = '&iquest;Est&aacute; seguro de eliminar el reporte seleccionado?';
$lang['create_reports_type']					  = 'Tipo de Reporte';
$lang['create_report_count']					  = 'Contar';
$lang['create_report_join']					  = 'Combinar Tablas';

//menu
$lang['menu_select_lang_i'] 					  = "Ingl&eacute;s";
$lang['menu_select_lang_e'] 					  = "Espa&ntilde;ol";
$lang['menu_in'] 					  = "Inicio";
$lang['menu_au'] 					  = "Adm Usuarios";
$lang['menu_ap'] 					  = "Adm Productos";
$lang['menu_re'] 					  = "Informes";
$lang['menu_id'] 					  = "Idioma";

$lang['search_user'] 					  = "Nombre y/o Apellido...";
$lang['search_product'] 			      = "Tipo de Producto...";

$lang['allocate_user'] 			      = "Seleccione funcionario";
$lang['allocate_quantity'] 			      = "Cantidad";
$lang['allocate_product']					="Asignar Producto";
$lang['allocate_view']					="Ver Asignados";
$lang['site_allocate']					="Asignados";

//imprimir grafico
$lang['jpeg'] = "Descargar JPEG";
$lang['pdf'] = "Descargar PDF";
$lang['png'] = "Descargar PNG";
$lang['svg'] = "Descargar SVG";
$lang['print_chart'] = "Imprimir gr&aacute;fico";