<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Auth Lang - English
*
* Author: Ben Edmunds
* 		  ben.edmunds@gmail.com
*         @benedmunds
*
* Author: Daniel Davis
*         @ourmaninjapan
* 
* Author: Josue Ibarra
*         @josuetijuana
*
* Location: http://github.com/benedmunds/ion_auth/
*
* Created:  03.09.2013
*
* Description:  Spanish language file for Ion Auth example views
*
*/

// Errors
$lang['error_csrf'] = 'This form does not pass our security tests.';

// Login
$lang['login_heading']         = 'Login';
$lang['login_subheading']      = 'Please enter your Email/UserName and password down here.';
$lang['login_identity_label']  = 'Email';
$lang['login_password_label']  = 'Password';
$lang['login_remember_label']  = 'Remember me';
$lang['login_submit_btn']      = 'Sign in';
$lang['login_forgot_password'] = 'Forgot Your Password?';

// Index
$lang['index_heading']           = 'Users Administration';
$lang['index_subheading']        = 'Below is a list of users.';
$lang['index_fname_th']          = 'Name';
$lang['index_rut_th']		     = 'ID';
$lang['index_lname_th']          = 'LastName';
$lang['index_email_th']          = 'Email';
$lang['index_groups_th']         = 'Groups';
$lang['index_status_th']         = 'Status';
$lang['index_action_th']         = 'Actions';
$lang['index_active_link']       = 'Active';
$lang['index_inactive_link']     = 'InActive';
$lang['index_create_user_link']  = 'Create new user';
$lang['index_create_group_link'] = 'Create new group';
$lang['index_logout'] = 'Logout';
$lang['index_edit_user'] = 'Edit';
$lang['index_view_user'] = 'View';
$lang['index_status_th'] = 'Active';
$lang['index_delete_th'] = 'Remove';
$lang['index_read_th'] = 'Read';
$lang['index_cancel_th'] = 'Cancel';
$lang['index_accept_th'] = 'Accept';
$lang['index_delete_user_confirm'] = 'Are you sure to remove the selected user?';
$lang['index_delete_product_confirm'] = 'Are you sure to remove the product with serial number?';
$lang['index_title']				  ="Stock Management";
$lang['index_confirm_action']	    	="Confirm Action";
$lang['index_export_excel']					="Export to Excel";
$lang['index_info']					   ="Information";
$lang['index_info_user']					="Official Information";
$lang['index_info_prod']					="Information Products Assigned";
$lang['index_no_results_found']					="No matches found";
$lang['index_warning']					="Attention";
$lang['index_no_report']					="Dynamic Report not found in database";
$lang['index_request']					="You do not have associated products, if you want to make an application click the following link";


// Deactivate User
$lang['deactivate_heading']                  = 'User Deactivate';
$lang['deactivate_subheading']               = 'Sure you want to disable the user?\'%s\'';
$lang['deactivate_confirm_y_label']          = 'Yes:';
$lang['deactivate_confirm_n_label']          = 'No:';
$lang['deactivate_submit_btn']               = 'Send';
$lang['deactivate_validation_confirm_label'] = 'confirmation';
$lang['deactivate_validation_user_id_label'] = 'User ID';

// Create User
$lang['create_user_heading']                           = 'Create User';
$lang['create_user_subheading']                        = 'Please, register your user information down here.';
$lang['create_user_fname_label']                       = 'Name';
$lang['create_user_lname_label']                       = 'LastName';
$lang['create_user_company_label']                     = 'Area';
$lang['create_user_email_label']                       = 'Email';
$lang['create_user_phone_label']                       = 'Phone';
$lang['create_user_password_label']                    = 'Password';
$lang['create_user_password_confirm_label']            = 'Confirm Password';
$lang['create_user_submit_btn']                        = 'Create User';
$lang['create_product_submit_btn']                     = 'Create Product';
$lang['create_user_lrut_label']                        = 'ID';
$lang['create_user_ldate_admission_label']             = 'Date of Admission';
$lang['create_user_cancel_btn']                        = 'Cancel';

$lang['create_user_validation_fname_label']            = 'Name';
$lang['create_user_validation_lname_label']            = 'LastName';
$lang['create_user_validation_email_label']            = 'Email';
$lang['create_user_validation_lphone_label']           = 'Phone Number';
$lang['create_user_validation_phone2_label']           = 'Second Phone Number';
$lang['create_user_validation_phone3_label']           = 'Third Phone Number';
$lang['create_user_validation_company_label']          = 'Name of Company';
$lang['create_user_validation_password_label']         = 'Password';
$lang['create_user_validation_password_confirm_label'] = 'Confirm Password';
$lang['create_user_validation_jobtitle_label']         = 'Job';
$lang['create_user_validation_area_label']		   = 'Area';

$lang['create_user_jobtitle_label']                     = 'Job';

// Edit User
$lang['edit_user_heading']                           = 'Edit User';
$lang['edit_user_subheading']                        = 'Please, register your user information down here.';
$lang['edit_user_fname_label']                       = 'Name';
$lang['edit_user_lname_label']                       = 'LastName';
$lang['edit_user_company_label']                     = 'Company';
$lang['edit_user_email_label']                       = 'Email';
$lang['edit_user_phone_label']                       = 'Phone';
$lang['edit_user_password_label']                    = 'Password';
$lang['edit_user_password_confirm_label']            = 'Confirm Password';
$lang['edit_user_groups_heading']                    = 'Access Permissions';
$lang['edit_user_submit_btn']                        = 'Save User';
$lang['edit_user_validation_fname_label']            = 'Name';
$lang['edit_user_validation_lname_label']            = 'LastName';
$lang['edit_user_validation_lrut_label']             = 'ID';
$lang['edit_user_validation_email_label']            = 'Email';
$lang['edit_user_validation_phone_label']            = 'Phone Number';
$lang['edit_user_validation_phone2_label']           = 'Second Phone Number';
$lang['edit_user_validation_phone3_label']           = 'Third Phone Number';
$lang['edit_user_validation_company_label']          = 'Company';
$lang['edit_user_validation_groups_label']           = 'Groups';
$lang['edit_user_validation_password_label']         = 'Password';
$lang['edit_user_validation_password_confirm_label'] = 'Confirm Password';

// Create Group
$lang['create_group_title']                  = 'Create group';
$lang['create_group_heading']                = 'Create Group';
$lang['create_group_subheading']             = 'Please, register the Group Information.';
$lang['create_group_name_label']             = 'Name of Group:';
$lang['create_group_desc_label']             = 'Description:';
$lang['create_group_submit_btn']             = 'Create Group';
$lang['create_group_validation_name_label']  = 'Name of Group';
$lang['create_group_validation_desc_label']  = 'Description';

// Edit Group
$lang['edit_group_title']                  = 'Edit Group';
$lang['edit_group_saved']                  = 'Save Group';
$lang['edit_group_heading']                = 'Edit Group';
$lang['edit_group_subheading']             = 'Please, register the Group Information down here.';
$lang['edit_group_name_label']             = 'Name of Group:';
$lang['edit_group_desc_label']             = 'Description:';
$lang['edit_group_submit_btn']             = 'Save Group';
$lang['edit_group_validation_name_label']  = 'Name of Group';
$lang['edit_group_validation_desc_label']  = 'Description';

// Change Password
$lang['change_password_heading']                               = 'Change Password';
$lang['change_password_old_password_label']                    = 'Old Password:';
$lang['change_password_new_password_label']                    = 'New Password (at least %s characters long):';
$lang['change_password_new_password_confirm_label']            = 'Confirm New Password:';
$lang['change_password_submit_btn']                            = 'Change';
$lang['change_password_validation_old_password_label']         = 'Old Password:';
$lang['change_password_validation_new_password_label']         = 'New Password:';
$lang['change_password_validation_new_password_confirm_label'] = 'Confirm New Password:';

// Forgot Password
$lang['forgot_password_heading']                 = 'I forget my Password';
$lang['forgot_password_subheading']              = 'Please enter your %s so that we can send you an email to reset your Password.';
$lang['forgot_password_email_label']             = '%s:';
$lang['forgot_password_submit_btn']              = 'Send';
$lang['forgot_password_validation_email_label']  = 'Email';
$lang['forgot_password_username_identity_label'] = 'User';
$lang['forgot_password_email_identity_label']    = 'Email';
$lang['forgot_password_email_not_found']         = 'No record of that Email address.';

// Reset Password
$lang['reset_password_heading']                               = 'Change Password';
$lang['reset_password_new_password_label']                    = 'New Password (at least %s characters long):';
$lang['reset_password_new_password_confirm_label']            = 'Confirm New Password:';
$lang['reset_password_submit_btn']                            = 'Change';
$lang['reset_password_validation_new_password_label']         = 'Old Password';
$lang['reset_password_validation_new_password_confirm_label'] = 'Confirm New Password';

// Activation Email
$lang['email_activate_heading']    = 'Activate account for %s';
$lang['email_activate_subheading'] = 'Please enter this link to %s.';
$lang['email_activate_link']       = 'Activate your Account';

// Forgot Password Email
$lang['email_forgot_password_heading']    = 'Reset Password for %s';
$lang['email_forgot_password_subheading'] = 'Please enter this link to %s.';
$lang['email_forgot_password_link']       = 'Reset Your Password';

// New Password Email
$lang['email_new_password_heading']    = 'New Password for %s';
$lang['email_new_password_subheading'] = 'Your password has been reset to: %s';
$lang['home_welcome'] = 'Welcome ';


//product
$lang['admin_product_heading']           = 'Administration Products';
$lang['admin_product_create_link']  	 = 'Create New Product';

//reports
$lang['reports_heading']           = 'Reports';
$lang['reports_inform_dinamic']    = 'Dynamic Reports'; 
$lang['reports_inform_static']    = 'Static Reports';
$lang['reports_action']            = 'Export';

//statistics
$lang['statistics_heading']           = 'Management';

$lang['back']            = 'Back';

//create product
$lang['create_product_heading']                           = 'Create Product';
$lang['create_product_lquantity_label']                   = 'Quantity';
$lang['create_product_ltipo_label']                       = 'Type';
$lang['create_product_ldescription_label']                = 'Description';
$lang['create_product_lserie_label']                      = 'Serial Number';
$lang['create_product_ldate_label']                       = 'Date Of Purchase';
$lang['create_product_limei_label']                       = 'IMEI';
$lang['create_product_lmarca_label']                      = 'TradeMark';
$lang['create_product_lmodel_label']                      = 'Model';
$lang['create_product_lstatus_label']                     = 'Status';
$lang['create_product_lasig_label']                       = 'Assigned?';
$lang['create_product_lcost_label']                       = 'Unit Cost';
$lang['create_product_los_label']                         = 'OS';
$lang['create_product_lram_label']                        = 'RAM';
$lang['create_product_lhdd_label']                        = 'HDD';
$lang['create_product_lcpu_label']                        = 'Processor';
$lang['create_product_luser_assigned_label']              = 'Assign to';
$lang['create_product_lassigned_label']                   = 'Assigned To';
$lang['create_product_lsearch_label']                     = 'Search';
$lang['create_product_cancel_btn']                        = '  Cancel   ';

$lang['create_product_name_label']                       = 'Product';
$lang['create_product_tipo_label']                       = 'Type';
$lang['create_product_description_label']                = 'Description';
$lang['create_product_serie_label']                      = 'Serial Number';
$lang['create_product_date_label']                       = 'Date Of Purchase';
$lang['create_product_imei_label']                       = 'IMEI';
$lang['create_product_marca_label']                      = 'TradeMark';
$lang['create_product_model_label']                      = 'Model';
$lang['create_product_status_label']                     = 'Status';
$lang['create_product_asig_label']                       = 'Assigned To';
$lang['create_product_quantity_label']                   = 'Quantity';
$lang['create_product_cost_label']                       = 'Unit Cost';

//Edit product
$lang['edit_product_edit']                               = 'Edit';
$lang['edit_product_delete']                             = 'Remove';
$lang['edit_product_heading']                            = 'Edit Product';
$lang['edit_product_submit_btn']                         = 'Save Product';

$lang['index_permission_th']        					 = 'Permissions';
$lang['index_status_desactive_user']       				 = 'Want to disable the user?';
$lang['index_status_activate_user']        				 = 'Want to enable the user?';
$lang['index_message_welcome'] 						     = "You to entered the Inventory System";
$lang['index_quantity'] 						         = "Total / Rest";

//Send Email
$lang['send_email_heading']                           = 'Request Product';
$lang['send_email_submit_btn']                        = 'Send Request';
$lang['send_email_name']                        	  = 'FullName';
$lang['send_email_jobtitle']                          = 'Job';
$lang['send_email_msg']              	              = 'Message';
$lang['send_email_email']                             = 'Email';
$lang['send_email_message']			 				  = 'Want remove the message of ?: ';
$lang['send_email_delte_message']			 		  = 'The message has been successfully removed';

//Varios
$lang['site_success']                             = 'Success';
$lang['site_error']                               = 'Error';
$lang['site_info']                                = 'Information';
$lang['site_correo']                              = 'Email';
$lang['site_password']                            = 'Password';
$lang['site_message']							  = 'InBox';
$lang['site_delete_message_confirm']			  = 'Are you sure to remove the selected message?';
$lang['site_select_table']			 			  = 'Select Table';
$lang['site_close']                               = 'Close';
$lang['site_faq']                                 = 'FAQ';
$lang['site_graphic']                             = 'Graphic';
$lang['site_print']                               = 'Print';
$lang['site_change']                              = 'Change';

//Reportes
$lang['create_reports_heading']				      = 'Create Report';
$lang['create_reports_submit_btn']				  = 'Create Report';
$lang['create_reports_table']				 	  = 'Table';
$lang['create_reports_name']				 	  = 'Name Report';
$lang['create_reports_fields']				 	  = 'Fields';
$lang['create_reports_condition']				  = 'Conditions';
$lang['create_reports_option']				  	  = 'Options';
$lang['create_reports_operation']		  		  = 'Operator';
$lang['create_reports_value_operation']		  	  = 'Value';
$lang['create_reports_value_between']		  	  = '-';
$lang['create_reports_and']		  	              = 'AND';
$lang['create_reports_or']		  	              = 'OR';
$lang['create_reports_sort_by']		  	          = 'Order By';
$lang['create_reports_asc']		  	      	      = 'ASC';
$lang['create_reports_desc']		  	      	  = 'DESC';
$lang['create_reports_limit_for']		  	      = 'Limit for';
$lang['create_reports_asc_desc']		  	      = 'Form';
$lang['create_reports_andor_cancel']		  	  = 'Cancel';
$lang['create_reports_join_table']				  = 'Join Table';
$lang['create_reports_change_confirm'] = 'Are you sure to set like static the selected report?';
$lang['create_reports_delete_confirm'] = 'Are you sure to remove the selected report?';

//menu
$lang['menu_select_lang_i'] 					  = "English";
$lang['menu_select_lang_e'] 					  = "Spanish";
$lang['menu_in'] 					  = "Home";
$lang['menu_au'] 					  = "Adm Users";
$lang['menu_ap'] 					  = "Adm Products";
$lang['menu_re'] 					  = "Reports";
$lang['menu_id'] 					  = "Language";

$lang['search_user'] 					  = "Name y/o LastName...";
$lang['search_product'] 			      = "Product Type...";