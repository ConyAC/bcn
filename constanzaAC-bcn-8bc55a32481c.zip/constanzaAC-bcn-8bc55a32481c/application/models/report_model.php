<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->config('ion_auth', TRUE);
		$this->load->helper('cookie');
		$this->load->helper('date');
		$this->lang->load('ion_auth');
		
		$this->tables  = $this->config->item('tables', 'ion_auth');
		$this->_ion_hooks = new stdClass;

	}	
	
	protected function _call_hook($event, $name)
	{
		if (isset($this->_ion_hooks->{$event}[$name]) && method_exists($this->_ion_hooks->{$event}[$name]->class, $this->_ion_hooks->{$event}[$name]->method))
		{
			$hook = $this->_ion_hooks->{$event}[$name];
	
			return call_user_func_array(array($hook->class, $hook->method), $hook->arguments);
		}
	
		return FALSE;
	}
	
	public function trigger_events($events)
	{
		if (is_array($events) && !empty($events))
		{
			foreach ($events as $event)
			{
				$this->trigger_events($event);
			}
		}
		else
		{
			if (isset($this->_ion_hooks->$events) && !empty($this->_ion_hooks->$events))
			{
				foreach ($this->_ion_hooks->$events as $name => $hook)
				{
					$this->_call_hook($events, $name);
				}
			}
		}
	}
	
	protected function _filter_data($table, $data)
	{
		$filtered_data = array();
		$columns = $this->db->list_fields($table);
	
		if (is_array($data))
		{
			foreach ($columns as $column)
			{
				if (array_key_exists($column, $data))
					$filtered_data[$column] = $data[$column];
			}
		}
	
		return $filtered_data;
	}
	public function get_all_user_from_company(){
	
		$query = $this->db->query('SELECT DISTINCT (SELECT COUNT(active) FROM users WHERE active = 1) AS active,
				(SELECT COUNT(active) FROM users WHERE active = 0) AS desactive FROM users');
	
		if ($query->num_rows() > 0){
			$results = $query->result_array();
			//echo print_r($results);
		}
		return $results;
	}
	
	public function get_all_type_products(){
	
		$query = $this->db->query('SELECT DISTINCT (SELECT COUNT(type) FROM product WHERE type = 1) AS movil,
				(SELECT COUNT(type) FROM product WHERE type = 2) AS pc,
				(SELECT COUNT(type) FROM product WHERE type = 3) AS notebook,
				(SELECT COUNT(type) FROM product WHERE type = 4) AS componente,
				(SELECT COUNT(type) FROM product WHERE type = 5) AS conectividad,
				(SELECT COUNT(type) FROM product WHERE type = 6) AS perifericos FROM product');
	
		if ($query->num_rows() > 0){
			$results = $query->result_array();
			//echo print_r($results);
		}
		return $results;
	}
	
	public function get_all_status_products(){
		$query = $this->db->query('SELECT DISTINCT (SELECT COUNT(statusId) FROM product WHERE statusId = 1) AS nuevo,
				(SELECT COUNT(statusId) FROM product WHERE statusId = 2) AS disponible,
				(SELECT COUNT(statusId) FROM product WHERE statusId = 3) AS caducado,
				(SELECT COUNT(statusId) FROM product WHERE statusId = 4) AS asignado FROM product');
	
		if ($query->num_rows() > 0){
			$results = $query->result_array();
			//echo print_r($results);
		}
		return $results;
	}
	
	public function get_all_assigned_products(){
		$query = $this->db->query('SELECT DISTINCT (SELECT COUNT(productId) FROM product WHERE user_assignedId is not null) AS assigned,
				(SELECT COUNT(productId) FROM product WHERE user_assignedId is null) AS available FROM product');
	
		if ($query->num_rows() > 0){
			$results = $query->result_array();
			//echo print_r($results);
		}
		return $results;
	}
	
	public function get_select_tables(){
	
		$query = $this->db->query('SELECT report_tablesId, name FROM report_tables ORDER BY name asc');
		$return = array();
		$return[''] = 'Seleccionar';
		if ($query->num_rows() > 0){
			foreach ($query->result_array() as $row)
			{
				$return[$row['report_tablesId']] = $row['name'];
			}
			return $return;
		}
	}
	
	public function get_select_fields_by_table($table){
			
		$query = $this->db->query('SELECT rf.report_fieldsId id, rf.name name, rf.key_name key_name FROM report_tables_fields rtf, report_fields rf WHERE report_tablesId ='.$table.' AND rtf.report_fieldsId = rf.report_fieldsId');			
		$return = array();
		$return[''] = 'Seleccionar';
		if ($query->num_rows() > 0){
			$results = $query->result();
			return $results;
		}
	}
	
	public function get_select_field_condition($table){
			
		$query = $this->db->query('SELECT rf.report_fieldsId id, rf.name name, rf.key_name key_name FROM report_tables_fields rtf, report_fields rf WHERE report_tablesId ='.$table.' AND rtf.report_fieldsId = rf.report_fieldsId');
		$return = array();
		$return[''] = 'Seleccionar';
		if ($query->num_rows() > 0){
			$results = $query->result();
			return $results;
		}
	}
	public function report_user_report(){
	
		$active = "Activado";
		$desactive = "Desactivado";
		$query = $this->db->query("SELECT u.first_name AS NOMBRE, u.last_name As APELLIDO, u.rut AS RUT, u.email AS EMAIL,
				j.name AS CARGO, if (u.active = 1,'". $active ."','". $desactive."') AS ESTADO FROM users u, jobtitle j WHERE u.jobtitleId = j.jobtitleId");
		//$return = array();
		//$return[''] = 'Seleccionar';
		/*if ($query->num_rows() > 0){
			$results = $query->result();
			//echo print_r($results);
			return $results;
		}*/
		return $query;
	}
	
	public function get_select_operator(){
	
		$query = $this->db->query('SELECT operatorId, name FROM operator ORDER BY name asc');
		$return = array();
		$return[''] = 'Seleccionar';
		if ($query->num_rows() > 0){
			foreach ($query->result_array() as $row)
			{
				$return[$row['operatorId']] = $row['name'];
			}
			return $return;
		}
	}
	
	/**
	 * Funci�n que permite guardar un reporte
	 * @param unknown_type $additional_data
	 */
	public function register_report( $additional_data = array())
	{
		$this->trigger_events('pre_register');
		$report_data = array_merge($this->_filter_data($this->tables['report'], $additional_data));
	
		$this->trigger_events('extra_set');
	
		$this->db->insert($this->tables['report'], $report_data);
	
		$id = $this->db->insert_id();	
		$this->trigger_events('post_register');
	
		return (isset($id)) ? $id : FALSE;
	}
	
	/**
	 * Cambiar el tipo del reporte
	 * @param unknown_type $id_report
	 */
	public function change_report($id_report){
	
		$query = $this->db->query("UPDATE report SET static = 1 WHERE reportId =".$id_report);
		return $query;
	}
	
	/**
	 * Eliminar un determinado reporte
	 * @param unknown_type $id_report
	 */
	 public function delete_report($id_report){
	
		$query = $this->db->query("UPDATE report SET deleted = 1 WHERE reportId =".$id_report);
		return $query;
	}
	
	/**
	 * Obtener la informaci�n de un determinado reporte
	 * @param unknown_type $id_report
	 */
	public function view_report($id_report){
	
		$query = $this->db->query("SELECT p.productId, p.serialNumber, p.datePurchase, p.imei, p.ram, p.hdd, p.cost, p.quantity, p.cpu,
				p.productId, p.user_assignedId usuarioId, p.type tipo, p.description, u.id, u.first_name nombre, u.last_name apellido,
				m.name modelo, ps.name estado, t.name tipo, tm.name marca, os.name sistema
				FROM product p
				LEFT JOIN users u ON p.user_assignedId = u.Id
				LEFT JOIN model m ON p.modelId = m.modelId
				LEFT JOIN product_status ps ON p.statusId = ps.product_statusId
				LEFT JOIN type t ON p.type = t.typeId
				LEFT JOIN trademark tm ON p.trademarkId = tm.trademarkId
				LEFT JOIN operating_system os ON p.operating_systemId = os.osId
				WHERE p.productId = ".$id_report);
			
		if ($query->num_rows() > 0){
			//echo print_r($results);
			return $results = $query->result_array();
		}
	}
	
	public function get_report_by_id($id_report){
	
		$query = $this->db->query("SELECT * FROM report WHERE reportId = ".$id_report);
			
		if ($query->num_rows() > 0){
			$results = $query->result_array();
			//echo print_r($results);
			return $results;
		}
	}
	
	public function get_report($id_report){
	
		$query = $this->db->query("SELECT r.* , rt.key_name FROM report r
								  LEFT JOIN report_tables rt ON rt.report_tablesId = r.table
								  WHERE reportid =".$id_report);
			
		if ($query->num_rows() > 0){
			$results = $query->result_array();
			return $this->report_model->get_data_report($results);
		}
	}
	
	public function get_data_report($results){
		/*array(1) { [0]=> array(19) { ["reportId"]=> string(2) "31" ["name"]=> string(25) "Funcionarios totales 2014" ["static"]=> string(1) "1" 
		 * ["table"]=> string(1) "8" ["fields"]=> string(10) "first_name" ["table_join"]=> string(1) "0" ["fields_where"]=> string(1) "0" 
		 * ["operator"]=> string(1) "1" ["first_value"]=> string(9) "constanza" ["second_value"]=> string(0) "" ["and_or"]=> string(1) "0" 
		 * ["order_by"]=> string(9) "last_name" ["asc_desc"]=> string(3) "asc" ["limit"]=> string(1) "0" 
		 * ["date_creation"]=> string(19) "2014-08-31 23:08:24" ["description"]=> string(4) "test" ["deleted"]=> string(1) "0" ["count"]=> string(1) "1" 
		 * ["key_name"]=> string(5) "users" } } */

		if($results != null){			
			$query= $this->db->query("SELECT ".$results[0]['fields']." FROM ".$results[0]['key_name']);
			return $query;			
		}		
	}
}
