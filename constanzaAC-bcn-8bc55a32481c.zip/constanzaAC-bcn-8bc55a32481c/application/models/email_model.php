<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_model extends CI_Model
{
	
	public $tables = array();
	protected $_ion_hooks;
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->config('ion_auth', TRUE);
		$this->load->helper('cookie');
		$this->load->helper('date');
		$this->lang->load('ion_auth');
		
		$this->tables  = $this->config->item('tables', 'ion_auth');

	}	
	
	public function trigger_events($events)
	{
		if (is_array($events) && !empty($events))
		{
			foreach ($events as $event)
			{
				$this->trigger_events($event);
			}
		}
		else
		{
			if (isset($this->_ion_hooks->$events) && !empty($this->_ion_hooks->$events))
			{
				foreach ($this->_ion_hooks->$events as $name => $hook)
				{
					$this->_call_hook($events, $name);
				}
			}
		}
	}
	
	protected function _filter_data($table, $data)
	{
		$filtered_data = array();
		$columns = $this->db->list_fields($table);
	
		if (is_array($data))
		{
			foreach ($columns as $column)
			{
				if (array_key_exists($column, $data))
					$filtered_data[$column] = $data[$column];
			}
		}
	
		return $filtered_data;
	}
	
	public function save_message_email($additional_data = array()){
		
		$this->trigger_events('pre_register');
		$send_email_data = array_merge($this->_filter_data($this->tables['send_email'], $additional_data));	
		$this->trigger_events('extra_set');	
		$this->db->insert($this->tables['send_email'], $send_email_data);	
		$id = $this->db->insert_id();	
		$this->trigger_events('post_register');
	
			return (isset($id)) ? $id : FALSE;	
		
	}
	
	public function get_message_by_id(){
	
		$id = $_POST['id'];
		$query = $this->db->query('SELECT se.send_emailId, se.name, se.email, se.message_user, se.jobtitle, se.viewed FROM send_email se WHERE se.send_emailId ='.$id);
	
		if ($query->num_rows() > 0){
			return $results = $query->result_array();
		}
	}
	
	public function set_read_message(){
	
		$id = $_POST['id'];
		$query = $this->db->query('UPDATE send_email SET viewed = 1 WHERE send_emailId ='.$id);
		return $query;
	}
	
	public function delete_message($id_message){
		$query = $this->db->query('DELETE FROM send_email WHERE send_emailId ='.$id_message);
		return $query;
	}
}
