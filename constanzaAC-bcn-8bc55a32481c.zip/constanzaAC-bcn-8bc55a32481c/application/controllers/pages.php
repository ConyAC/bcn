<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('ion_auth');
		$this->load->library('form_validation');
		
		$this->load->helper('url');
	
		// Load MongoDB library instead of native db driver if required
		$this->config->item('use_mongodb', 'ion_auth') ?
		$this->load->library('mongo_db') :
	
		$this->load->database();
	
		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
	
		//$this->lang->load('auth'); lo comento para poder cargar el idioma seleccionado por el usuario.
		$this->load->helper('language');		
		$this->load->library('pagination');
	}
	
	function _valid_csrf_nonce()
	{
		if ($this->input->post($this->session->flashdata('csrfkey')) !== FALSE &&
			$this->input->post($this->session->flashdata('csrfkey')) == $this->session->flashdata('csrfvalue'))
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	
	public function view($page = 'home')
	{
		if ( !file_exists('application/views/pages/'.$page.'.php'))
		{
			// Oh-oh... no tenemos una pagina para esto!
			show_404();
		}

		$data['title'] = ucfirst($page); // Capitaliza la primera letra
		$this->load->view('template/header', $data);
		$this->load->view('pages/'.$page, $data);
		$this->load->view('template/footer', $data);
	}
	
	function _render_page($view, $data=null, $render=false)
	{
	
		$this->viewdata = (empty($data)) ? $this->data: $data;
	
		$view_html = $this->load->view($view, $this->viewdata, $render);
	
		if (!$render) return $view_html;
	}
	
	function adminProduct()
	{
	
		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		elseif (!$this->ion_auth->is_admin()) //remove this elseif if you want to enable this for non-admins
		{
			//redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else
		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['trademarkList'] = $this->ion_auth_model->get_select_trademark();
			$this->data['typeId'] = $this->ion_auth_model->get_select_type();
			$this->data['modelId'] = $this->ion_auth_model->get_select_model();
			$this->data['status_productId'] = $this->ion_auth_model->get_select_status();
			$this->data['osId'] = $this->ion_auth_model->get_select_os();
			$this->data['user_assigned'] = $this->ion_auth_model->get_select_user_assigned();
			
			$this->data['product'] = $this->ion_auth_model->get_product_all();
				
			$this->_render_page('pages/admin_product', $this->data);
		}
	}

	function reports()
	{			
		
		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		elseif (!$this->ion_auth->is_admin()) //remove this elseif if you want to enable this for non-admins
		{
			//redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else
		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
	
			$this->data['report'] = $this->ion_auth_model->get_report_all();	
			$this->data['report_dinamic'] = $this->ion_auth_model->get_report_dinamic();
			$this->_render_page('pages/reports', $this->data);
		}
	}
	
	function statistics()
	{
	
		if (!$this->ion_auth->logged_in())
		{
			//redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		elseif (!$this->ion_auth->is_admin()) //remove this elseif if you want to enable this for non-admins
		{
			//redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else
		{
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
	
			//list the users
			$this->data['users'] = $this->ion_auth->users()->result();
			foreach ($this->data['users'] as $k => $user)
			{
				$this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}
	
			$this->_render_page('pages/statistics', $this->data);
		}
	}

	//create product
	function create_product()
	{
		$this->data['title'] = "Crear Producto";
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}
		
		$this->data['trademarkList'] = $this->ion_auth_model->get_select_trademark();
		$this->data['typeId'] = $this->ion_auth_model->get_select_type();
		$this->data['modelId'] = $this->ion_auth_model->get_select_model();
		$this->data['status_productId'] = $this->ion_auth_model->get_select_status();
		$this->data['osId'] = $this->ion_auth_model->get_select_os();
		$this->data['user_assigned'] = $this->ion_auth_model->get_select_user_assigned();
		
		//validate form input
		$this->form_validation->set_rules('serialNumber', $this->lang->line('create_product_lserie_label'), 'required|xss_clean');
		$this->form_validation->set_rules('trademarkId', $this->lang->line('create_product_lmarca_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('type', $this->lang->line('create_product_ltipo_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('modelId', $this->lang->line('create_product_lmodel_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('statusId', $this->lang->line('create_product_lstatus_label'), 'required|check_dropdown');			
	
		if ($this->form_validation->run() == true){
			$date = new DateTime ($this->input->post('dateAdmission'));
			$dateAdmission = date_format($date, 'Y-d-m H:i:s');
			
		if($this->input->post('type') == 1 || $this->input->post('type') == 2){
			$additional_data_user_product = array('quantity' => 1, 'userId' => $this->input->post('user_assignedId'));
		}else{
			$q = $this->input->post('quantity');
			if($q > 1){
				$additional_data_user_product = array('quantity' => $q, 'total' => $q);
			}else{
				$additional_data_user_product = array('quantity' => $q, 'userId' => $this->input->post('user_assignedId'));
			}
		}
		
		$date = new DateTime ($this->input->post('datePurchase'));
		$datePurchase = date_format($date, 'Y-d-m H:i:s');
			
		//($this->input->post('type') == 1 || $this->input->post('type') == 2)?$q = 1: $q = $this->input->post('quantity');
		$data= array(
				$additional_data_product = array(
						'imei' => $this->input->post('imei'),
						'datePurchase'  => $datePurchase,
						'cost'    => $this->input->post('cost'),
						'serialNumber'      => $this->input->post('serialNumber'),
						'description'      => $this->input->post('description'),
						'trademarkId'      => $this->input->post('trademarkId'),
						'type'      => $this->input->post('type'),
						'modelId'      => $this->input->post('modelId'),
						'statusId'      => $this->input->post('statusId'),
						'operating_systemId'      => $this->input->post('operating_systemId'),
						'ram'      => $this->input->post('ram'),
						'hdd'      => $this->input->post('hdd'),
						'cpu'      => $this->input->post('cpu')
				),
				
				$additional_data_user_product
			);
		}
		if ($this->form_validation->run() == true && $this->ion_auth->register_prod($data))
		{
			redirect("pages/adminProduct", 'refresh');				
		}
		else
		{
			//display the create user form
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));
	
			$this->data['imei'] = array(
					'name'  => 'imei',
					'id'    => 'imei',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('imei'),
			);
			$this->data['datePurchase'] = array(
					'name'  => 'datePurchase',
					'id'    => 'datePurchase',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('datePurchase'),
			);
			$this->data['cost'] = array(
					'name'  => 'cost',
					'id'    => 'cost',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('cost'),
			);
			$this->data['serialNumber'] = array(
					'name'  => 'serialNumber',
					'id'    => 'serialNumber',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('serialNumber'),
			);
			$this->data['type'] = array(
					'name'  => 'type',
					'id'    => 'type',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('type'),
			);
			$this->data['quantity'] = array(
					'name'  => 'quantity',
					'id'    => 'quantity',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('quantity'),
			);
			$this->data['description'] = array(
					'name'  => 'description',
					'id'    => 'description',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('description'),
			);
			$this->data['operating_systemId'] = array(
					'name'  => 'operating_systemId',
					'id'    => 'operating_systemId',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('operating_systemId'),
			);
			$this->data['ram'] = array(
					'name'  => 'ram',
					'id'    => 'ram',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('ram'),
			);
			$this->data['hdd'] = array(
					'name'  => 'hdd',
					'id'    => 'hdd',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('hdd'),
			);
			$this->data['cpu'] = array(
					'name'  => 'cpu',
					'id'    => 'cpu',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('cpu'),
			);
			
			
			$this->_render_page('pages/create_product', $this->data);
		}
	}
		
	public function excel_test($option)
	{
		if($option == "user_report"){
			$active = "Activado";
			$desactive = "Desactivado";
			$query = $this->db->query("SELECT u.first_name AS NOMBRE, u.last_name As APELLIDO, u.rut AS RUT, u.email AS EMAIL, 
									j.name AS CARGO, if (u.active = 1,'". $active ."','". $desactive."') AS ESTADO FROM users u, jobtitle j WHERE u.jobtitleId = j.jobtitleId");
		}else{
			$query = $this->db->query('SELECT * FROM jobtitle');			
		}
	
		if(!$query)
			return false;
	
		// Starting the PHPExcel library
		$this->load->library('excel');
		$this->load->library('IoFactory');
		
		$objPHPExcel = new Excel();
		$objPHPExcel->getProperties()->setTitle("export")->setDescription("none");	
		$objPHPExcel->setActiveSheetIndex(0);
		
		$objDrawing = new PHPExcel_Worksheet_Drawing();
		$objDrawing->setName('Water_Level');
		$objDrawing->setDescription('Water_Level');
		$objDrawing->setPath('images/logo_bcn.png');
		$objDrawing->setHeight(74);
		$objDrawing->setCoordinates('O1');
		$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
	
		// Field names in the first row
		$fields = $query->list_fields();
		$col = 0;
		foreach ($fields as $field)
		{
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field)->getColumnDimensionByColumn($field)->setAutoSize(true);
			$objPHPExcel->getActiveSheet()->getStyle('A1:Z1')->getFont()->setBold(true);
			$col++;
		}
	
		// Fetching the table data
		$row = 2;
		foreach($query->result() as $data)
		{
			$col = 0;
			foreach ($fields as $field)
			{
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $data->$field)->getColumnDimensionByColumn($field)->setAutoSize(true);
				$col++;
			}
	
			$row++;
		}
	
		$objPHPExcel->setActiveSheetIndex(0);
		$objPHPExcel->getActiveSheet()->setTitle('Reporte01');		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
	
		// Sending headers to force the user to download the file
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="Reporte_'.date('dMy').'.xls"');
		header('Cache-Control: max-age=0');
	
		$objWriter->save('php://output');
	}
	
	/*no estoy ocupando este metodo de acutalizacion, el otro esta en auth*/
	function editProduct($id)
	{
		$this->data['title'] = "Edit Product";
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}
	
		$product = $this->ion_auth_model->get_product($id);
		$this->data['trademarkList'] = $this->ion_auth_model->get_select_trademark();
		
		$this->data['typeId'] = $this->ion_auth_model->get_select_type();
		$this->data['modelList'] = $this->ion_auth_model->get_select_model();
		$this->data['status_productId'] = $this->ion_auth_model->get_select_status();
		$this->data['osId'] = $this->ion_auth_model->get_select_os();
		$this->data['user_assigned'] = $this->ion_auth_model->get_select_user_assigned();
		
		//validate form input
		$this->form_validation->set_rules('datePurchase', $this->lang->line('create_product_ldate_label'), 'required|xss_clean');
		$this->form_validation->set_rules('cost', $this->lang->line('create_product_lcost_label'), 'required|xss_clean');
		$this->form_validation->set_rules('serialNumber', $this->lang->line('create_product_lserie_label'), 'required|xss_clean');
		$this->form_validation->set_rules('description', $this->lang->line('create_product_ldescription_label'), 'required|xss_clean');
		$this->form_validation->set_rules('quantity', $this->lang->line('create_product_lquantity_label'), 'required|xss_clean');
		
		$this->form_validation->set_rules('trademarkId', $this->lang->line('create_product_lmarca_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('type', $this->lang->line('create_product_ltipo_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('modelId', $this->lang->line('create_product_lmodel_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('statusId', $this->lang->line('create_product_lstatus_label'), 'required|check_dropdown');
		$this->form_validation->set_rules('operating_systemId', $this->lang->line('create_product_los_label'), 'required|check_dropdown');
			
	
		if (isset($_POST) && !empty($_POST))
		{
			// do we have a valid request?
			if ($this->_valid_csrf_nonce() === FALSE || $id != $this->input->post('id'))
			{
				show_error($this->lang->line('error_csrf'));
			}
				
			$data = array(
					'imei' => $this->input->post('imei'),
					'datePurchase'  => $this->input->post('datePurchase'),
					'cost'    => $this->input->post('cost'),
					'serialNumber'      => $this->input->post('serialNumber'),
					'quantity'      => $this->input->post('quantity'),
					'description'      => $this->input->post('description'),
					'trademarkId'      => $this->input->post('trademarkId'),
					'type'      => $this->input->post('type'),
					'modelId'      => $this->input->post('modelId'),
					'statusId'      => $this->input->post('statusId'),
					'operating_systemId'      => $this->input->post('operating_systemId'),
					'ram'      => $this->input->post('ram'),
					'hdd'      => $this->input->post('hdd'),
					'cpu'      => $this->input->post('cpu'),
					'user_assignedId' => $this->input->post('user_assignedId')
			);
	
			if ($this->form_validation->run() === TRUE)
			{
				$this->ion_auth->update_product($product['id'], $data);
	
				//check to see if we are creating the user
				//redirect them back to the admin page
				$this->session->set_flashdata('message', "Product Saved");
				redirect("pages/adminProduct", 'refresh');
			}
		}
	
		//set the flash data error message if there is one
		$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));
	
		$this->data['imei'] = array(
				'name'  => 'imei',
				'id'    => 'imei',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('imei', $product[0]['imei']),
		);
		$this->data['datePurchase'] = array(
				'name'  => 'datePurchase',
				'id'    => 'datePurchase',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('datePurchase', $product[0]['datePurchase']),
		);
		$this->data['cost'] = array(
				'name'  => 'cost',
				'id'    => 'cost',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('cost', $product[0]['cost']),
		);
		$this->data['serialNumber'] = array(
				'name'  => 'serialNumber',
				'id'    => 'serialNumber',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('serialNumber', $product[0]['serialNumber']),
		);
		$this->data['type'] = array(
				'name'  => 'type',
				'id'    => 'type',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('type', $product[0]['type']),
		);
		$this->data['modelId'] = array(
				'name'  => 'modelId',
				'id'    => 'modelId',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('modelId', $product[0]['modelId']),
		);
		
		$this->data['quantity'] = array(
				'name'  => 'quantity',
				'id'    => 'quantity',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('quantity', $product[0]['quantity']),
		);
		$this->data['description'] = array(
				'name'  => 'description',
				'id'    => 'description',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('description', $product[0]['description']),
		);
		$this->data['ram'] = array(
				'name'  => 'ram',
				'id'    => 'ram',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('ram', $product[0]['ram']),
		);
		$this->data['hdd'] = array(
				'name'  => 'hdd',
				'id'    => 'hdd',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('hdd', $product[0]['hdd']),
		);
		$this->data['cpu'] = array(
				'name'  => 'cpu',
				'id'    => 'cpu',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('cpu', $product[0]['cpu']),
		);
		$this->data['trademarkId'] = array(
				'name'  => 'trademarkId',
				'id'    => 'trademarkId',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('trademarkId', $product[0]['trademarkId']),
		);
		$this->data['statusId'] = array(
				'name'  => 'statusId',
				'id'    => 'statusId',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('statusId', $product[0]['statusId']),
		);
		$this->data['operating_systemId'] = array(
				'name'  => 'operating_systemId',
				'id'    => 'operating_systemId',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('operating_systemId', $product[0]['operating_systemId'] ),
		);
		$this->data['user_assignedId'] = array(
				'name'  => 'user_assignedId',
				'id'    => 'user_assignedId',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('user_assignedId', $product[0]['user_assignedId'] ),
		);

		$this->_render_page('pages/edit_product', $this->data);
	}
	
	
	function search_product()
	{
		$this->data['title'] = "Buscar Producto";
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}
	
		//validate form input
		$this->form_validation->set_rules('search', $this->lang->line('create_product_lsearch_label'), 'required|xss_clean');
			
		if ($this->form_validation->run() == true)
		{
			$additional_data = array(
					'search' => $this->input->post('search')
			);
		}
		if ($this->form_validation->run() == true && $this->ion_auth->search_prod($additional_data))
		{
			redirect("pages/adminProduct", 'refresh');
		}
		else
		{
			//display the create user form
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));
	
			$this->data['search'] = array(
					'name'  => 'search',
					'id'    => 'search',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('search'),
			);				

			$this->_render_page('pages/create_product', $this->data);
		}
	}
	
	function ajax_search_product()				
	{		
		if($_POST['textbox'] != ""){			
			$textbox = $_POST['textbox'];			
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');			
			$this->data['product'] = $this->ion_auth_model->get_search_product($textbox);
			
		}else if ($_POST['textbox'] == ""){
			
			$this->data['product'] = $this->ion_auth_model->get_product_all();
		}
		
		$this->_render_page('pages/admin_product', $this->data);
		
	}
	
	function ajax_delete_product(){
		if ($_POST['id_product'] != ""){
			$id_product = $_POST['id_product'];
			$delete = $this->ion_auth_model->delete_product($id_product);			
		}	
	}	
	
	function ajax_view_product(){
		if ($_POST['id_product'] != ""){
			$id_product = $_POST['id_product'];
			$this->data['product'] = $this->ion_auth_model->get_product_by_id($id_product);
			echo json_encode($this->data['product']);
		}
	}	
	
	/* OLD
	function ajax_view_jobtitle_by_departments(){
		if ($_POST['id'] != ""){
			$id = $_POST['id'];
			$this->data['department'] = $this->ion_auth_model->get_select_jobtitle_by_department($id);

			echo json_encode($this->data['department']);	
		}
	}*/	
	
	public function ajax_view_jobtitle_by_department()
	{
		$options = "";
		if($_POST['id'])
		{
			$id = $_POST['id'];
			$this->data['department'] = $this->ion_auth_model->get_select_jobtitle_by_department($id);
			?><option value="">Seleccionar</option><?php
			foreach($this->data['department'] as $fila)
			{
				?>
					<option value="<?=$fila -> jobtitleId ?>"><?=$fila -> name ?></option>
				<?php
				}
			}
	}	
		
	function ajax_view_user(){
		if ($_POST['id'] != ""){
			$id = $_POST['id'];
			$this->data['users'] = $this->ion_auth_model->get_user_by_id($id);
			echo json_encode($this->data['users']);
		}
	}
	
	public function ajax_view_model_by_trademark()
	{
		$options = "";
		if($_POST['id'])
		{
			$id = $_POST['id'];
			$this->data['trademark'] = $this->ion_auth_model->get_select_model_by_trademark($id);
			?><option value="">Seleccionar</option><?php
			foreach($this->data['trademark'] as $fila)
			{
				?>
						<option value="<?=$fila -> modelId ?>"><?=$fila -> name ?></option>
					<?php
					}
			//echo print_r($this->data['trademark']);
				}
			
		}
		
	public function ajax_users()
	{
		$options = "";
		$this->data['users'] = $this->ion_auth_model->get_users();
		?><option value="">Seleccionar</option><?php
			foreach($this->data['users'] as $fila)
			{
				?><option value="<?=$fila -> id ?>"><?=$fila -> last_name.", ".$fila -> first_name ?></option>	<?php
			}
	}
	
	function ajax_allocate_product(){
		if ($_POST['productId'] != "" && $_POST['userId'] != ""){
			$id_product = $_POST['productId'];
			$id_user = $_POST['userId'];
			//$quantity = $_POST['quantity'];
			$allocate = $this->ion_auth_model->allocate_product($id_product, $id_user);
		}
	}
	
	function ajax_insert_allocate(){
		if ($_POST['productId'] != "" && $_POST['userId'] != ""){
			$id_product = $_POST['productId'];
			$id_user = $_POST['userId'];
			$quantity = $_POST['quantity'];
			$allocate = $this->ion_auth_model->insert_allocate_product($id_product, $id_user, $quantity);
			var_dump($allocate);
			return $allocate;
		}
	}
	
	function ajax_view_allocate(){
		if ($_POST['productId'] != ""){
			$id = $_POST['productId'];
			$this->data['allocate'] = $this->ion_auth_model->get_users_by_product($id);
			echo json_encode($this->data['allocate']);
		}
	}
}