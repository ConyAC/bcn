<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Report_controller extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('ion_auth');
		$this->load->library('form_validation');
		$this->load->helper('url');
	
		// Load MongoDB library instead of native db driver if required
		$this->config->item('use_mongodb', 'ion_auth') ?
		$this->load->library('mongo_db') :	
		$this->load->database();
	
		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
	
		//$this->lang->load('auth'); lo comento para poder cargar el idioma seleccionado por el usuario.
		$this->load->helper('language');		
		$this->load->library('pagination');
	}
	
	function _render_page($view, $data=null, $render=false)
	{
	
		$this->viewdata = (empty($data)) ? $this->data: $data;
	
		$view_html = $this->load->view($view, $this->viewdata, $render);
	
		if (!$render) return $view_html;
	}
	
	function ajax_view_users(){
		$this->data['users'] = $this->report_model->get_all_user_from_company();
		echo json_encode($this->data['users']);
	}
	
	function ajax_view_type_products(){
		$this->data['product'] = $this->report_model->get_all_type_products();
		echo json_encode($this->data['product']);
	}
	
	function ajax_view_status_products(){
		$this->data['product'] = $this->report_model->get_all_status_products();
		echo json_encode($this->data['product']);
	}
	
	function ajax_view_assigned_products(){
		$this->data['product'] = $this->report_model->get_all_assigned_products();
		echo json_encode($this->data['product']);
	}
	
	function view_pdf(){
		require('plugins/FPDF/fpdf.php');
		$pdf = new FPDF();
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->Cell(40,10,'�Hola, Mundo!');
		$pdf->Output();
	}
	
	public function ajax_view_fields_by_table()
	{
		$options = "";
		if($_POST['id'])
		{
			$id = $_POST['id'];
			$this->data['fields'] = $this->report_model->get_select_fields_by_table($id);
			//echo "<b><input class='jq-checkbox-all' type='checkbox' value=''> Todos</b>"."<br>";				
			foreach($this->data['fields'] as $fila)
				{
					//echo "<input type='checkbox' value='{$fila['key_name']}'> " . $fila['name']."<br>";
					?>
										<option value="<?=$fila -> key_name ?>"><?=$fila -> name ?></option>
									<?php
										
				}
			}
	}
	
	public function ajax_view_field_condition()
	{
		$options = "";
		if($_POST['id'])
		{
			$id = $_POST['id'];
			$this->data['fields'] = $this->report_model->get_select_field_condition($id);
			?> <option value="">Seleccionar</option> <?php 
			foreach($this->data['fields'] as $fila){
				?>
					<option value="<?=$fila -> key_name ?>"><?=$fila -> name ?></option>
				<?php
				}
			}
		}

	public function excel_report($id)
	{
		//if($id != ""){
			
			$query = $this->report_model->get_report($id);	
			
			//if(!$query)
			//	return false;
		
			// Starting the PHPExcel library
			$this->load->library('excel');
			$this->load->library('IoFactory');
		
			$objPHPExcel = new Excel();
			$objPHPExcel->getProperties()->setTitle("export")->setDescription("none");
			$objPHPExcel->setActiveSheetIndex(0);
		
			$objDrawing = new PHPExcel_Worksheet_Drawing();
			$objDrawing->setName('Water_Level');
			$objDrawing->setDescription('Water_Level');
			$objDrawing->setPath('images/logo_bcn.png');
			$objDrawing->setHeight(74);
			$objDrawing->setCoordinates('O1');
			$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
		
			// Field names in the first row
			$fields = $query->list_fields();
			$col = 0;
			foreach ($fields as $field)
			{
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field)->getColumnDimensionByColumn($field)->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getStyle('A1:Z1')->getFont()->setBold(true);
				$col++;
			}
		
			// Fetching the table data
			$row = 2;
			foreach($query->result() as $data)
			{
				$col = 0;
				foreach ($fields as $field)
				{
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $data->$field)->getColumnDimensionByColumn($field)->setAutoSize(true);
					$col++;
				}
		
				$row++;
			}
		
			$objPHPExcel->setActiveSheetIndex(0); 
			$objPHPExcel->getActiveSheet()->setTitle('Reporte01');
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		
			// Sending headers to force the user to download the file
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="Reporte_'.date('dMy').'.xls"');
			header('Cache-Control: max-age=0');
		
			$objWriter->save('php://output');
		//}
	}
	
	function create_reports()
	{
		$this->data['title'] = "Crear Reporte";
	
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{
			redirect('auth', 'refresh');
		}
	
		$this->data['tablesList'] = $this->report_model->get_select_tables();
		$this->data['operatorList'] = $this->report_model->get_select_operator();
	
		//Validar al menos dos datos obligatorios por form_validation
		$this->form_validation->set_rules('name', $this->lang->line('create_reports_name'), 'required|xss_clean');
		$this->form_validation->set_rules('table', $this->lang->line('create_reports_name'), 'required|xss_clean');
	
		if ($this->form_validation->run() == true)
		{			
			$date_creation = date("Y-m-d H:i:s");			
			$additional_data = array(
					'name' => $this->input->post('name'),
					'static' => 0,
					'table' => $this->input->post('table'),					
					'fields' => implode(', ', $this->input->post('fields')),					
					'table_join' => $this->input->post('table_join'),
					'fields_where' => $this->input->post('fields_where'),
					'operator' => $this->input->post('operator'),
					'first_value' => $this->input->post('first_value'),
					'second_value' => $this->input->post('second_value'),
					'and_or' => $this->input->post('options'),
					'order_by' => $this->input->post('order_by'),
					'asc_desc' => $this->input->post('asc_desc'),
					'limit' => $this->input->post('limit'),
					'date_creation' => $date_creation,
					'description' => $this->input->post('description'),
					'count' => $this->input->post('count'),
					'deleted' => 0
			);				
			//echo var_dump($additional_data);
		}
		
		if ($this->form_validation->run() == true && $this->report_model->register_report($additional_data))
		{
			redirect("pages/reports", 'refresh');
		}
		else
		{
			//display the create user form
			//set the flash data error message if there is one
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));
	
			$this->data['name'] = array(
					'name'  => 'name',
					'id'    => 'name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('name'),
			);
			$this->data['table'] = array(
					'name'  => 'table',
					'id'    => 'table',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('table'),
			);
			$this->data['fields'] = array(
					'name'  => 'fields',
					'id'    => 'fields',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('fields'),
			);
			$this->data['table_join'] = array(
					'name'  => 'table_join',
					'id'    => 'table_join',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('table_join'),
			);
			$this->data['fields_where'] = array(
					'name'  => 'fields_where',
					'id'    => 'fields_where',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('fields_where'),
			);
			$this->data['operator'] = array(
					'name'  => 'operator',
					'id'    => 'operator',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('operator'),
			);
			$this->data['first_value'] = array(
					'name'  => 'first_value',
					'id'    => 'first_value',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('first_value'),
			);
			$this->data['second_value'] = array(
					'name'  => 'second_value',
					'id'    => 'second_value',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('second_value'),
			);
			$this->data['options'] = array(
					'name'  => 'options',
					'id'    => 'options',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('options'),
			);
			$this->data['order_by'] = array(
					'name'  => 'order_by',
					'id'    => 'order_by',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('order_by'),
			);
			$this->data['asc_desc'] = array(
					'name'  => 'asc_desc',
					'id'    => 'asc_desc',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('asc_desc'),
			);
			$this->data['limit'] = array(
					'name'  => 'limit',
					'id'    => 'limit',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('limit'),
			);
			$this->data['date_creation'] = array(
					'name'  => 'date_creation',
					'id'    => 'date_creation',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('date_creation'),
			);
			$this->data['description'] = array(
					'name'  => 'description',
					'id'    => 'description',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('description'),
			);
			$this->data['count'] = array(
					'name'  => 'count',
					'id'    => 'count',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('count'),
			);
			
			$this->_render_page('pages/create_reports', $this->data);
		}
	}
	
	function ajax_static_report(){
		if ($_POST['id_report'] != ""){
			$id_report = $_POST['id_report'];
			$change = $this->report_model->change_report($id_report);
		}
	}
	
	function ajax_delete_report(){
		if ($_POST['id_report'] != ""){
			$id_report = $_POST['id_report'];
			$change = $this->report_model->delete_report($id_report);
		}
	}
	
	function ajax_view_report(){
		if ($_POST['id_report'] != ""){
			$id_report = $_POST['id_report'];
			$this->data['report'] = $this->report_model->view_report($id_report);
			echo json_encode($this->data['report']);
		}
	}
	
	function ajax_info_report(){
		if ($_POST['id_report'] != ""){
			$id_report = $_POST['id_report'];
			$this->data['report'] = $this->report_model->get_report_by_id($id_report);
			echo json_encode($this->data['report']);
		}
	}
	
}