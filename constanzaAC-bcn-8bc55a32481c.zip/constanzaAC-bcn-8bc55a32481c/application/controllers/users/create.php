<script type="text/javascript">//<![CDATA[
	$(function() {
		
	});
//]]></script>
<div id="jq-create-users-wrapper">
	<div class="main-information-fields add_user left-wrapper scrollable" id="jq-add-user-div">
		<h3 class="title jq-title"><?php echo lang('company_add_user');?></h3>
		<?php
		$create_edit_data['OPTIONS']['show_roles'] = true;
		$create_edit_data['OPTIONS']['show_supervisors'] = true;
		$create_edit_data['OPTIONS']['show_current_password'] = true;
		$create_edit_data['OPTIONS']['show_but_hide_current_password'] = true;
		$create_edit_data['OPTIONS']['show_locales'] = true;
		$create_edit_data['OPTIONS']['table_class'] = "table";
		$create_edit_data['OPTIONS']['widths'] = array(35,65);
		$create_edit_data['OPTIONS']['required_passwords'] = true;
		$create_edit_data['USER']['locale'] = $this->session->userdata('company_locale');
		$this->load->view('users/create_edit_form', $create_edit_data);
		?>
		<input type="hidden" class="jq-id" />
		<a class="btn btn-small btn-success flybox_add_button" id="jq-add-user">
			<i class="icon-plus-sign icon-white"></i>
			<?php echo lang('company_add_user_to_list');?>
		</a>
		<a class="btn btn-small btn-success flybox_add_button hidden-obj" id="jq-edit-user"><?php echo lang('site_save_changes');?></a>
		<a class="btn btn-small flybox_add_button hidden-obj" id="jq-cancel-edit-user"><?php echo lang('site_cancel');?></a>
	</div>
	<div class="main-information-fields right-wrapper users_list scrollable" id="jq-users-list-scrollable">
		<h3 class="title"><?php echo lang('company_users_list');?></h3>
		<h5 class="jq-remaining-users">(<?php if(isset($COMPANY['stats']['users']['remaining'])) echo $COMPANY['stats']['users']['remaining']."/".$COMPANY['stats']['users']['plan'];  
				   else echo "0";
		?> <?php echo lang('company_users_remaining');?>)</h5>
		<?php if(!isset($USERS) || empty($USERS)): ?>
			<div class="jq-msg warning"><?php echo lang('site_empty_list', array(strtolower(lang('user_users'))));?></div>
		<?php endif;?>
		<table id="jq-users-list" class="table table-hover <?php echo (isset($USERS) && !empty($USERS))?'':'hidden-obj';?>">
			<thead>
				<tr>
					<?php $width1 = 20; $width2 = 15; $width3 = 15; $width4 = 20; $width5 = 15; $width6 = 15;?>
					<th class="valign-middle" width="<?php echo $width1;?>%"><?php echo lang('site_name');?></th>
					<th class="valign-middle" width="<?php echo $width2;?>%"><?php echo lang('site_email');?></th>
					<th class="valign-middle" width="<?php echo $width3;?>%"><?php echo lang('user_role');?></th>
					<th class="valign-middle" width="<?php echo $width4;?>%"><?php echo lang('user_supervisor');?></th>
					<th class="valign-middle" width="<?php echo $width5;?>%"><?php echo lang('site_language');?></th>
					<th class="valign-middle align-center" width="<?php echo $width6;?>%"><?php echo lang('site_actions');?></th>
				</tr>
			</thead>
			<tbody>
				<tr class="hidden-obj" id="jq-user-tr-clonable">
					<td>
						<input class="jq-user-id" type="hidden" />
						<span class="jq-user-name" ></span>
						<span class="jq-user-lastname"></span>
					</td>
					<td class="jq-user-email"></td>
					<td>
						<input class="jq-user-role-id" type="hidden" />
						<span class="jq-user-role-name"></span>
					</td>
					<td>
						<input class="jq-user-supervisor-id" type="hidden" />
						<span class="jq-user-supervisor-name"></span>
					</td>
					<td>
						<input class="jq-user-locale-id" type="hidden" />
						<span class="jq-user-locale-name"></span>
					</td>
					<td class="align-center">
						<a class="btn btn-mini btn-info my_tipsy jq-user-edit" title="<?php echo lang('site_edit');?>">
							<i class="icon-white icon-pencil"></i>
						</a>
						<a class="btn btn-mini btn-danger my_tipsy jq-user-delete" title="<?php echo lang('site_delete');?>">
							<i class="icon-white icon-trash"></i>
						</a>
					</td>
				</tr>
				<?php
				if(isset($USERS) && !empty($USERS)):
					foreach( $USERS as $user ):
				?>
				<tr>
					<td>
						<input class="jq-user-id" type="hidden" value="<?php echo $user['id'];?>" />
						<span class="jq-user-name" ><?php echo $user['name']; ?></span>
						<span class="jq-user-lastname" ><?php echo $user['lastname']; ?></span>
					</td>
					<td class="jq-user-email"><?php echo $user['email'];?></td>					
					<td>
						<input class="jq-user-role-id" type="hidden" value="<?php echo $user['role']['id'];?>" />
						<span class="jq-user-role-name"><?php echo $user['role']['name']; ?></span>
					</td>
					<td>
						<input class="jq-user-supervisor-id" type="hidden"  value="<?php echo (isset($user['supervisor']['id']))?$user['supervisor']['id']:'';?>"/>
						<span class="jq-user-supervisor-name"><?php echo (isset($user['supervisor']['id']) && isset($user['supervisor']['name']) && isset($user['supervisor']['lastname']))?($user['supervisor']['name']." ".$user['supervisor']['lastname']):("<span class='example'>".lang('site_none')."</span>"); ?></span>
					</td>
					<td>
						<input class="jq-user-locale-id" type="hidden"  value="<?php echo (isset($user['locale']))?$user['locale']:'';?>"/>
						<span class="jq-user-locale-name"><?php echo (isset($user['locale']))?get_locale($user['locale']):("<span class='example'>".lang('site_none')."</span>"); ?></span>
					</td>
					<td class="align-center">
						<a class="btn btn-mini btn-info my_tipsy jq-user-edit" title="<?php echo lang('site_edit');?>">
							<i class="icon-white icon-pencil"></i>
						</a>
						<a class="btn btn-mini btn-danger my_tipsy jq-user-delete" title="<?php echo lang('site_delete');?>">
							<i class="icon-white icon-trash"></i>
						</a>
					</td>
				</tr>
				<?php
					endforeach;
				endif;
				?>
			</tbody>
		</table>
	</div>
</div>
<div id="jq-create-role-dialog" class="dialog_wrapper" title="<?php echo lang('user_create_new_role');?>">
	<?php $this->load->view('roles/create');?>
</div>