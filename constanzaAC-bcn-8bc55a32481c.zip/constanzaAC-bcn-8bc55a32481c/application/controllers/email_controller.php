<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_controller extends CI_Controller {

    function __construct() {
        parent::__Construct();
       /* $this->load->library(array('form_validation','email', 'ion_auth'));
        $this->load->helper(array('url','html'));
        $this->load->helper('language');
        $this->lang->load('auth');*/
        
        $this->load->library('ion_auth');
		$this->load->library('form_validation');
		$this->load->helper('url');
	
		// Load MongoDB library instead of native db driver if required
		$this->config->item('use_mongodb', 'ion_auth') ?
		$this->load->library('mongo_db') :
	
		$this->load->database();
	
		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
	
		//$this->lang->load('auth'); lo comento para poder cargar el idioma seleccionado por el usuario.
		$this->load->helper('language');
		
		$this->load->library('pagination');
       }

    function _render_page($view, $data=null, $render=false)
       {
       
       	$this->viewdata = (empty($data)) ? $this->data: $data;
       
       	$view_html = $this->load->view($view, $this->viewdata, $render);
       
       	if (!$render) return $view_html;
       }
       
    function index(){
	
		/*$config['protocol']     = 'smtp';
		$config['smtp_host']    = 'ssl://smtp.gmail.com';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = 'testingbcn2@gmail.com';
		$config['smtp_pass']    = 'testing123r';
		$config['charset']      = 'utf-8';
		$config['newline']      = "\r\n";
		$config['mailtype']     = 'text'; 
		$config['validation']   = TRUE; */
		
		//$this->load->library('email', $config);
		$this->email->set_newline("\r\n");	
       
        $data['title'] = 'Solicitud de Software';
        $data['msg'] = NULL;
     
       $this->form_validation->set_rules('name', 'Nombre', 'required');
       $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
       $this->form_validation->set_rules('message', 'Mensaje', 'required');
       $this->form_validation->set_rules('jobtitle', 'Cargo', 'required');
     
       $this->form_validation->set_message('required', 'el campo %s es requerido');
       $this->form_validation->set_message('valid_email', 'El email no es v�lido');         
       $this -> form_validation -> set_error_delimiters('<ul><li>', '</li></ul>');     
       $this->form_validation->set_message('required', 'el campo %s es requerido');
       $this->form_validation->set_message('required', 'el campo %s es requerido');
      
      
   	   if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('send_email', $data); 
		}else{                      
            $name = $this->input->post('name');
            $jobtitle = $this->input->post('jobtitle');
            $email = $this->input->post('email');
            $message = $this->input->post('message');
                      
            $this->email->from($email, $name);
            $this->email->to('testingbcn2@gmail.com');         
            $this->email->subject('Solicitud de Software');
            $this->email->message('Usuario :'.$name.'<br>'.'Cargo :'.$jobtitle.'<br>'.'Solicitud :'.$message);            
                    
      /* if($this->email->send()){          
            $data['title']='Mensaje Enviado';
            $data['msg'] = 'Mensaje enviado a su email';
            $this->load->view('send_email', $data);
          
       }else{
             	show_error($this->email->print_debugger());
                $data['title']='El mensaje no se pudo enviar';
                $this->load->view('send_email', $data);            
        	}*/
    	}
	}
	
	function send_email(){
		$this->data['title'] = "Solicitar Producto";
		
		$config['protocol']     = 'smtp';
		$config['smtp_host']    = 'ssl://smtp.gmail.com';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = 'testingbcn2@gmail.com';
		$config['smtp_pass']    = 'testing123r';
		$config['charset']      = 'utf-8';
		$config['newline']      = "\r\n";
		$config['mailtype']     = 'text';
		$config['validation']   = TRUE;
		
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth', 'refresh');
		}
		
		$this->form_validation->set_rules('name', $this->lang->line('send_email_name'), 'required|xss_clean');
		$this->form_validation->set_rules('email', $this->lang->line('send_email_email'), 'required|valid_email');
		$this->form_validation->set_rules('message_user', $this->lang->line('send_email_message'), 'required|xss_clean');
		$this->form_validation->set_rules('jobtitle', $this->lang->line('send_email_jobtitle'), 'required|xss_clean');	
	
		if ($this->form_validation->run() == true)
		{			
			$additional_data = array(
				'name'     => $this->input->post('name'),
				'jobtitle' => $this->input->post('jobtitle'),
				'email'    => $this->input->post('email'),
				'message_user'  => $this->input->post('message_user'),
				'viewed'   => 0);
			
			$this->email->from($this->input->post('email'), $this->input->post('name'));
			$this->email->to('testingbcn2@gmail.com');
			$this->email->subject('Solicitud de Software');
			$this->email->message('Usuario :'.$this->input->post('name').'<br>'.'Cargo :'.$this->input->post('jobtitle').'<br>'.'Solicitud :'.$this->input->post('message_user'));
		}
		if ($this->form_validation->run() == true && $this->email->send() && $this->email_model->save_message_email($additional_data))
		{
			redirect("auth/home", 'refresh');				
		}
		else
		{
			$this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));
				
			$this->data['name'] = array(
					'name'  => 'name',
					'id'    => 'name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('name'),
			);
			$this->data['jobtitle'] = array(
					'name'  => 'jobtitle',
					'id'    => 'jobtitle',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('jobtitle'),
			);
			$this->data['email'] = array(
					'name'  => 'email',
					'id'    => 'email',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('email'),
			);
			$this->data['message_user'] = array(
					'name'  => 'message_user',
					'id'    => 'message_user',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('message_user'),
			);			
			
			$this->_render_page('pages/send_email', $this->data); 
		}
	}
	
	function ajax_view_message(){
		if ($_POST['id'] != ""){
			$id = $_POST['id'];
			$this->data['send_email'] = $this->email_model->get_message_by_id($id);
			echo json_encode($this->data['send_email']);
		}
	}
	
	function ajax_read_message(){
		if ($_POST['id'] != ""){
			$id = $_POST['id'];
			$this->data['send_email'] = $this->email_model->set_read_message($id);
		}
	}
	
	function ajax_delete_message(){
		if ($_POST['id_message'] != ""){
			$id_message = $_POST['id_message'];
			$delete = $this->email_model->delete_message($id_message);
		}
	}
}