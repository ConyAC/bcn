<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	
		selectMenuUpperAdmProd();
	$(document).ready(function(){
		if($("select[name=type]").val() != ""){
			$("select[name=type]").change();
		}
		if($("select[name=statusId]").val() != ""){
			$("select[name=statusId]").change();
		}
	});

	hideElement();
	selectType();
	selectStatus();
	quantityShow();

	$("select[name=statusId]").change(function(){
		   if ( $('select[name=statusId]').val() == 4 ){
		  	   $(".jq-label-user-assigned").show();
			   $(".jq-select-user-assigned").show();
		   }else{
			   $(".jq-label-user-assigned").hide();
			   $(".jq-select-user-assigned").hide();
		   }
		});		

	$("body").off("change", "select[name='trademarkId']").on("change", "select[name='trademarkId']", function() {	
		 $.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('pages/ajax_view_model_by_trademark');?>", 
	         data: {id: $("select[name='trademarkId']").val()},
	         dataType: "text",  
	         cache:false,
	         success:   
	              function(data){      	
	        		 $("#jq-model-id").html(data);
	              }	 	                 
	     });
	});
	
	$(".jq-input-date").datepicker({
		 changeMonth: true,
		 changeYear: true
	});

	if($(".jq-multiple").val() == "1"){
		$('select[name=statusId]').val(4);
		$(".jq-select-user-assigned").html("");
		$(".jq-select-user-assigned").append("<span class='normal-link link-prod jq-allocate-user'><?php echo lang('allocate_view');?></span>");
	}

	$(".jq-select-user-assigned").find(".jq-allocate-user").click(function(){
		$.ajax({ 
	        type: "POST",
	        url: "<?php echo site_url('pages/ajax_view_allocate');?>", 
	        data: {productId: $("#jq-user-form").find(".jq-product-id").val()},
	        dataType: "text",  
	        cache:false,
	        success:  
	             function(data){
	        		 var resp = $.parseJSON(data);	
			       	$.each(resp, function(index, value) { 
			       		$(".jq-table-view-allocate").find(".jq-tbody").append("<tr><td class='align-left jq-tr'><input type='hidden' class='jq-user-id' value='"+value.id+"' />"+value.first_name+" "+value.last_name+"</td> <td class='align-left'>"+value.quantity+"</td><td><a class='jq-delete-user'><img class='img-reports my_tooltip' style='cursor: pointer;' src='<?php get_image('delete_unit.png');?>' data-toggle='tooltip' title='<?php echo lang('index_delete_th');?>'></a></td></tr>");
			       	});
	           }          
	    });
		$('#modal-view-allocate').modal('show');
	});

	$('#btnCancelView').click(function() {
		$(".jq-table-view-allocate").find(".jq-tbody").html("");
	});
		
});		
//]]></script>
<div id="modal-view-allocate" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header without-border">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"><?php echo lang("site_allocate");?></h4>
      </div>
      <div class="modal-body modal-body-view-allocate">
	      <table class="jq-table-view-allocate jq-table-product-results table table-hover">
		      <thead>
				<tr>
					<th class="align-left"><?php echo lang("site_user");?></th>
					<th class="align-left"><?php echo lang("site_quantity");?></th>
					<th class="align-center"><?php echo lang("index_action_th");?></th>
				</tr>
			</thead>
			<tbody class="jq-tbody">
		    </tbody>
	      </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="btnCancelView" data-dismiss="modal"><?php echo lang("site_close");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('edit_product_heading');?></span>
</div>		
<div class="panel panel-default">
<div class="panel-body">
<div id="jq-add-user-div" class="add_user scrollable">
<div id="jq-user-form">
<?php echo form_open(uri_string());?>
<table class="form-user">
      <tr>
      		<td><?php echo lang('create_product_ltipo_label', 'type');?></td>
            <td> <?php echo form_dropdown('type',  $typeId, $type['value']);?> </td>
            <input type="hidden" class="jq-multiple" value="<?php echo $multiple['value'];?>" />
            <input type="hidden" class="jq-product-id" value="<?php echo $productId;?>" />
            <td><?php echo lang('create_product_lserie_label', 'serie');?></td>
            <td><span class="td-left"><?php echo form_input($serialNumber);?></span></td>
      </tr>
      <tr>  
      		<td><?php echo lang('create_product_lmarca_label', 'marca');?></td>
            <td> <?php echo form_dropdown_id('trademarkId','', $trademarkList, $trademarkId['value']);?> </td>       		
             
            <td><?php echo lang('create_product_ldate_label', 'datePurchase');?></td>
            <td><span class="td-left"><?php echo form_input_date($datePurchase);?></span></td> 
      </tr>
      <tr>      
      		<td> <?php echo lang('create_product_lmodel_label', 'model');?></td>
      		<!-- <td><select name="modelId" id="jq-model-idd"><option value="">Seleccionar</option></select></td>-->	
      		<td> <?php echo form_dropdown_id('modelId','jq-model-id', $modelList, $modelId['value']);?> </td>
             
            <td class="jq-label-os"><?php echo lang('create_product_los_label', 'os');?></td>
            <td class="jq-select-os"> <?php echo form_dropdown('operating_systemId',  $osId, ($operating_systemId['value']) ? $operating_systemId['value'] : '');?> </td>
            
            <td class="jq-label-imei"><?php echo lang('create_product_limei_label', 'imei');?></td>
            <td class="jq-select-imei"> <?php echo form_input($imei);?> </td>      
      </tr>   
      <tr>
            <td> <?php echo lang('create_product_lstatus_label', 'statusId');?></td>
            <td> <?php echo form_dropdown('statusId', $status_productId, $statusId['value']);?> </td>
            
            <td class="jq-label-cpu"> <?php echo lang('create_product_lcpu_label', 'cpu');?></td>
            <td class="jq-select-cpu"> <?php echo form_input($cpu);?> </td>      
      </tr>  
      <tr>
            <td class="jq-label-user-assigned"> <?php echo lang('create_product_luser_assigned_label', 'userAssigned');?></td>
            <td class="jq-select-user-assigned"> <?php echo form_dropdown('user_assignedId', $user_assigned, ($user_assignedId['value']) ? $user_assignedId['value'] : '');?> </td>
      </tr>
      <tr>
            <td><?php echo lang('create_product_cost_label', 'cost');?></td>
            <td><?php echo form_input($cost);?></td>
            
             <td class="jq-label-hdd"> <?php echo lang('create_product_lhdd_label', 'hdd');?></td>
             <td class="jq-select-hdd"> <?php echo form_input($hdd);?> </td>  
      </tr>        
      <tr>            
            <td class="jq-label-ram"> <?php echo lang('create_product_lram_label', 'ram');?></td>
            <td class="jq-select-ram"> <?php echo form_input($ram);?> </td>   
      </tr>
      <tr>
            <td class="jq-quantity-label hidden-obj"><?php echo lang('create_product_quantity_label', 'quantity');?></td>
            <td class="jq-quantity-input hidden-obj"><?php echo form_input($quantity);?></td>
       <tr>
            <td><?php echo lang('create_product_ldescription_label', 'description');?></td>
            <td> <?php echo form_textarea($description,'','');?> </td>
      </tr>
      <tr>
      <td style="padding-top: 30px;"><?php echo form_submit('submit', lang('edit_product_submit_btn'));?></td>
      <td><a href="<?php echo site_url('pages/adminProduct');?>" id="jq-create-product"> 
	            <input style="margin-top: 27px;" class="btn btn-small btn-success" type="button" value="Cancelar"></a></td>
      </tr>
      </table>
<?php echo form_close();?>
</table>
</div>
<div id="infoMessage" class="create-user-message"><?php echo $message;?></div>
</div>
</div>
</div>