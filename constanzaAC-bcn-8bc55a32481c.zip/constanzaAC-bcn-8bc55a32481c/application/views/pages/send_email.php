<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	

		$(".menu-select-inicio").animate({ backgroundColor: "#21759B" }, "slow"); 
		$(".inicio").css('color', '#FFFFFF'); 
		
		var name_user = $("input[name='name']").val(),
		jobtitle_user = $("input[name='jobtitle']").val(),
		email_user	  = $("input[name='email']").val(),
		message_user  = $("textare[name='message']").val();
		
		/*$("#jq-send-email").click(function(){       
			console.log("ingreso"); 
			console.log(name_user); 
			     $.ajax({
			         type: "POST",
			         url: "<?php echo site_url('email_controller/ajax_save_email');?>", 
			         data: { name: name_user, jobtitle:jobtitle_user, email:email_user, message:message_user},
			         dataType: "text",  
			         cache:false,
			         success: 
			              function(data){

			        	 console.log(data);
			                		                
			              }
			     });
			    // return false;
			 });*/
});		
//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>
<div class="view-header">
	<span class="middle2"><?php echo lang('send_email_heading');?></span>
</div>		
<div class="panel panel-default">
	<div class="panel-body">
		<div id="jq-add-user-div" class="add_user left-wrapper scrollable">
			<div id="jq-user-form">
				<?php echo form_open("email_controller/send_email");?>
				<table class="form-user">
				      <tr>
				             <td><?php echo lang('send_email_name', 'name');?></td>
				      		 <td><input id="email" class="form-control input_text medium jq-required-field" type="text" value="<?php echo $this->session->userdata('first_name'). ' '.$this->session->userdata('last_name');?>" name="name"></td>
				      </tr>
				      <tr>  
				            <td><?php echo lang('send_email_jobtitle', 'jobtitle');?></td>
				      		<td><input id="email" class="form-control input_text medium jq-required-field" type="text" value="<?php echo $this->session->userdata('jobtitle');?>" name="jobtitle"></td>
				      </tr>
				      <tr>      
				      		 <td><?php echo lang('send_email_email', 'email');?></td>
				      		 <td><input id="email" class="form-control input_text medium jq-required-field" type="text" value="<?php echo $this->session->userdata('email');?>" name="email"></td>
				      </tr>   
				      <tr>
				            <td> <?php echo lang('send_email_msg', 'message_user');?></td>
				            <td> <?php echo form_textarea($message_user,'','');?> </td>     
				      </tr>  
				      <tr> <td style="padding-top: 30px; padding-right: 5px;"><?php echo form_submit_email('submit', lang('send_email_submit_btn'));?> </td>
				      	   <td style="padding-top: 33px;"><?php echo form_reset('reset', lang('create_product_cancel_btn'));?> </td></tr>
				<?php echo form_close();?>
				</table>
			</div>
		</div>
	</div>
</div>
<div id="infoMessage" class="create-user-message"><?php echo $message;?></div>
