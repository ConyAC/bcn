<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	
		 selectMenuUpperAdmProd();		
		 hideElement();
		 selectType();
		 selectStatus();
		 quantityShow();

	$("body").off("change", "select[name='trademarkId']").on("change", "select[name='trademarkId']", function() {	
		 $.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('pages/ajax_view_model_by_trademark');?>", 
	         data: {id: $("select[name='trademarkId']").val()},
	         dataType: "text",  
	         cache:false,
	         success:   
	              function(data){      	
	        		 $("#jq-model-id").html(data);
	              }	 	                 
	     });
	});
	

	$(".jq-input-date").datepicker({
		 changeMonth: true,
		 changeYear: true
	});

	/*$("#jq-send-form").off("click").on("click",function(){
		if(!checkForm(".form-user", ''))
			return false;
		
	});*/
});		
//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('create_product_heading');?></span>
</div>		

<div class="panel panel-default">
  <div class="panel-body scrollable-users-table">
<div id="jq-add-user-div" class="add_user left-wrapper">
<div id="jq-user-form">
<?php echo form_open("pages/create_product");?>
<table class="form-user">
      <tr>
      		<td><?php echo lang('create_product_ltipo_label', 'type');?></td>
            <td> <?php echo form_dropdown('type',  $typeId, '');?> </td>
            
             <td><?php echo lang('create_product_lserie_label', 'serie');?></td>
             <td><span class="td-left"><?php echo form_input_id($serialNumber);?></span></td>
      </tr>
      <tr>  
      		<td><?php echo lang('create_product_lmarca_label', 'marca');?></td>
      		<td> <?php echo form_dropdown_id('trademarkId', '', $trademarkList, '');?> </td>  
             
            <td><?php echo lang('create_product_ldate_label', 'datePurchase');?></td>
            <td><span class="td-left"><?php echo form_input_date($datePurchase);?></span></td> 
      </tr>
      <tr>      
      		 <td> <?php echo lang('create_product_lmodel_label', 'model');?></td>
      		 <td><select name="modelId" id="jq-model-id"><option value=""><?php echo lang("site_select");?></option></select></td>
             
            <td class="jq-label-os"><?php echo lang('create_product_los_label', 'os');?></td>
            <td class="jq-select-os"> <?php echo form_dropdown_id('operating_systemId', '', $osId, '');?> </td>
            
            <td class="jq-label-imei"><?php echo lang('create_product_limei_label', 'imei');?></td>
            <td class="jq-select-imei"><span class="td-left"><?php echo form_input($imei);?></span></td>      
      </tr>   
      <tr>
            <td> <?php echo lang('create_product_lstatus_label', 'statusId');?></td>
            <td> <?php echo form_dropdown_id('statusId', '', $status_productId, '');?> </td>
            
            <td class="jq-label-cpu"> <?php echo lang('create_product_lcpu_label', 'cpu');?></td>
            <td class="jq-select-cpu"> <?php echo form_input($cpu);?> </td>      
      </tr>  
      <tr>
            <td class="jq-label-user-assigned"> <?php echo lang('create_product_luser_assigned_label', 'userAssigned');?></td>
            <td class="jq-select-user-assigned"> <?php echo form_dropdown('user_assignedId', $user_assigned, '');?> </td>
      </td>      
      </tr>  
      <tr>
            <td><?php echo lang('create_product_cost_label', 'cost');?></td>
            <td><?php echo form_input($cost);?></td>
            
             <td class="jq-label-hdd"> <?php echo lang('create_product_lhdd_label', 'hdd');?></td>
             <td class="jq-select-hdd"> <?php echo form_input($hdd);?> </td>  
      </tr>       
      <tr>            
            <td class="jq-label-ram"> <?php echo lang('create_product_lram_label', 'ram');?></td>
            <td class="jq-select-ram"> <?php echo form_input($ram);?> </td>   
      </tr>
      <tr>
     		<td class="jq-quantity-label hidden-obj"><?php echo lang('create_product_quantity_label', 'quantity');?></td>
            <td class="jq-quantity-input hidden-obj"><?php echo form_input($quantity);?></td>
      </tr>
       <tr>
            <td><?php echo lang('create_product_ldescription_label', 'description');?></td>
            <td> <?php echo form_textarea($description,'','');?> </td>
      </tr>
      
      <tr> <td style="padding-top: 30px;"><input type="submit" id='jq-send-form' class='btn btn-small btn-success' value="<?php echo lang('create_product_submit_btn');?>" /> </td>
      	   <td style="padding-top: 30px;"><?php echo form_reset('reset', lang('create_product_cancel_btn'));?> </td></tr>
      

<?php echo form_close();?>

</table>
</div>
</div>
</div>
</div>
<div id="infoMessage" class="create-user-message"><?php echo $message;?></div>
