<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	
		selectMenuUpperReports();
		 $("#jq-container-add-join").find("select").addClass("jq-exclude");
		 $("#jq-container-add-join-clonable").find("select").addClass("jq-exclude");
		 $("#jq-operator-tr").find("select").addClass("jq-exclude");
		 $("#jq-operator-tr").find("#jq-field-condition-id").hide();
		 $("#jq-operator-tr").find(".jq-between, .between").hide();
		 $("#jq-sort-by-tr").find("#jq-field-condition-id").hide();
		 $("#jq-operator-clone").find("#jq-field-condition-clone-id").hide();
		 $("#jq-operator-clone").find(".jq-between, .between").hide();
		 //$("#jq-fields").find(".report-fields").hide();
		
		$("body").off("change", "#jq-table-id").on("change", "#jq-table-id", function() {	
			 $.ajax({ 
		         type: "POST",
		         url: "<?php echo site_url('report_controller/ajax_view_fields_by_table');?>", 
		         data: {id:$("#jq-table-id").val(), option:"true"},
		         dataType: "text",  
		         cache:false,
		         success:   
		              function(data){      	
		                 $("#jq-operator-tr").find("#jq-select-field").hide();
		                 $("#jq-sort-by-tr").find("#jq-select-field").hide();
		                 $("#jq-fields-tr").find("#jq-select-field").hide();		          
		        		 $("#jq-field-id").html(data);
		        		// $("#jq-fields").find(".report-fields").show();
		        		 $("#jq-operator-tr").find("#jq-field-condition-id").show();
		        		 $("#jq-sort-by-tr").find("#jq-field-condition-id").show();
		              },
		         error:
			         function(data){
		        	 $("#jq-operator-tr").find("#jq-select-field").show();
	                 $("#jq-sort-by-tr").find("#jq-select-field").show();
	                 $("#jq-fields-tr").find("#jq-select-field").show();  
		         }      
		     });

			 $.ajax({ 
		         type: "POST",
		         url: "<?php echo site_url('report_controller/ajax_view_field_condition');?>", 
		         data: {id:$("#jq-table-id").val()},
		         dataType: "text",  
		         cache:false,
		         success:   
		              function(data){      	
		        	 $("#jq-operator-tr").find("#jq-select-field").hide();
	                 $("#jq-sort-by-tr").find("#jq-select-field").hide();
	                 $("#jq-fields-tr").find("#jq-select-field").hide();
	                 $("#jq-operator-tr").find("#jq-field-condition-id").html(data);
		        	 $("#jq-sort-by-tr").find("#jq-field-condition-id").html(data);
		        	 $("#jq-operator-clone").find("#jq-field-condition-id").html(data);
		              },
		         error:
			         function(data){
		        	 $("#jq-operator-tr").find("#jq-select-field").show();
	                 $("#jq-fields-tr").find("#jq-select-field").show();    
	                 $("#jq-sort-by-tr").find("#jq-select-field").show();
		         }      
		     });
		
		   $("body").off("click", ".jq-checkbox-all").on("click", ".jq-checkbox-all", function() {
		       if($(this).is(":checked")) {
		    	   $('input[type=checkbox]').attr("checked", true);
		       }else{
		    	   $('input[type=checkbox]').attr("checked", false);
		       }
		   });					 
	});
		$('.my_tooltip').tooltip('trigger');
	
		$("#jq-operator-tr").find("#jq-operator-id").change(function(){
			   if ( $(this).val() == 2 ){
				   $("#jq-operator-tr").find(".jq-between, .between").show();
				   $("#jq-operator-clone").find(".jq-between, .between").show();
			   }else{
				   $("#jq-operator-tr").find(".jq-between, .between").hide();
				   $("#jq-operator-clone").find(".jq-between, .between").hide();
			   }
		});		

		$("#jq-operator-clone").find("#jq-operator-id").change(function(){
			   if ( $(this).val() == 2 ){
				   $("#jq-operator-clone").find(".jq-between, .between").show();
			   }else{
				   $("#jq-operator-clone").find(".jq-between, .between").hide();
			   }
		});		

		/*$("#jq-add-join-clone").click(function(){
			$('.testt').clone(true).insertAfter('span.testt');
		});		
		*/
		$("input#jq-report-and").change(function(){
			console.log($("select#jq-table-id").val());
			var value = $(this).val();
			if ($("select#jq-table-id").val() != ""){				
				$('#jq-operator-clone').clone(true).appendTo('#jq-operator-clone');
				$('#jq-operator-clone').removeClass('hidden-obj');			
			}else{
				alert("Por favor seleccione una tabla.");				
			}
		});

		$("input#jq-report-or").change(function(){
			console.log($("select#jq-table-id").val());
			var value = $(this).val();
			if ($("select#jq-table-id").val() != ""){				
				$('#jq-operator-clone').clone(true).appendTo('#test');
				$('#jq-operator-clone').removeClass('hidden-obj');			
			}else{
				alert("Por favor seleccione una tabla.");				
			}
		});

		$("input#jq-report-andor-cancel").change(function(){
			$('#jq-operator-clone').addClass('hidden-obj');
		});

		$("#jq-cancel-form").click(function(){
			$('select#jq-field-id option').remove();
			$('select#jq-field-id').append("<option value='0'> Seleccionar </option>");
		});

		$("#jq-add-join").click(function(){
			if($("#jq-container-add-join").hasClass("hidden-obj"))
				$("#jq-container-add-join").removeClass("hidden-obj");
			else
				$("#jq-container-add-join").addClass("hidden-obj");
		});

		$("#jq-container-add-join").find("#jq-table-id").addClass("jq-exclude");
		
		$("#jq-create-report").click(function(){

			if(!checkForm("#jq-report-form", ''))
				return false;

			//checkNumericFields(".form-user");

			var fields = [];
			$("#jq-fields-tr").find("#jq-field-id option:selected").each(function(){
				var d = {};
				d = $(this).val();
				return fields.push(d);
			});
			
			var data = {};
			data.name  = $("#jq-identification-tr").find(".jq-name-report").val();
			data.table = $("#jq-tables-tr").find("#jq-table-id option:selected").val();
			data.fields = fields;
			data.condition = $("#jq-operator-tr").find("#jq-field-condition-id option:selected").val();
			data.operator= $("#jq-operator-tr").find("#jq-operator-id option:selected").val();
			data.firstvalue = $("#jq-operator-tr").find("#jq-first-value option:selected").val();
			data.secondvalue = $("#jq-operator-tr").find("#jq-second-value option:selected").val();
			data.sortby = $("#jq-sort-by-tr").find("#jq-field-condition-id option:selected").val();
			data.ascdesc = $("#jq-sort-by-tr").find("input[name='asc_desc']").val();
			data.limit  = $("#jq-limit-tr").find(".jq-limit-for").val();
			data.description = $("#jq-description-tr").find("textarea").val();

			console.log(data);


			$( "#jq-create-report" ).submit();
						
		});

	$( "#tabs" ).tabs();
	  
	// Clona la fila oculta que tiene los campos base, y la agrega al final de la tabla
	$("#jq-add-join-clone").on('click', function(){
		$("#jq-container-add-join-clonable").clone().removeClass("hidden-obj").insertAfter("#jq-container-add-join");
	});

	$("#jq-report-form").off("click", "#jq-delete-join-clone").on("click", "#jq-delete-join-clone", function() {
		$(this).parents("#jq-container-add-join-clonable").remove();
	});
	
	  // Evento que selecciona la fila y la elimina
	$(document).on("click",".jq-delete-join-clone",function(){
		var parent = $(this).parent();
		$(parent).remove();
	});	
});		
//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('create_reports_heading');?></span>
</div>		     
<div class="panel panel-default">
	<div class="panel-body scrollable-users-table">
		<div id="jq-add-user-div" class="add_user left-wrapper scrollable">
			<div id="jq-report-form">
				<?php echo form_open("report_controller/create_reports");?>
				<div class="table-responsive">
				<table class="table table-hover table-condensed create-report">
					  <tr id="jq-identification-tr">  <!-- Nombre -->
				            <td><?php echo lang('create_reports_name', 'name_report');?></td>
				            <td><input type='text' value='' name='name' class='form-control input_text jq-name-report jq-required-field' placeholder='Nombre del Reporte' /></td>
				            
				      </tr>
				      <tr id="jq-tables-tr"> <!-- Tabla -->
				      		<td><?php echo lang('create_reports_table', 'tables');?></td>
				            <td><?php echo form_dropdown_id_required('table', 'jq-table-id', $tablesList, '');?></td>
				      </tr>
				      <tr id="jq-fields-tr"> <!-- Campos de tabla seleccionada -->    
				             <td><?php echo lang('create_reports_fields', 'field');?></td>
				             <td class="report-fields"><select multiple name="fields[]" class="form-control jq-required-field" id="jq-field-id"><option value=""><?php echo lang("site_select");?></option></select></td>           
				             
				             <!-- opciones seleccionar todos los campos / conteo total 
				       		 <td><?php echo lang('create_reports_option', 'option');?></td>
				             <td class="order-options"><input type='checkbox' value=""> Total</td>-->				             
				      </tr>
				      <tr>
				      	<td><?php echo lang("create_report_count");?></td>
				      	<td><input type="checkbox" name="count" id="jq-count" value="1" /></td>
				      </tr>
				     
				      <tr><td><span id="jq-add-join" data-toggle="tooltip" title="Haz clic si deseas a&ntilde;adir una combinaci&oacute;n de tablas" class="minimal-normal-link my_tooltip"><?php echo lang("create_report_join");?></span></td> </tr>
				     
				      <tr id="jq-container-add-join" class="hidden-obj">				     
				    	  <td><?php echo lang('create_reports_join_table', 'tables');?></td>
				          <td><?php echo form_dropdown_id('table_join', '', $tablesList, '');?><button type="button" class="btn btn-primary" id="jq-add-join-clone">+</button></td>
				          <td class = "clonable hidden-obj"><?php echo form_dropdown_id('table_join', '', $tablesList, '');?><td>	      
				      </tr>
				       <tr id="jq-container-add-join-clonable" class="hidden-obj">				     
				    	  <td></td>
				          <td class="testt"><?php echo form_dropdown_id('table_join', '', $tablesList, '');?>
				          	<button type="button" class="btn btn-danger" id="jq-delete-join-clone">-</button></td>
				      </tr>
				      
				      <tr id="jq-operator-tr"> <!-- Condici�n por campo --> 
				      		<td> <?php echo lang('create_reports_condition', 'field_condition');?></td>
				      		<td id="jq-select-field"><span class="no-info"><?php echo lang('site_select_table', 'select');?></span></td>            
				      	    <td><select id="jq-field-condition-id" class="" name="fields_where" style="display: inline-block;"></td>
				      	    
				      	    <!-- Operador -->
				      	    <td> <?php echo lang('create_reports_operation', 'operators');?></td>
				      	    <td><?php echo form_dropdown_id('operator', 'jq-operator-id', $operatorList, '');?> </td>
				      	    
				      	    <!-- valor operador -->
				      	    <td><?php echo lang('create_reports_value_operation', 'value_operator');?></td>
				      	    <td><input type="text" name="first_value" class='form-control input_text small first-value jq-first-value' placeholder="Valor primer campo" value="" /></td>
				      	    
				      	   	<td class="between"><?php echo lang('create_reports_value_between', 'value_between');?></td>
				      	    <td class="jq-between"><input type="text" name="second_value" class='form-control input_text small second-value jq-second-value' placeholder="Valor segundo campo" value="" /></td>
				    				      	  
				      	  <td><div class="btn-group group-buttons-options btn-group-xs visible-lg" data-toggle="buttons">
				  			<label id="jq-report-and" class="btn btn-primary my_tooltip" data-toggle="tooltip" data-placement="top" title="Y"><input type="radio" name="options" id="jq-report-and" value="and"><?php echo lang('create_reports_and', 'and');?></label>
				  			<label id="jq-report-or" class="btn btn-primary my_tooltip" data-toggle="tooltip" data-placement="top" title="O"><input type="radio" name="options" id="jq-report-or" value="or"><?php echo lang('create_reports_or', 'or');?></label>
				  			<label id="jq-report-andor-cancel" class="btn btn-primary my_tooltip" data-toggle="tooltip" data-placement="top" title="Cancelar"><input type="radio" name="options" id="jq-report-andor-cancel" value=""><?php echo lang('create_reports_andor_cancel', 'andor_cancel');?></label>
						</div></td>     	    
				      </tr>
				      
				     
				      
				      <!-- //TODO clone
				      
				       <tr><td><span id="jq-add-join" data-toggle="tooltip" title="Haz clic si deseas a&ntilde;adir una combinaci&oacute;n de tablas" class="minimal-normal-link my_tooltip">Combinar Tablas</span></td> </tr>
				        -->
				      
				      <tr id="jq-sort-by-tr">
				      	<td> <?php echo lang('create_reports_sort_by', 'sort_by');?></td>
				      		<td id="jq-select-field"><span class="no-info"><?php echo lang('site_select_table', 'select');?></span></td>            
				      	    <td><select id="jq-field-condition-id" class="" name="order_by" style="display: inline-block;"></td>
				      	 
				      	 <td> <?php echo lang('create_reports_asc_desc', 'asc_desc');?></td>   
				      	 <td><div class="input-group group-options">
				      	    	<span class="input-group-addon">
				      	    		<input type="radio" name="asc_desc" id="jq-report-asc" value="asc" />
				      	    	</span>
				      	    	<label type="text" class="form-control asc_desc my_tooltip" data-toggle="tooltip" data-placement="top" title="Ascendente"> <?php echo lang('create_reports_asc', 'asc');?> </label>
				      	    	<span class="input-group-addon">
				      	    		<input type="radio" name="asc_desc" id="jq-report-desc" value="desc" />
				      	    	</span>
				      	    	<label type="text" class="form-control asc_desc my_tooltip" data-toggle="tooltip" data-placement="top" title="Descendente"> <?php echo lang('create_reports_desc', 'desc');?> </label>
				      	  </div></td>						
				      </tr>
				      <tr class="jq-limit-tr">
				      		<td><?php echo lang('create_reports_limit_for', 'limit_for');?></td>
				      	    <td><input type="text" name="limit" placeholder="Ej.: 10" maxlength="15" class="form-control input_num jq-limit-for jq-numeric-field" value="" /> </td>
				      </tr>
				      <tr id="jq-description-tr">
				      		<td><?php echo lang('create_product_ldescription_label', 'description');?></td>
				            <td> <?php echo form_textarea($description,'', '');?> </td>
				      </tr>
				      <tr> 
				      	   <td style="padding-top: 30px;"><?php echo form_submit_report('submit', lang('create_reports_submit_btn'));?>  </td>
				      	   <td style="padding-top: 30px;"><?php echo form_reset('reset', lang('create_product_cancel_btn'));?> </td>
				      </tr>
				<?php echo form_close();?>
				</table>
				</div>
			</div>
		</div>
	</div>
</div>