<?php $this->load->view("includes/test_head");?>
<?php $this->load->view("includes/modals_product");?>
<script type="text/javascript">//<![CDATA[
$(function() {

	<?php $this->load->view("pages/js/allocate_prod");?>
	
	selectMenuUpperAdmProd();		
	$('.my_tooltip').tooltip('trigger');

	/*Eliminar un producto - Ventana Modal.*/
	$("body").off("click", "#jq-delete-product").on("click", "#jq-delete-product", function() {	
		var tr_selected = $(this).parentsUntil("tr").parent();	
		$('#modal-delete').data('id', tr_selected).modal('show');	
		$(".modal-body-delete").find("span.num-serial").text(tr_selected.find(".jq-serial-number-product").text());
	});

	$('#btnYes').click(function() {
		var tr_selected = $('#modal-delete').data('id');
		$.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('pages/ajax_delete_product');?>", 
	         data: {id_product: tr_selected.find(".jq-product-id").val()},
	         dataType: "text",  
	         cache:false,
	         success:  
	              function(data){
	              <?php echo notify("El producto se ha eliminado con �xito", "success"); ?>;
	             	 $('#modal-delete').modal('hide');
	        		 $(tr_selected).remove();		        	 
	              }	 	                
	     });
	});

	
	$("body").off("click", "#jq-view-product").on("click", "#jq-view-product", function() {	
		var tr_selected = $(this).parentsUntil("tr").parent();  	
		$.ajax({ 
		     type: "POST",
		     url: "<?php echo site_url('pages/ajax_view_product');?>", 
		     data: {id_product: tr_selected.find(".jq-product-id").val()},
		     cache:false,
		     success: function(data){
		       	 var resp = $.parseJSON(data);	
		       	$.each(resp, function(index, value) {
		       		/* JSON : [{"serialNumber":"serie","datePurchase":"0000-00-00 00:00:00","imei":"im","ram":"0","hdd":"0",
	        		"cost":"0","quantity":"0","cpu":"pro","productId":"12","usuarioId":null,"tipo":"Conectividad","id":null,
	        		"nombre":null,"apellido":null,"modelo":"Inspiron","estado":"Caducado","marca":"Compaq","sistema":"Fedora"}]*/       		
				        		
		  		 var html = "<div class='jq-result-view-product text-align'>";
		      		 html += "<table class='table table-hover'>";
		      		 html += "<tr>";		
		      		 html += "<td> N&uacute;mero de Serie</td>";				        		 
		       		 html += "<td> "+ value.serialNumber+" </td>";
		         	 html += "</tr>";
			      	 html += "<tr>";						        
			       	 html += "<td> N&uacute;mero Fecha de Ingreso</td>";	         	 
			      	 html += "<td> "+ value.datePurchase+" </td> ";	
			       	 html += "</tr>";					  
			       	 if(value.imei != ""){	
			        	 html += "<tr>";						     	        
			        	 html += "<td> N&uacute;mero de IMEI</td>";		
			        	 html += "<td> "+ value.imei+ "</td> ";	
			        	 html += "</tr>";
			       	 }
			       	 if(value.ram > 0){	
			        	 html += "<tr>";						     	        
			        	 html += "<td> RAM</td>";		
			        	 html += "<td> "+ value.ram+ "</td> ";	
			        	 html += "</tr>";
			       	 }		
			       	 if(value.hdd > 0){	
			        	 html += "<tr>";						     	        
			        	 html += "<td> HDD</td>";		
			        	 html += "<td> "+ value.hdd+ "</td> ";	
			        	 html += "</tr>";
			       	 }  	
			         html += "<tr>";				     
			         html += "<td> Costo Unitario</td>";   	
			         html += "<td> "+ value.cost+" </td> ";			
			         html += "</tr>";
			         html += "<tr>";		        	
			         html += "<td> Restante </td>";
			         html += "<td> "+ value.quantity+" </td> ";		
			         html += "</tr>";
			       	 if(value.cpu > 0){	
			        	 html += "<tr>";						     	        
			        	 html += "<td> CPU</td>";		
			        	 html += "<td> "+ value.cpu+ "</td> ";	
			        	 html += "</tr>";
			       	 }
			         html += "<tr>";			        
			         html += "<td> Tipo</td>";	
			         html += "<td> "+ value.tipo+" </td> ";		
			         html += "</tr>";
			       	 if(value.apellido != null && value.nombre != null){	
				       	 html += "<tr>";						     	        
				       	 html += "<td> Asignado a</td>";		
				       	 html += "<td> "+ value.nombre+ " "+ value.apellido+ " " +" </td> ";	
				       	 html += "</tr>";
				   	 }
				  	 html += "<tr>";				     
				  	 html += "<td> Modelo</td>";   		
				  	 html += "<td> "+ value.modelo+" </td> ";		
				   	 html += "</tr>";
				   	 html += "<tr>";			        
				  	 html += "<td> Estado</td>";		
				   	 html += "<td> "+ value.estado+" </td> ";	
				   	 html += "</tr>";
				   	 html += "<tr>";				     
				  	 html += "<td> Marca</td>";   		
				   	 html += "<td> "+ value.marca+" </td> ";	
				  	 html += "</tr>";
				  	 if(value.sistema != null){
				      	 html += "<tr>";				     
				      	 html += "<td> Sistema</td>";   		
				       	 html += "<td> "+ value.sistema+" </td> ";	
				       	 html += "</tr>";
				   	 }					        	 
				      	 html += "</table>";				
				       	 html += "</div>";
	        	  $(".modal-body-info-prod").append(html);
	       		});
	       	  }
	       });
		 $('#modal-info-prod').modal('show');	
	});
	
	$("#send").click(function()
		    {       
		     $.ajax({
		         type: "POST",
		         url: "<?php echo site_url('pages/ajax_search_product');?>", 
		         data: {textbox: $("#textbox").val()},
		         dataType: "text",  
		         cache:false,
		         success: 
		              function(data){
		                var result = $('<div />').append(data).find('.jq-table-product-results').html();
			            $('.jq-table-product-results').html(result);			                
		              }
		     });
		     return false;
		 });

	$('#btnInfo').click(function() {
		$('#modal-info-prod').modal('hide');
		$('#modal-info-prod').find(".modal-body-info-prod").html('');
		
	});
	
	 $("#menu").menu();
});

//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>
<?php $this->load->view('includes/menu_upper');?>
<div class="view-header">
	<span class="middle2"><?php echo lang('admin_product_heading');?></span>
	<form class="navbar-form navbar-right form-search-user" role="search" method="post">
  			<div class="form-group">
  			   <input type="text" class="form-control input-search" id="textbox" placeholder="<?php echo lang("search_product");?>">
  			</div>
  			<button id="send" type="submit" name="textbox" class="btn btn-small btn-success"><?php echo lang('create_product_lsearch_label')?></button>
  			<a href="<?php echo site_url('pages/create_product');?>" id="jq-create-product" class="btn btn-small btn-success" role="button"><?php echo lang('create_product_submit_btn');?></a>	    
	</form>		
</div>		
<div id="infoMessage"><?//php echo $message;?></div>
<div class="scrollable-users-table">
<table class="jq-table-product-results table table-hover">
<?php if($product == null) {?>
			<tr>
				<td><div class="alert alert-warning" role="alert">
						<strong><?php echo lang("index_warning");?>! </strong><?php echo lang("index_no_results_found");?></div></td>
			</tr>
	<?php }else{?>
		<thead>
			<tr>
				<?php $width1 = 10; $width2 = 12; $width3 = 12; $width4 = 18; $width5 = 10; $width6 = 10; $width7 = 12; $width8 = 16;?>
				<th width="<?php echo $width1;?>%"><?php echo lang('create_product_lserie_label');?></th>
				<th width="<?php echo $width2;?>%"><?php echo lang('create_product_ltipo_label');?></th>
				<th width="<?php echo $width3;?>%"><?php echo lang('create_product_lmarca_label');?></th>
				<th width="<?php echo $width4;?>%"><?php echo lang('create_product_lmodel_label');?></th>
				<th width="<?php echo $width5;?>%"><?php echo lang('index_quantity');?></th>				
				<th width="<?php echo $width6;?>%"><?php echo lang('create_product_lstatus_label');?></th>
				<th class="align-left" width="<?php echo $width7;?>%"><?php echo lang('create_product_lassigned_label');?></th>
				<th class="align-left" width="<?php echo $width8;?>%"><?php echo lang('index_action_th');?></th>
			</tr>
		</thead>
		<tbody>
	<?php foreach ($product as $row):?>
		<tr class="jq-row-product text-left">
			<td class="jq-serial-number-product"><input type="hidden" value="<?php echo $row['productId'];?>" class="jq-product-id" />
			<?php echo $row['serialNumber'];?></td>
			<td><?php echo $row['tipo'];?><input type="hidden" value="<?php echo $row['type'];?>" class="jq-type-id" /></td>
			<td><?php echo $row['marca'];?></td>
			<td><?php echo $row['modelo'];?></td>
			<td><?php echo ($row['total'] != null)?$row['total']: $row['quantity'];?> / <span class="jq-quantity-1">
				<?php echo ($row['quantity'] == "1" && ($row['nombre'] != null && $row['apellido'] != null))?0:$row['quantity'];?></span></td>			
			<td class="jq-product-status"><?php echo $row['estado'];?><input type="hidden" value="<?php echo $row['product_statusId'];?>" class="jq-product_status-id" /></td>
			<?php if($row['nombre'] != null && $row['apellido'] != null) {?>
				<td class="jq-allocate-user"><?php echo $row['nombre'].' '.$row['apellido'];?></td>
			<?php }else if($row['total'] > $row['quantity']){?>
				<td><a class="normal-link" id="jq-view-allocate">Ver asignados</a></td>
			<?php }else{?>
				<td><span class="no-info"><?php echo "no asignado";?></span><span class="jq-user-select hidden-obj"></span></td>
			<?php }?>
			<td>		
			<a id="jq-view-product"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('information.png');?>" data-toggle="tooltip" title="<?php echo lang("index_view_user");?>"></a>
	        <a id="jq-allocate-product"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('check.png');?>" data-toggle="tooltip" title="<?php echo lang("index_allocate_product");?>"></a>	
			<a href="<?php echo site_url('auth/editProduct/'.$row['productId']);?>" id="jq-edit-product"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('edit.png');?>" data-toggle="tooltip" title="<?php echo lang("index_edit_user");?>"></a>
			<a id="jq-delete-product"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('delete_unit.png');?>" data-toggle="tooltip" title="<?php echo lang("index_delete_th");?>"></a>
	         </td>			
		</tr>
	<?php endforeach;}?>
	</tbody>
</table>
</div>