<?php $this->load->view("includes/test_head");?>
<?php $this->load->view("includes/modals_report");?>
<http-equiv="X-UA-Compatible" content="IE=edge"/>
<script type="text/javascript">//<![CDATA[
$(function() {
	selectMenuUpperReports();
	<?php $this->load->view("pages/js/utilities");?>
		
	$(".jq-view-pdf-one").click(function(e){
        e.preventDefault(); 
        var url = "<?php echo site_url('report_controller/view_pdf');?>";
        window.open(url, 'Exportar a PDF', "height=700,width=800");
    });

	$("body").off("click", "#jq-graphic-report").on("click", "#jq-graphic-report", function(e) {
		var tr_selected = $(this).parentsUntil("tr").parent();		
		$("#modal-chart").find(".modal-title").text("");
		$('#modal-chart').modal('show');	
		$('.modal-body-chart-report').highcharts({
		        chart: {
		            type: 'bar'
		        },
		        title: {
		            text: tr_selected.find(".jq-name-report").text()
		        },
		        xAxis: {
		            categories: ['Funcionarios']
		        },
		        yAxis: {
		            title: {
		                text: '2014'
		            }
		        },
		        series: [{
		            name: 'Total',
		            data: [14]
	       	 }],
		       	exporting: {
		            enabled: true
		        },
		        credits: {
		            enabled: false
		        }
	 	   });
	 	});
});

//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>
<div id="dialog-view-product" class="view-product" title="Download complete"></div>
<div class="view-header-report">
	<span class="middle2"><?php echo lang('reports_heading');?></span>
	<div class="create-reports">
	    <a href="<?php echo site_url('report_controller/create_reports');?>" id="jq-create-reports"> 
	    	<input class="btn btn-small btn-success button-create" type="button" value="<?php echo lang('create_reports_heading');?>"></a>	    
	</div>	
</div>		

<div class=" table-responsive">
<table id="jq-table-static-report" class="jq-table-offer-results table table-hover table-condensed text-left" style="float: left;">
		<thead>
			<tr>
				<?php $width1 = 2; $width2 = 55; $width3 = 43; ?>
				<th width="<?php echo $width1;?>%">#</th>
				<th width="<?php echo $width2;?>%"><?php echo lang('reports_inform_static');?></th>
				<th width="<?php echo $width3;?>%"  style="text-align: center;"><?php echo lang('index_action_th');?></th>
			</tr>
		</thead>
		<tbody>
		<tr class="hidden-obj" id="jq-report-clonable">
			<input type="hidden" value="" class="jq-report-id" />		
			<td>#</td>
			<td id="jq-name-report-tr" class="jq-name-report"></td>
			<td class="actions-report">
				<a id="jq-info-report" class="btn btn-mini btn-info btn-report" title="">
		           		<i class="glyphicon glyphicon-info-sign"></i></a>	            
	            <a href="<?php echo site_url('report_controller/excel_test/user_report');?>" id="jq-excel-report" class="btn btn-mini btn-success btn-report"> 
	            	<i class="glyphicon glyphicon-list-alt"></i></a>
	          	            
	            <a id="jq-graphic-report" class="btn btn-mini btn-warning btn-report" title="">
		           		<i class="glyphicon glyphicon-signal"></i></a>
	            
	            <!-- <a id="jq-print-report" class="btn btn-mini btn-primary btn-report" title="">
		           		<i class="glyphicon glyphicon-print"></i></a>-->
	            
	           <!-- <a id="jq-delete-report" class="btn btn-mini btn-danger jq-delete btn-report" title="Eliminar">
		           		<i class="glyphicon glyphicon-remove"></i></a>-->
	         </td>			
		</tr>
		<?php $i = 1; 
		if( isset($report) && !empty($report)) 
			foreach ($report as $row):?>
		<tr class="jq-row-report text-left">
			<input type="hidden" value="<?php echo $row['reportId'];?>" class="jq-report-id" />		
			<td>#</td>
			<td class="jq-name-report"><?php echo $row['name'];?></td>
			<td class="actions-report">
				<a id="jq-info-report" class="btn btn-mini btn-info my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_info");?>">
		           		<i class="glyphicon glyphicon-info-sign"></i></a>	            
	            <a href="<?php echo site_url('report_controller/excel_report/'.$row['reportId']);?>" class="btn btn-mini btn-success my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("index_export_excel");?>"> 
	            	<i class="glyphicon glyphicon-list-alt"></i></a>
	          	            
	            <a id="jq-graphic-report" class="btn btn-mini btn-warning my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_graphic");?>">
		           		<i class="glyphicon glyphicon-signal"></i></a>
	            
	         <!--   <a id="jq-print-report" class="btn btn-mini btn-primary my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_print");?>">
		           		<i class="glyphicon glyphicon-print"></i></a> -->
	            
	         <!-- <a id="jq-delete-report" class="btn btn-mini btn-danger jq-delete my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("index_delete_th");?>">
		           		<i class="glyphicon glyphicon-remove"></i></a>-->
	         </td>			
		</tr>
	<?php $i++; endforeach;?>
	</tbody>
</table>
</div>

<div class=" table-responsive">
	<table id="jq-table-dinamic-report" class="jq-table-offer-results table table-hover table-condensed text-left" style="float: right;">
		<?php if($report_dinamic == null) {?>
			<tr>
				<td><div class="alert alert-info" role="alert">
						<strong><?php echo lang("index_info");?>! </strong><?php echo lang("index_no_report");?></div></td>
			</tr>
		<?php }else{?>
		<thead>
			<tr>
				<?php $width1 = 2; $width2 = 55; $width3 = 45; ?>
				<th width="<?php echo $width1;?>%">#</th>
				<th width="<?php echo $width2;?>%"><?php echo lang('reports_inform_dinamic');?></th>
				<th width="<?php echo $width3;?>%" style="text-align: center;"><?php echo lang('index_action_th');?></th>
			</tr>
		</thead>
		<tbody>
		<?php $i = 1; 
		if( isset($report_dinamic) && !empty($report_dinamic)) 
			foreach ($report_dinamic as $row):?>
		<tr class="jq-row-report text-left">
			<input type="hidden" value="<?php echo $row['reportId'];?>" class="jq-report-id" />		
			<td>#</td>
			<td class="jq-name-report"><?php echo $row['name'];?></td>
			<td class="actions-report"><a id="jq-info-report" class="btn btn-mini btn-info my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_info");?>">
		           		<i class="glyphicon glyphicon-info-sign"></i></a>	            
	            <a href="<?php echo site_url('report_controller/excel_test/user_report');?>" id="jq-excel-report" class="btn btn-mini btn-success my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("index_export_excel");?>"> 
	            	<i class="glyphicon glyphicon-list-alt"></i></a>
	          	            
	            <a id="jq-graphic-report" class="btn btn-mini btn-warning my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_graphic");?>">
		           		<i class="glyphicon glyphicon-signal"></i></a>
	            
	         <!--   <a id="jq-print-report" class="btn btn-mini btn-primary my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_print");?>">
		           		<i class="glyphicon glyphicon-print"></i></a> -->
	            
	            <a id="jq-anchor-report" class="btn btn-mini btn-default my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("site_change");?>">
		           		<i class="glyphicon glyphicon-pushpin"></i></a>
	            
	            <a id="jq-delete-report" class="btn btn-mini btn-danger jq-delete my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("index_delete_th");?>">
		           		<i class="glyphicon glyphicon-remove"></i></a></td>
		</tr>
		<?php $i++; endforeach;?>
		</tbody>
		<?php }?>
	</table>
</div>
		