<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css" />

<div id="menu-upper" class="<?php echo (!$this->session->userdata('is_logged_in'))?'menu-upper-not-logged':'';?>">
	<div class="navbar navbar-fixed-top">
		<?php $this->load->view('template/header');?>
	    <div class="navbar-inner menu">
			<div class="container-fluid">
				<a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<div class="nav-collapse">
					<ul class="nav">
						<li class="divider-vertical"></li>
						<li><a href="<?php echo site_url('home');?>"><?php echo lang('site_home');?></a></li>
						
						
						<li class="divider-vertical"></li>
						<li><a href="<?php echo site_url('requests/view_all');?>"><?php echo lang('menu_upper_requests');?></a></li>
						
						<li class="divider-vertical"></li>
						<li><a href="<?php echo site_url('processes/supervised');?>"><?php echo lang('menu_upper_processes');?></a></li>
						
						<li class="divider-vertical"></li>
						<li><a href="<?php echo site_url('offers/view_all');?>"><?php echo lang('menu_upper_offers');?></a></li>
						
						<li class="divider-vertical"></li>
						<li><a href="<?php echo site_url('applicants/search');?>"><?php echo lang('menu_upper_search_cv');?></a></li>
						
						
					</ul>
					<ul class="nav pull-right user-login">
	            		<li class="gradient">
	              			<a href="<?php echo site_url('login/logout');?>"> <i class="icon-user icon-white"></i> <?php echo lang('menu_lat_logout');?></a>
	            		</li>
	          		</ul>
				</div>
	    	</div>
	    </div>
	</div>
</div>