<?php $this->load->view("includes/test_head");?>
<link rel="stylesheet" media="all and (orientation:portrait)" href="<?php echo base_url();?>css/landscape.css">
<script type="text/javascript">//<![CDATA[                                  
	$(function() {	
			$(".menu-select-inicio").animate({ backgroundColor: "#21759B" }, "slow"); 
			$(".inicio").css('color', '#FFFFFF'); 

			$(".jq-message_item_container").off("click").on("click",function(event){
				if($(event.target).parent().hasClass("jq-message")) {
					activate_deactivate($(event.target), 'message');
				}else if($(event.target).parent().hasClass("jq-delete")) {
					activate_deactivate($(event.target).parent(), 'deactivate');
				}			
			});

			activate_deactivate = function(button, action) {
				console.log(button);
				var container = $(button).parentsUntil(".jq-message_item_container").parent().parent().parent();
				var message_name = $.trim($(button).parent().parent().find(".jq-message-name").text());
				var confirm_text;
				var active;
				var parent = $(button).parent().parent().parent();	
					if(action == 'deactivate') {
						var message_id = $(button).parent().find(".jq-message-id").val();		

						$('#modal-delete-message').modal('show');	
						$('#modal-delete-message').find(".user-message").text(message_name);
						$('#modal-delete-message').find('#btnYes').click(function() {					
							$.ajax({  
						         type: "POST",
						         url: "<?php echo site_url('email_controller/ajax_delete_message');?>", 
						         data: {id_message: message_id},
						         dataType: "text",   
						         cache:false, 
						         success:  
						              function(data){						  	        		
						              	$('#modal-delete-message').modal('hide');
						              	var new_value = $("#jq-message-list").find("span.badge").text() - 1;
    						        	$("#jq-message-list").find("span.badge").text(new_value);
						              	$(container).hide("highlight", "slow", function() {
						        			 $(container).remove();	
						        			 <?php echo notify(lang("send_email_delete_message"), "success"); ?>;
						              	 });	 						        		        	 
						           }	 	                
							});
						});			
					
					}else if(action == 'message') {
						var message_id = $(button).parent().parent().find(".jq-message-id").val();
						 $.ajax({ 
					         type: "POST",
					         url: "<?php echo site_url('email_controller/ajax_view_message');?>", 
					         data: {id: message_id},
					         cache:false,
					         success: function(data){	
					        	 var resp = $.parseJSON(data);	
					        	$.each(resp, function(index, value) {	
						        	 var html = "<div class='jq-result-view-product text-align'>";
						        	 html += "<table class='table table-hover'>";
						        	 html += "<tr>";
					        		 html += "<td style='width:190px;'><b>" + value.name + "</b></td>";	
					        		 html += "<td></td>";	
					        		 html += "</tr>";
					        		 html += "<tr>";
					        		 html += "<td> <?php echo lang("create_user_validation_jobtitle_label");?>: </td>";				        		 
					        		 html += "<td>" + value.jobtitle + "</td>";
					        		 html += "</tr>";		
					        		 html += "<tr>";
					        		 html += "<td> <?php echo lang("create_user_email_label");?>: </td>";				        		 
					        		 html += "<td>" + value.email + "</td>";
					        		 html += "</tr>";	
					        		 html += "<tr>";
					        		 html += "<td> <?php echo lang("site_request");?>: </td>";				        		 
					        		 html += "<td>" + value.message_user + "</td>";	
					        		 html += "</tr>";
					        		 html += "</table>";				
						        	 html += "</div>";				        		

						        	 $('#modal-message').find(".modal-body").append(html);
					        		});				        		
					              }	 	                
					     });     	

						 $.ajax({ 
					         type: "POST", 
					         url: "<?php echo site_url('email_controller/ajax_read_message');?>", 
					         data: {id: message_id},
					         cache:false, 
					         success: function(data){	 			    						        	
					        	 $(container).find(".jq-image-message").attr("src","<?php get_image('message_already_read.png'); ?>");	
					        	 $(parent).removeClass("active_message");			    						        		
					        	 $(parent).addClass("inactive_message");
					           }	 	                
					     });
						 $('#modal-message').find(".modal-body").html("");			

						$('#modal-message').modal('show');		
					}
			};

			$('#btnCancelInfo').click(function() {
				$("#modal-message").find(".modal-body").html("");
			});

			//console.log(jQuery.fn.jquery);
});	
//]]></script>			
<?//php phpinfo();?>	
<?//php echo CI_VERSION;?>					        			 
<!-- Modal info producto -->
<div id="modal-message" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header without-border">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo lang("site_close");?></span></button>
        <h4 class="modal-title"><?php echo lang("send_email_msg");?></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="btnCancelInfo" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-delete-message" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header without-border">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo lang("site_close");?></span></button>
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo lang("send_email_message");?><span class="user-message"></span></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYes"><?php echo lang("index_delete_th");?></button>
        <button type="button" class="btn btn-default" id="btnCancelDelete" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
						        			 
<div id="menu-upper" class="">
	<div class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs" id="landscape"><?php echo lang('index_title');?></span>
	</div>
</div>

<?php $user = $this->ion_auth->user()->row(); 	  
	  $group_id = $this->ion_auth->group_test($user->id);		
	  $detail = $this->ion_auth->get_all_info_user_by_id($user->id);
		
		$admin = false;
		foreach ($group_id as $gid){
			$var = $gid->groupId;
			if($var == 1){
				$admin = true;
			}
		}
		if($admin){
			$class="style='display: none;'";	
			$hidden = "";
			if(isset($send_email) == null){
				$hidden="style='display: none;'";
			}			
		}else{
			$hidden="style='display: none;'";
			$class="";
		}
	  $this->load->view('includes/menu_upper'); ?>

<div class="view-header">
<h2 class="welcome"> <?php echo lang('home_welcome');  echo $user->first_name." ".$user->last_name;?></h2>

<?php 
date_default_timezone_set("Chile/Continental");
$t = $user->last_login;?>
<span class="welcome-message"><?php echo lang('index_message_welcome')." ".date('d/m/y H:i:s',$t);?></span>
</div>		
<br/>
<div class="notify-email" id="jq-notify-emails" <?php echo $hidden;?>>	
<div class="scrollable_message message_list" id="jq-message-list">
	<div class="view-header2"><span class="middle2"><?php echo lang('site_message');?></span><span class="badge"><?php echo count($send_email);?></span></div>
	  <div class="row">
	    <?php foreach ($send_email as $row):?>    
	      <div class="col-sm-5 col-md-2">
	       <div class="thumbnail">
	        <div class="jq-message_item_container <?php echo ($row['viewed'] == 0)?' active_message':' inactive_message'?>">
	            <div class="jq-message-action message_action text-left">
	            <input type="hidden" class="jq-message-id" value="<?php echo $row['send_emailId'];?>"/>
	                 <a id="jq-delete-message" class="btn btn-mini btn-danger jq-delete my_tooltip" data-toggle="tooltip" title="<?php echo lang("index_delete_th");?>">
		           		<i class="glyphicon glyphicon-remove"></i>
	   				</a>
	                <a id="jq-view-message" class="btn btn-mini btn-default jq-message my_tooltip" data-toggle="tooltip" title="<?php echo lang("index_read_th");?>">
	                    <i class="glyphicon glyphicon-search"></i>
	                </a>
	            </div>
	                <?php if($row['viewed'] == 0) {  
		                	$image= "new_message.png";
	                	 } else { 
	                	 	$image= "message_already_read.png";
	                 } ?>
	                	<img class="jq-image-message img-message" style="cursor: pointer;" src="<?php get_image($image);?>">         
	            <div class="caption">
	           <p><span class="message_name jq-message-name"><?php echo $row['name'];?></span></p></div>
	        </div>
	        </div>
	        </div>
	    <?php endforeach;  ?>
	</div>
</div>
</div>

<div class="panel panel-info" <?php echo $class;?>>
  <div class="panel-heading text-align"><b><?php echo lang('index_info_user');?></b></div>
  <div class="panel-body table-responsive">
    <table class="table table-hover table-condensed text-align">
	      <tr>
	             <td><b><?php echo lang('create_user_fname_label', 'first_name');?></b></td>
	             <td><?php echo $user->first_name;?></td>           
	      
	             <td><b><?php echo lang('create_user_lname_label', 'first_name');?></b></td>
	             <td><?php echo $user->last_name?></td>    
	      
	             <td><b><?php echo lang('create_user_lrut_label', 'rut');?></b></td>
	             <td><?php echo $user->rut;?></td>                  
	      </tr> 
	      <tr>
	             <td><b><?php echo lang('create_user_email_label', 'email');?></b></td>
	             <td><?php echo $user->email;?></td>                       
	      
	             <td><b><?php echo lang('create_user_validation_jobtitle_label', 'phone');?></b></td>
	             <td><?php echo $detail[0]['Cargo'];?></td>                    
	      
	             <td><b><?php echo lang('create_user_company_label', 'company');?></b></td>
	             <td><?php echo $detail[0]['Area'];?></td>           
	      </tr> 
	      <tr>
	             <td><b><?php echo lang('create_user_phone_label', 'phone');?></b></td>
	             <td><?php echo $user->phone;?></td>                    
	      
	             <td><b><?php echo lang('create_user_ldate_admission_label', 'dateAdmission');?></b></td>
	             <td><?php echo $user->dateAdmission;?></td> 
	             
	             <td></td>
	             <td></td>          
	      </tr>                 
	</table>
  </div>
</div>

<div class="panel panel-info" <?php echo $class;?>>
  <div class="panel-heading text-align"><b><?php echo lang('index_info_prod');?></b></div>
  <div class="panel-body">
    <table class="table table-hover table-condensed text-align">  		
			<?php if($detail[0]['trademarkId'] != null){
				foreach ($detail as $row):?>	
				<tr><td><?php echo $row["Tipo"]?>:
				<?php echo $row["Marca"]?>,
				<?php echo $row["Modelo"]?>.</td></tr>		
			<?php endforeach;?>
			<?php }else{ ?>
				<tr><td><?php echo lang("index_request");?>
			<?php }?>
				  	<a href="<?php echo site_url('email_controller/send_email');?>" id="jq-send_email" class="btn btn-mini btn-warning my_tooltip btn-report" data-toggle="tooltip" title="<?php echo lang("send_email_submit_btn");?>">
		           		<i class="glyphicon glyphicon-envelope"></i></a>
		           	</td>
			    </tr>
		</table>
  </div>
</div>
<!-- 
<div class="panel panel-info " <?php echo $class;?>>
  <div class="panel-heading"><?php echo lang("index_info_user");?></div>
  <div class="panel panel-info-one" <?php echo $class;?>>
  <table class="table table-hover table-condensed">
	      <tr>
	            <td><?php echo lang('create_user_fname_label', 'first_name');?></td>
	            <td><?php echo $user->first_name;?></td>           
	      </tr>
	      <tr>	      
	             <td><?php echo lang('create_user_lname_label', 'first_name');?></td>
	             <td><?php echo $user->last_name?></td>    
	      </tr>
	      <tr>
	             <td><?php echo lang('create_user_lrut_label', 'rut');?></td>
	             <td><?php echo $user->rut;?></td>                  
	      </tr> 
	      <tr>
	             <td> <?php echo lang('create_user_email_label', 'email');?></td>
	             <td><?php echo $user->email;?></td>                       
	      </tr>
	      <tr>
	             <td><?php echo lang('create_user_validation_jobtitle_label', 'phone');?></td>
	             <td><?php echo $detail[0]['Cargo'];?></td>                    
	      </tr>    
	      <tr>
	             <td><?php echo lang('create_user_company_label', 'company');?></td>
	             <td><?php echo $detail[0]['Area'];?></td>           
	      </tr> 
	      <tr>
	             <td><?php echo lang('create_user_phone_label', 'phone');?></td>
	             <td><?php echo $user->phone;?></td>                    
	      </tr> 
	      <tr>
	             <td><?php echo lang('create_user_ldate_admission_label', 'dateAdmission');?></td>
	             <td><?php echo $user->dateAdmission;?></td>           
	      </tr>                 
	</table>
	</div>

<div class="panel panel-info-two" <?php echo $class;?>>
  <div class="panel-heading"><?php echo lang("index_info_prod");?></div>
		<table class="table table-hover table-condensed">  		
			<?php if($detail[0]['trademarkId'] != null){
				foreach ($detail as $row):?>	
				<tr><td><?php echo $row["Tipo"]?>:
				<?php echo $row["Marca"]?>,
				<?php echo $row["Modelo"]?>.</td></tr>		
			<?php endforeach;?>
			<?php }else{ ?>
				<tr><td><?php echo lang("index_request");?></td></tr>
			<?php }?>
			      <tr>
				  	<td><a href="<?php echo site_url('email_controller/send_email');?>" id="jq-send_email"> 
				    <img class="img-email" src="<?php get_image('send_email.png');?>" title="Enviar Correo"></a></td>
			     </tr>
		</table>
	</div>
</div>-->