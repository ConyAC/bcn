<?php $this->load->view("includes/head");?>
<script type="text/javascript">//<![CDATA[

$(function() {

});

//]]></script>
<div id="menu-upper" class="">
<div class="container-fluid banner-header">
	<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
	<span class="tag_line">Sistema de Inventario - BCN</span>
</div>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('statistics_heading');?></span>	
</div>		
<div id="infoMessage"><?php echo $message;?></div>

<html>
  <head>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Work',     11],
          ['Eat',      2],
          ['Commute',  2],
          ['Watch TV', 2],
          ['Sleep',    7]
        ]);

        var options = {
          title: 'My Daily Activities'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <table class="jq-table-offer-results table table-hover">
  <body>
    <div id="piechart" style="width: 900px; height: 500px;" class="scrollable-users-table"></div>
  </body>
  </table>
</html>
