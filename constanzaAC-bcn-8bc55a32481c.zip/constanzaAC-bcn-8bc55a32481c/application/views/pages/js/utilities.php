$("#jq-table-dinamic-report").off("click", "#jq-anchor-report").on("click", "#jq-anchor-report", function() {	
	var tr_selected = $(this).parentsUntil("tr").parent();
	$('#modal-change').data('id', tr_selected).modal('show');	
});

$('#btnYesChange').click(function() {
	var tr_selected = $('#modal-change').data('id');	
	$.ajax({ 
         type: "POST",
         url: "<?php echo site_url('report_controller/ajax_static_report');?>", 
         data: {id_report: tr_selected.find(".jq-report-id").val()},
         dataType: "text",  
         cache:false,
         success:  
              function(data){
              <?php echo notify("El reporte ha sido anclado", "success"); ?>;
             	 $('#modal-change').modal('hide');             	 
             	 var inputBoxEl = $(tr_selected).find('.jq-name-report');
				 var new_tr = $('#jq-report-clonable').clone();
				 $(new_tr).removeAttr('id').removeClass('hidden-obj');
				 $(new_tr).find('#jq-name-report-tr').html(inputBoxEl.text());
				 $(new_tr).find('.jq-report-id').val(tr_selected.find(".jq-report-id").val());
				 $("#jq-table-static-report").append(new_tr);
				 highlightBox(new_tr);				 
				// if($("#jq-table-dinamic-report").find(".jq-row-report").size() > 0) //TODO				 
				 tr_selected.remove();
              }	 	                
     });
});


$("body").off("click", "#jq-delete-report").on("click", "#jq-delete-report", function() {	
	var tr_selected = $(this).parentsUntil("tr").parent();
	$('#modal-delete').data('id', tr_selected).modal('show');	
});

$('#btnYesDelete').click(function() {
	var tr_selected = $('#modal-delete').data('id');	
	$.ajax({ 
         type: "POST",
         url: "<?php echo site_url('report_controller/ajax_delete_report');?>", 
         data: {id_report: tr_selected.find(".jq-report-id").val()},
         dataType: "text",  
         cache:false,
         success:  
              function(data){
              <?php echo notify("El reporte ha sido eliminado", "success"); ?>;
             	$('#modal-delete').modal('hide');             	 
				$(tr_selected).hide("highlight", "slow", function() {
					tr_selected.remove();	
              });	 	      
            }          
     });
});


$("body").off("click", "#jq-info-report").on("click", "#jq-info-report", function() {
		var tr_selected = $(this).parentsUntil("tr").parent();  	
		$.ajax({ 
		     type: "POST",
		     url: "<?php echo site_url('report_controller/ajax_info_report');?>", 
		     data: {id_report: tr_selected.find(".jq-report-id").val()},
		     cache:false,
		     success: function(data){
		       	 var resp = $.parseJSON(data);	
		       	$.each(resp, function(index, value) {
		       	/*[{"reportId":"19","name":"Reporte test","static":"1","table":"2","fields":"name","table_join":"2","fields_where":"0",
		       	"operator":"2","first_value":"eeeeeee","second_value":"rrrrrrrrrrr","and_or":"0","order_by":null,"asc_desc":"0","limit":"3",
		       	"date_creation":"2014-07-20 03:43:49","description":"eeeeerererererer","deleted":"0"}]*/	
		       	 var type = (value.static == "1")?"<?php echo lang("reports_static");?>":"<?php echo lang("reports_dinamic");?>";			        		
		  		 var html = "<div class='jq-result-view-report text-align'>";
		      		 html += "<table class='table table-hover'>";
		      		 html += "<tr>";		
		      		 html += "<td> <?php echo lang("create_reports_name");?></td>";				        		 
		       		 html += "<td> "+ value.name+" </td>";
		         	 html += "</tr>";
			      	 html += "<tr>";						        
			       	 html += "<td><?php echo lang("create_reports_type");?></td>";	         	 
			      	 html += "<td> "+ type+" </td> ";	
			       	 html += "</tr>";					  
			         html += "<tr>";				     
			         html += "<td><?php echo lang("reports_date");?></td>";   	
			         html += "<td> "+ value.date_creation+" </td> ";			
			         html += "</tr>";
			         html += "<tr>";		        	
			         html += "<td> <?php echo lang("reports_description");?> </td>";
			         html += "<td> "+ value.description+" </td> ";		
			         html += "</tr>";			         
				     html += "</table>";				
				     html += "</div>";
	        	  $(".modal-body-info-report").append(html);
	       		});
	       	  }
	       });
		 $('#modal-info').modal('show');	
	});
	
$('#btnYesCancel').click(function() {
	 $(".modal-body-info-report").html("");
});


/*$("body").off("click", "#jq-graphic-report").on("click", "#jq-graphic-report", function() {
		var tr_selected = $(this).parentsUntil("tr").parent();  	

		 $('#modal-info').modal('show');	
	});*/
	
$('#btnYesCancel').click(function() {
	 $(".modal-body-info-report").html("");
});
