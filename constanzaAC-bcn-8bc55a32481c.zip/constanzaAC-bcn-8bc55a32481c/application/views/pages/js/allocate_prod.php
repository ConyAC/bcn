$("body").off("click", "#jq-allocate-product").on("click", "#jq-allocate-product", function() {	
	var tr_selected = $(this).parentsUntil("tr").parent();
	$('#modal-allocate').data('id', tr_selected).modal('show');	
	
	var cant = tr_selected.find(".jq-quantity-1").text();
	//console.log(cant == 1);
	if( cant > 1  ){
		$("#jq-quantity-value, .jq-quantity-value").removeClass("hidden-obj");	
	}else if( cant == 1){
		$("#jq-quantity-value, .jq-quantity-value").addClass("hidden-obj");
	}else if(cant == 0){
		$("#jq-quantity-value, .jq-quantity-value, .jq-user-select, .jq-user").addClass("hidden-obj");
		$(".jq-msg-allocate").removeClass("hidden-obj");
		$("#modal-allocate").find("#btnAllocate").addClass("hidden-obj");
	}
	
	$.ajax({ 
         type: "POST",
         url: "<?php echo site_url('pages/ajax_users');?>", 
         dataType: "text",  
         success:  
              function(data){
				$("#jq-user-product").html(data);    
            }          
     });
});

$('#btnCancelAllocate').click(function() {
	$("#modal-allocate").find("#btnAllocate").removeClass("hidden-obj");
	$(".jq-msg-allocate").addClass("hidden-obj");
	$("#jq-quantity-value, .jq-quantity-value, .jq-user-select, .jq-user").removeClass("hidden-obj");
	$("#jq-quantity-value").val("");

});
	
	
$('#btnAllocate').click(function() {
	var tr_selected = $('#modal-allocate').data('id');		
	var userId = $(this).parents().find("#jq-user-product").val();
	var quantity = $(this).parents().find("#jq-quantity-value").val();
	var user_allocate= tr_selected.find(".jq-allocate-user").text();
	var old_quantity = tr_selected.find(".jq-quantity-1").text();
	var name_user = $(this).parents().find("#jq-user-product option:selected").text();
	
	if(old_quantity > 1){
		/*if(user_allocate != ""){
			$.ajax({ 
		         type: "POST",
		         url: "<?php echo site_url('pages/ajax_update_allocate');?>", 
		         data: {productId: tr_selected.find(".jq-product-id").val(), userId: userId, quantity: quantity},
		         dataType: "text",  
		         cache:false,
		         success:  
		              function(data){
		              console.log(data);
		              <?php echo notify("El reporte ha cambiado de estado", "success"); ?>;
		             	$('#modal-delete').modal('hide');             	 	 	      
		            }          
		     });
	     }else{*/
	     	$.ajax({ 
		         type: "POST",
		         url: "<?php echo site_url('pages/ajax_insert_allocate');?>", 
		         data: {productId: tr_selected.find(".jq-product-id").val(), userId: userId, quantity: quantity},
		         dataType: "text",  
		         cache:false,
		         success:  function(data){
		              <?php echo notify("El producto ha sido asignado", "success"); ?>;
		             	$('#modal-allocate').modal('hide');   
		             	$("#jq-quantity-value").val("");
		             	tr_selected.find('.jq-product-status').text('Asignado');

		            }      
		     });
	    // }
     }else{
	     $.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('pages/ajax_allocate_product');?>", 
	         data: {productId: tr_selected.find(".jq-product-id").val(), userId: userId},
	         dataType: "text",  
	         cache:false,
	         success:  
	              function(data){
	              <?php echo notify("El producto ha sido asignado", "success"); ?>;
	              
	              	var name = $("#jq-user-product option:selected").text();
	              	tr_selected.find(".no-info").addClass("hidden-obj");
	              	tr_selected.find(".jq-user-select").removeClass("hidden-obj").text(name);
	              	tr_selected.find(".jq-quantity-1").text(0);
	             	$('#modal-allocate').modal('hide');     
	             	tr_selected.find('.jq-product-status').text('Asignado');
	            }          
	     });
     }
});


$("body").off("click", "#jq-view-allocate").on("click", "#jq-view-allocate", function() {	
	var tr_selected = $(this).parentsUntil("tr").parent();
	$('#modal-view-allocate').data('id', tr_selected).modal('show');	
	
	$.ajax({ 
        type: "POST",
        url: "<?php echo site_url('pages/ajax_view_allocate');?>", 
        data: {productId: tr_selected.find(".jq-product-id").val()},
        dataType: "text",  
        cache:false,
        success:  
             function(data){
        		 var resp = $.parseJSON(data);	
		       	$.each(resp, function(index, value) { 
		       		$(".jq-table-view-allocate").find("span.jq-fullname-user").append(value.first_name+" "+value.last_name+"<br/>");
		       		$(".jq-table-view-allocate").find("span.jq-quantity-product").append(value.quantity+"<br/>");
		       	});
           }          
    });
});

$("body").off("click", "#btnViewAllocate").on("click", "#btnViewAllocate", function() {	
	$(".jq-table-view-allocate").find("span.jq-fullname-user").html("");	
	$(".jq-table-view-allocate").find("span.jq-quantity-product").html("");
});