<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link
	rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>css/bootstrap.css" />
<link
	rel="stylesheet" type="text/css" media="all"
	href="<?php echo base_url();?>css/style.css" />
<link
	rel="stylesheet" type="text/css" media="all"
	href="<?php echo base_url();?>css/login.css" />
<link
	rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>css/font.css" charset="utf-8" />

<title>BCM</title>

<div id="menu-upper" class="<?php echo (!$this->session->userdata('is_logged_in'))?'menu-upper-not-logged':'';?>">
	<div class="navbar navbar-fixed-top">
		<?php $this->load->view('includes/banner_header');?>
		<?php if($this->session->userdata('is_logged_in')) { ?>
	    <div class="navbar-inner menu">
			<div class="container-fluid">
				<a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<div class="nav-collapse">
					<ul class="nav">
						<?php
						$active_home = ""; $active_processes = ""; $active_requests = ""; $active_offers = ""; $active_search_cv = ""; $active_customize = ""; $active_storage = ""; $active_admin = "";
						if(current_url() == site_url('home'))
							$active_home = "active";
						else if($this->uri->segment(1) == 'processes')
							 $active_processes = "active";
						else if($this->uri->segment(1) == 'requests')
							 $active_requests = "active";
						else if($this->uri->segment(1) == 'offers')
							 $active_offers = "active";
						else if($this->uri->segment(1) == 'applicants')
							 $active_search_cv = "active";
						else if($this->uri->segment(1) == 'storages')
							 $active_storage = "active";
						else if($this->uri->segment(1) == 'administration' || $this->uri->segment(1) == 'companies')
							 $active_admin = "active";
						else
							$active_customize = "active";
						?>
						<li class="divider-vertical"></li>
						<li class="<?php echo $active_home;?>"><a href="<?php echo site_url('home');?>"><?php echo lang('site_home');?></a></li>
						
						
						<?php if(has_permission('view_requests') || has_permission('view_own_requests')) { ?>
						<li class="divider-vertical"></li>
						<li class="<?php echo $active_requests;?>"><a href="<?php echo site_url('requests/view_all');?>"><?php echo lang('menu_upper_requests');?></a></li>
						<?php } ?>
						
						<?php if(has_permission('view_processes') || has_permission('view_own_processes')) { ?>
						<li class="divider-vertical"></li>
						<li class="<?php echo $active_processes;?>"><a href="<?php echo site_url('processes/supervised');?>"><?php echo lang('menu_upper_processes');?></a></li>
						<?php } ?>
						
						<?php if(has_permission('view_offers')) { ?>
						<li class="divider-vertical"></li>
						<li class="<?php echo $active_offers;?>"><a href="<?php echo site_url('offers/view_all');?>"><?php echo lang('menu_upper_offers');?></a></li>
						<?php } ?>						
						
						<?php if(has_permission('search_cv')) { ?>
						<li class="divider-vertical"></li>
						<li class="<?php echo $active_search_cv;?>"><a href="<?php echo site_url('applicants/search');?>"><?php echo lang('menu_upper_search_cv');?></a></li>
						<?php } ?>
						
						<?php if(has_permission('view_storage')) { ?>
						<li class="divider-vertical"></li>
						<li class="<?php echo $active_storage;?>">
							<a href="<?php echo site_url("storages") ?>">
								<span><?php echo lang('menu_upper_storage');?></span>
							</a>
						</li>
						<?php } ?>
						
						<?php if(has_permission('select_language')) { ?>
						<li class="divider-vertical"></li>
						<li class="dropdown">
	              			<a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo lang('site_language');?> <b class="caret"></b></a>
	              			<ul class="dropdown-menu">
	              				<?php foreach($this->config->item('GPS_LANGUAGES') as $key => $language):?>
								<li class="jq-switch-language">
									<a><?php echo $language;?></a>
									<input type="hidden" value="<?php echo $key;?>" class="jq-language-key" />
								</li>	
								<?php endforeach;?>
	              			</ul>
	              		</li>
						<?php } ?>
						
						
						<?php if(has_permission_personalize()) { ?>
						<li class="divider-vertical"></li>
						<li class="dropdown <?php echo $active_customize;?>">
							<a data-toggle="dropdown" class="dropdown-toggle" href="<?php echo site_url('customize');?>"><?php echo lang('menu_upper_customize');?> <b class="caret"></b></a>
							<ul class="dropdown-menu">
								<?php if(has_permission('edit_own_profile')) { ?>
								<li><a href="<?php echo site_url('users/my_profile');?>"><?php echo lang('user_my_data');?></a></li>
								<?php } ?>
								
							 	<?php if(has_permission('manage_templates')) { ?>
								<li><a href="<?php echo site_url('process_templates/manage');?>"><?php echo lang('processtemplate_templates');?></a></li>
								<?php } ?>
							
								<?php if(has_permission('manage_users')) { ?>
								<li><a href="<?php echo site_url('users/manage');?>"><?php echo lang('site_users');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_areas')) { ?>
								<li><a href="<?php echo site_url('departments/manage');?>"><?php echo lang('site_departments');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_roles')) { ?>			
								<li><a href="<?php echo site_url('roles/manage');?>"><?php echo lang('role_roles');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_sources')) { ?>
								<li><a href="<?php echo site_url('sources/manage');?>"><?php echo lang('source_sources');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_client_companies')) { ?>
								<li><a href="<?php echo site_url('client_companies/manage');?>"><?php echo lang('clientcompany_client_companies');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_internal_jobtitles')) { ?>
								<li><a href="<?php echo site_url('internal_jobtitles/manage');?>"><?php echo lang('internaljobtitle_internal_jobtitles');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_video_interviews')) { ?>
								<li><a href="<?php echo site_url('video_templates/manage');?>"><?php echo lang('videointerview_video_interviews');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_dashboard')) { ?>
								<li><a href="<?php echo site_url('dashboard/manage');?>"><?php echo lang('dashboard_dashboard');?></a></li>
								<?php } ?>
								
								<?php if(has_permission('manage_settings')) { ?>
								<li><a href="<?php echo site_url('settings');?>"><?php echo lang('settings_settings');?></a></li>
								<?php } ?>
							 </ul>
						</li>
						<?php } ?>						
						
						<?php if( has_permission('admin_gps') ){ ?>
						<li class="divider-vertical"></li>
						<li class="dropdown <?php echo $active_admin;?>">
							<a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo lang('menu_upper_admin_gps');?> <b class="caret"></b></a>
							<ul class="dropdown-menu">
	                			<li><a href="<?php echo site_url('administration/companies');?>"><?php echo lang('company_companies');?></a></li>
	                			<li><a href="<?php echo site_url('companies/create');?>"><?php echo lang('company_create');?></a></li>
	             			</ul>
						</li>
						<?php } ?>
						
					</ul>
					<ul class="nav pull-right user-login">
	            		<li class="gradient">
	              			<a href="<?php echo site_url('login/logout');?>"> <i class="icon-user icon-white"></i> <?php echo lang('menu_lat_logout');?></a>
	            		</li>
	          		</ul>
				</div>
	    	</div>
	    </div>
	    <?php } ?>
	</div>
</div>