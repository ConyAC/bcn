<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es-es" lang="es-es">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title><?php echo $TITLE;?></title>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>css/cupertino/jquery-ui-1.8.18.custom.css<?php echo $this->config->item('REVISION_CSS');?>" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap1.css<?php echo $this->config->item('REVISION_CSS');?>" type="text/css" />
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>css/style.css<?php echo $this->config->item('REVISION_CSS');?>" />
		<?php if($this->uri->segment(1) == 'requests' && $this->uri->segment(2) == 'create') { ?>
		<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>css/out_style6.css<?php echo $this->config->item('REVISION_CSS');?>" />
		<?php } ?>
		<link type="text/css" href="<?php echo base_url();?>css/tipsy.css<?php echo $this->config->item('REVISION_CSS');?>" rel="stylesheet" />
		<link type="text/css" href="<?php echo base_url();?>css/form.css<?php echo $this->config->item('REVISION_CSS');?>" rel="stylesheet" />
		<link type="text/css" href="<?php echo base_url();?>css/box_messages.css<?php echo $this->config->item('REVISION_CSS');?>" rel="stylesheet" />
		<link type="text/css" href="<?php echo base_url();?>css/home.css<?php echo $this->config->item('REVISION_CSS');?>" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/dropdown.css<?php echo $this->config->item('REVISION_CSS');?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo base_url();?>css/switch.css<?php echo $this->config->item('REVISION_CSS');?>" type="text/css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plugins/cleditor/jquery.cleditor.css<?php echo $this->config->item('REVISION_CSS');?>" />
		<link rel="stylesheet" media="screen" type="text/css" href="<?php echo base_url();?>plugins/colorpicker/css/colorpicker.css<?php echo $this->config->item('REVISION_CSS');?>" />
		
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery-1.7.1.min.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.18.custom.min.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.ui.datepicker-es.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.json-2.3.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.tipsy.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/my_lib.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/popups.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.raty.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/dropdown.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/iphone-style-checkboxes.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.form.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.scrollTo-1.4.2-min.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/bootstrap.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/moment.min.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.formatCurrency.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>plugins/cleditor/jquery.cleditor.min.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>plugins/colorpicker/js/colorpicker.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>plugins/tinymce/jscripts/tiny_mce/jquery.tinymce.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>plugins/pnotify-1.2.0/jquery.pnotify.min.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		<script type="text/javascript" src="<?php echo base_url();?>js/jquery.PrintArea.js<?php echo $this->config->item('REVISION_JS');?>"></script>
		
		<link href="<?php echo base_url();?>plugins/pnotify-1.2.0/jquery.pnotify.default.css<?php echo $this->config->item('REVISION_CSS');?>" media="all" rel="stylesheet" type="text/css" />

		<link rel="shortcut icon" type="image/ico" href="<?php get_image('favicon.ico');?>" />
		<noscript><meta http-equiv="refresh" content="0;url=<?php echo site_url("no_javascript");?>"></noscript>
		<script type="text/javascript">//<![CDATA[
			$(window).load(function() {
				resizeWindow();
				$(".dir").hover(function(){
					$(this).children("ul").show();
				},function(){
					$(this).children("ul").hide();
				});
			});

			$(window).resize(function() {
				resizeWindow();
			});

			$(function(){
				messages = {};
				messages.cant_institutions_text_singular = "<?php echo lang('request_institution');?>";
				messages.cant_institutions_text_plural = "<?php echo lang('request_institutions_lower');?>";
				messages.cant_degrees_text_singular = "<?php echo lang('request_degree');?>";
				messages.cant_degrees_text_plural = "<?php echo lang('request_degrees_lower');?>";
				messages.and = "<?php echo lang('site_and');?>";
				messages.chosen = "<?php echo lang('request_chosen');?>";
				messages.cant_lang_selected_singular = "<?php echo lang('request_one_language_selected');?>";
				messages.cant_lang_selected_plural = "<?php echo lang('request_languages_selected');?>";
				messages.no_filters = "<?php echo lang('phase_no_filters');?>";
				messages.no_actions = "<?php echo lang('phase_no_actions');?>";
				messages.no_attributes = "<?php echo lang('phase_no_attributes');?>";
				messages.no_phases = "<?php echo lang('process_no_phases');?>";
				messages.show_requisites = "<?php echo lang('process_show_requisites');?>";
				messages.wait_a_moment = "<?php echo lang('site_wait_a_moment');?>";
				messages.close = "<?php echo lang('site_close');?>";
				messages.yes = "<?php echo lang('site_yes');?>";
				messages.no = "<?php echo lang('site_no');?>";
				messages.sources = "<?php echo lang('site_sources');?>";
				messages.item_selected = "<?php echo lang('site_item_selected');?>";
				messages.items_selected = "<?php echo lang('site_items_selected');?>";
				messages.institutions = "<?php echo lang('request_institutions');?>";
				messages.degrees = "<?php echo lang('request_degrees');?>";
				messages.languages = "<?php echo lang('request_languages');?>";
				messages.reading = "<?php echo lang('site_reading');?>";
				messages.writing = "<?php echo lang('site_writing');?>";
				messages.speaking = "<?php echo lang('site_speaking');?>";
				messages.must_enter_internal_jobtitle = "<?php echo lang('offer_must_enter_internal_jobtitle');?>";
				messages.cant_load_rj_new_internal_jobtitle = "<?php echo lang('offer_cant_load_rj_new_internal_jobtitle');?>";
				messages.no_data_to_load = "<?php echo lang('offer_no_data_to_load');?>";
				messages.offer_preview = "<?php echo lang('offer_preview');?>";
				messages.request_preview = "<?php echo lang('request_preview');?>";
				messages.no_description = "<?php echo lang('site_no_description');?>";
				messages.phase_undeletable = "<?php echo lang('site_phase_undeletable');?>";
				messages.loading = "<?php echo lang('site_loading');?>";
				messages.no_info = "<?php echo lang('site_no_info');?>";
				messages.invalid_email = "<?php echo lang('site_invalid_email_message');?>";
				
				$('body').ajaxComplete( function(event,request,settings) {

					if(request.status === 401 ){
		                window.location.href = "<?php echo site_url('')?>"; 
		            }
					else if(request.status === 400){
						/*Error a nivel de programación*/
						try {
							var msg = $.parseJSON(request.responseText);
							if(checkVar(msg.error) && checkVar(msg.error.message)) {
								alert(msg.error.message);
							}
							else {
								alert("<?php echo lang('site_unexpected_error');?>");
							}
							
						}
						catch(err) {
							alert("<?php echo lang('site_unexpected_error');?>");
						}

						return false;
		            }
					else if(request.status === 200) {
						;
					}
				});

				<?php if($this->config->item('SHOW_GLOBAL_MESSAGE')) { ?>
				$("#jq-close-global-message").off('click').on('click', function() {
					$("#jq-global-message").remove();
					$.ajax({
						url: '<?php echo site_url('users/ajax_set_global_message');?>',
						type: 'POST',
						data: {option: 'hide'}
					});
				});
				<?php } ?>

				$(".scrollable, .dialog_wrapper").scroll(function() {
					$(this).find(".jq-popup-box").addClass("hidden-obj");
				});

				$("body").off("blur", ".jq-email-field").on("blur", ".jq-email-field", function() {
					checkEmail($(this), messages.invalid_email);
				});

				$("body").off("keydown", ".jq-numeric-field").on("keydown", ".jq-numeric-field", function(e) {
					var key = e.charCode || e.keyCode || 0;
		            // allow backspace, tab, delete, arrows, numbers and keypad numbers ONLY
		            return (key == 8 || key == 9 || key == 46 || (key >= 37 && key <= 40) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));
				});
			});
		//]]></script>
	</head>
	<body class="logueadoTbj7">
		<?php $msg = get_global_message();?>
		<?php if($this->session->userdata('is_logged_in') && $this->config->item('SHOW_GLOBAL_MESSAGE') && $this->session->userdata('OPTION_GLOBAL_MESSAGE') !== 'hide' && trim($msg) != "") { ?>
		<div class="global_message" id="jq-global-message">
			<?php echo $msg;?>
			<a class='minimal-normal-link' id="jq-close-global-message"><?php echo lang('site_close');?></a>
		</div>
		<?php } ?>
		<?php
		/** MENU GLOBAL **/
		$this->load->view('includes/menu_upper');
		if($this->session->userdata('is_logged_in')) {
			$this->load->view('includes/breadcrumb');
		}
		?>
		<div id="container" class="aps" <?php if(!$this->session->userdata('is_logged_in')) echo "style='margin-top:0px;'";?>>
			<div id="sub-content" <?php if(current_url() == site_url('login') || current_url() == site_url('') || !$this->session->userdata('is_logged_in')) { echo "class='login_content'"; } ?>>
				<?php $this->load->view($MAIN_CONTENT);?>
			</div>
		</div>
		<?php if($this->session->userdata('is_logged_in')) { ?>
		<div id="feedback-wrapper" style="position:fixed;top:30%;left:0;z-index:100000;" >
			<?php $this->load->view('feedback/form')?>
		</div>
		<?php } ?>
	</body>
</html>