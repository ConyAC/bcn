<!--  Modal cambiar reporte -->
<div id="modal-change" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo lang("create_reports_change_confirm");?><span class="num-serial"></span></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYesChange"><?php echo lang("index_accept_th");?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Modal eliminar reporte -->
<div id="modal-delete" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo lang("create_reports_delete_confirm");?><span class="num-serial"></span></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYesDelete"><?php echo lang("index_delete_th");?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Modal info reporte -->
<div id="modal-info" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"><?php echo lang("index_info");?></h4>
      </div>
      <div class="modal-body-info-report"></div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYesCancel" data-dismiss="modal"><?php echo lang("site_close");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-chart" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body-chart-report" style="width:40%; height:400px;"></div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYesCancel" data-dismiss="modal"><?php echo lang("site_close");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->