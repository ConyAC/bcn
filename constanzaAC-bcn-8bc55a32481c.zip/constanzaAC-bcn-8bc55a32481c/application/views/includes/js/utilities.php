<?php //GRAFICOS ?>

	<?php //GRAFICO - 1 ?>
	function userStatus (active, desactive) {
    $('#piechart').highcharts({
		    chart: {
		        type: 'pie',
		        spacingTop: 10,
	            spacingRight: 350,
	            spacingBottom: 3,
	            spacingLeft: 0
		    },
		    title: {
		        text: 'Usuarios Activos y No Activos'
		    },
		    xAxis: {
		        categories: ['Activo', 'No Activo']
		    },
		    plotOptions: {
	            series: {
	                allowPointSelect: true
	            },
	            pie: {
	                //center: [200, 200],
	                dataLabels: {
	                    enabled: true
	                }, 
	                size: 250
	            }
	        },
	        series: [{
			    data: [{
			    	name: 'Activo',
			    	color: '#0101DF',
			    	y: parseFloat(active)
			    }, {
			    	name: 'No Activo',
			    	color: '#848484',
			    	y: parseFloat(desactive)
			    }]
		    }]
		  });
		}
	
		$.ajax({
		    url: "<?php echo site_url('report_controller/ajax_view_users');?>", 
		    type: 'POST',
		    async: true,
		    dataType: "json",
		    success: function (data) {		        
		        $.each(data, function(index, value) {
		        	userStatus(value.active, value.desactive);
		        });
		    }
	 });
	 
	 
	 <?php //GRAFICO - 2 ?>
	function productsType (movil, pc, notebook, componente, conectividad, perifericos ) {
    $('#piechart-two').highcharts({
		    chart: {
		        type: 'pie',
		         spacingTop: 10,
	            spacingRight: 350,
	            spacingBottom: 3,
	            spacingLeft: 0
		    },
		    title: {
		        text: 'Productos existentes por tipo'
		    },
		    plotOptions: {
	            series: {
	                allowPointSelect: true
	            },
	            pie: {
	                //center: [200, 200],
	                dataLabels: {
	                    enabled: true
	                }, 
	                size: 250
	            }
	        },
	        series: [{
			    data: [{
			    	name: 'Movil',
			    	color: '#4C0B5F',
			    	y: parseFloat(movil)
			    }, 
			    {
			    	name: 'PCs',
			    	color: '#585858',
			    	y: parseFloat(pc)
			    },
			    {
			    	name: 'Notebook',
			    	color: '#0101DF',
			    	y: parseFloat(notebook)
			    },
			    {
			    	name: 'Componente',
			    	color: '#DF0101',
			    	y: parseFloat(componente)
			    },
			    {
			    	name: 'Conectividad',
			    	color: '#088A08',
			    	y: parseFloat(conectividad)
			    },
			    {
			    	name: 'Perifericos',
			    	color: '#FFFF00',
			    	y: parseFloat(perifericos)
			    }]
		    }]
		  });
		}
	
		$.ajax({
		    url: "<?php echo site_url('report_controller/ajax_view_type_products');?>", 
		    type: 'POST',
		    async: true,
		    dataType: "json",
		    success: function (data) {		        
		        $.each(data, function(index, value) {
		        	productsType(value.movil, value.pc, value.notebook, value.componente, value.conectividad, value.perifericos);
		        });
		    }
	 });
	 
	 
	 <?php //GRAFICO - 3 ?>
	function productsStatus (nuevo, disponible, caducado, asignado) {
    $('#piechart-three').highcharts({
		    chart: {
		        type: 'pie', 
		         spacingTop: 10,
	            spacingRight: 350,
	            spacingBottom: 3,
	            spacingLeft: 0
		    },
		    title: {
		        text: 'Productos por estado'
		    },
		    plotOptions: {
	            series: {
	                allowPointSelect: true
	            },
	            pie: {
	                //center: [200, 200],
	                dataLabels: {
	                    enabled: true
	                }, 
	                size: 250
	            }
	        },
	        series: [{
			    data: [{
			    	name: 'Nuevo',
			    	color: '#4C0B5F',
			    	y: parseFloat(nuevo)
			    }, 
			    {
			    	name: 'Disponible',
			    	color: '#585858',
			    	y: parseFloat(disponible)
			    },
			    {
			    	name: 'Caducado',
			    	color: '#0101DF',
			    	y: parseFloat(caducado)
			    },
			    {
			    	name: 'Asignado',
			    	color: '#DF0101',
			    	y: parseFloat(asignado)
			    }]
		    }]
		  });
		}
	
		$.ajax({
		    url: "<?php echo site_url('report_controller/ajax_view_status_products');?>", 
		    type: 'POST',
		    async: true,
		    dataType: "json",
		    success: function (data) {		        
		        $.each(data, function(index, value) {
		        	productsStatus(value.nuevo, value.disponible, value.caducado, value.asignado);
		        });
		    }
	 });
	 
	 
	<?php //GRAFICO - 4 ?>
	function productsAssigned (assigned, available) {
    $('#piechart-four').highcharts({
		    chart: {
		        type: 'pie', 
		         spacingTop: 10,
	            spacingRight: 350,
	            spacingBottom: 3,
	            spacingLeft: 0
		    },
		    title: {
		        text: 'Producto Asignado'
		    },
		    plotOptions: {
	            series: {
	                allowPointSelect: true
	            },
	            pie: {
	                //center: [200, 200],
	                dataLabels: {
	                    enabled: true
	                }, 
	                size: 250
	            }
	        },
	        series: [{
			    data: [{
			    	name: 'Asignado',
			    	color: '#4C0B5F',
			    	y: parseFloat(assigned)
			    }, 
			    {
			    	name: 'Disponible',
			    	color: '#585858',
			    	y: parseFloat(available)
			    }]
		    }]
		  });
		}
	
		$.ajax({
		    url: "<?php echo site_url('report_controller/ajax_view_assigned_products');?>", 
		    type: 'POST',
		    async: true,
		    dataType: "json",
		    success: function (data) {		        
		        $.each(data, function(index, value) {
		        	productsAssigned(value.assigned, value.available);
		        });
		    }
	 });