<!--  Modal cambiar producto -->
<!-- Modal info producto -->
<div id="modal-info-prod" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header without-border">
        <h4 class="modal-title"><?php echo lang("index_info");?></h4>
      </div>
      <div class="modal-body modal-body-info-prod"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="btnInfo"><?php echo lang("site_close");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-delete" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body modal-body-delete">
        <p><?php echo lang("index_delete_product_confirm");?><span class="num-serial"></span></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYes"><?php echo lang("index_delete_th");?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-allocate" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo lang("allocate_product");?></h4>
      </div>
      <div class="modal-body modal-body-allocate">
      	<span class="hidden-obj jq-msg-allocate">Todos los articulos de este tipo han sido asignados.</span>
        <table>
        	<tr>
        		<td class="jq-user"><?php echo lang("allocate_user");?></td>
                <td class="jq-user-select"><select id="jq-user-product" class="form-control my_select" name="table_where" style="display: inline-block;"></select></td>
        	</tr>
        	<tr>
        		<td class="jq-quantity-value hidden-obj"><?php echo lang("allocate_quantity");?></td>
                <td><input type="text" id="jq-quantity-value" name="quantity" class='form-control input_text small quantity-value hidden-obj' placeholder="Ej.: 1" value="" /></td>
        	</tr>
        </table>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnAllocate"><?php echo lang("index_allocate_product");?></button>
        <button type="button" class="btn btn-default" id="btnCancelAllocate" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-view-allocate" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header without-border">
        <h4 class="modal-title"><?php echo lang("site_allocate");?></h4>
      </div>
      <div class="modal-body modal-body-view-allocate">
	      <table class="jq-table-view-allocate table table-hover">
		      <thead>
				<tr>
					<th class="align-left">Usuario</th>
					<th class="align-left">Cantidad</th>
				</tr>
			</thead>
			<tbody>
		      	<tr class="align-left">
		      		<td><span class="jq-fullname-user"></span></td>
		      		<td><span class="jq-quantity-product"></span></td>
		      	</tr>
		    </tbody>
	      </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="btnViewAllocate" data-dismiss="modal"><?php echo lang("site_close");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
