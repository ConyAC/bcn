<!DOCTYPE html>
<html>
	<head>
		 <!-- <meta charset="utf-8">
   		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
   		 <meta name="viewport" content="width=device-width, initial-scale=1">-->		
   		 
   		 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		 <meta name="viewport" content="width=device-width, initial-scale=1">
		
<title>BCN</title>
<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css">
<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>plugins/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>css/test_style.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>plugins/pnotify-1.2.0/jquery.pnotify.default.css"/>

<script src="<?php echo base_url();?>js/jquery-1.10.1.js"></script>
<script src="<?php echo base_url();?>js/jquery-ui.js"></script>
<script src="<?php echo base_url();?>js/highcharts.js"></script>
<script src="<?php echo base_url();?>js/exporting.js"></script>
<script src="<?php echo base_url();?>js/highchart_settings.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.confirm.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/my_lib.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plugins/jquery.pnotify.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.Rut.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.PrintArea.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.scrollTo-1.4.2-min.js"></script>
<script src="<?php echo base_url();?>js/moment.min.js"></script>
</head>
</html>