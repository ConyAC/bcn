<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">				
<title>BCN</title>
<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-ui.css">
<link href="<?php echo base_url();?>js/calendario_dw/calendario_dw-estilos.css" type="text/css" rel="STYLESHEET" /> 
<link rel="stylesheet" type="text/css"	href="<?php echo base_url();?>css/bootstrap.css" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>css/style.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/font.css" charset="utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/jquery.pnotify.default.css" charset="utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/jquery.pnotify.default.icons.css" charset="utf-8" />

<script src="<?php echo base_url();?>js/jquery-1.10.1.js"></script>
<script src="<?php echo base_url();?>js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.scrollTo-1.4.2-min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/my_lib.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/calendario_dw/calendario_dw.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>plugins/jquery.pnotify.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.PrintArea.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.Rut.js"></script>
<script src="<?php echo base_url();?>js/highcharts.js"></script>
<script src="<?php echo base_url();?>js/moment.min.js"></script>
<script src="<?php echo base_url();?>js/bootstrap.js"></script>
</head>
</html>