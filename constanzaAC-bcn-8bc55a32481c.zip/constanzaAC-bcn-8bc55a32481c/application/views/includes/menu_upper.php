<script type="text/javascript">//<![CDATA[
	$(function() {
		$(document).ready(function() {
			$('#faqs h3').each(function() {
				var tis = $(this), state = false, answer = tis.next('div').hide().css('height','auto').slideUp();
				tis.click(function() {
					state = !state;
					answer.slideToggle(state);
					tis.toggleClass('active',state);
				});
			});
		});

		$(document).ready(function() {
			$('#faqsadm h3').each(function() {
				var tis = $(this), state = false, answer = tis.next('div').hide().css('height','auto').slideUp();
				tis.click(function() {
					state = !state;
					answer.slideToggle(state);
					tis.toggleClass('active',state);
				});
			});
		});

		$('.my_tooltip').tooltip('trigger');		
		//$('#jq-faq').on('shown.bs.modal', function () {});
			
	});
//]]></script>



<!-- Modal -->
<div class="modal fade" id="myModalAdm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo lang('site_close');?></span></button>
        <h4 class="modal-title" id="myModalLabel">Gesti&oacute;n de Existencias - Ayuda</h4>
      </div>
      <div class="modal-body">
        <div id="faqs">
		<h4>&#8226;Inicio Administrador</h4>
			<h3>&iquest;C&oacute;mo visualizar el mensaje?</h3>
		<div>
			<p>Elija el mensaje que desea ver y presione la lupa para ver el contenido.</p>
		</div>
		<h4>&#8226;Admin Usuario</h4>
		<h3>&iquest;C&oacute;mo modifico un usuario?</h3>
		<div>
			<p>Seleccione el usuario que desea modificar y presione el bot&oacute;n en forma de engranaje.</p>
		</div>
			<h3>&iquest;C&oacute;mo le doy permisos al usuario?</h3>
		<div>
			<p>Seleccione el usuario, presione modificar se desplegar&aacute; la pantalla y en la parte inferior se encuentran los checks de permisos de acceso.</p>
		</div>
			<h3>&iquest;C&oacute;mo visualizo la informaci&oacute;n del usuario?</h3>
		<div>
			<p>Seleccione el usuario y presione el &iacute;cono que es una "i".</p>
		</div>
		<h4>&#8226;Admin Producto</h4>
			<h3>&iquest;C&oacute;mo modifico un producto?</h3>
		<div>
			<p>Seleccione el producto que desea modificar y presione el bot&oacute;n que es una engranaje.</p>
		</div>
			<h3>&iquest;C&oacute;mo visualizo la informaci&oacute;n de un producto?</h3>
		<div>
			<p>Seleccione el producto y presione el &iacute;cono que es una "i".</p>
		</div>
		<h4>&#8226;Informes</h4>
		<h3>&iquest;D&oacute;nde creo un reporte?</h3>
		<div>
			<p>Seleccione del men&uacute; principal la opci&oacute;n "Informes" y presione el bot&oacute;n "Crear Reporte".</p>
		</div>
		<h3>&iquest;Qu&eacute; tipos de reportes existen?</h3>
		<div>
			<p>Existen los reportes din&aacute;micos que los crea usted y estos pueden ser est&aacute;ticos si los ancla a la lista de reportes.</p>
		</div>
		<h3>&iquest;C&oacute;mo crear un reporte?</h3>
		<div>
			<p>Presione el bot&oacute;n "Crear Reporte" y se desplegar&aacute; el formulario de creaci&oacute;n.</p>
		</div>
		<h3>&iquest;Qu&eacute; acciones puedo realizar con los reportes din&aacute;micos?</h3>
		<div>
			<p>Los reportes din&aacute;micos tienen 6 acciones:</br>
		       El bot&oacute;n 'i' da informaci&oacute;n del reporte, </br>
			   El bot&oacute;n 'Excel' exporta el reporte a archivo Excel, </br>
			   El bot&oacute;n 'Gr&aacute;fico' Visualiza la informaci&oacute;n del reporte en gr&aacute;fico,</br>
			   El bot&oacute;n 'Impresora' imprime el reporte, </br>
			   El bot&oacute;n 'pincho sujeta papeles' es para fijar el reporte como est&aacute;tico,</br>
			   El bot&oacute;n 'x' es para eliminar el reporte.
			   </p>
		</div>
		<h3>&iquest;Qu&eacute; acciones puedo realizar con los reportes est&aacute;ticos?</h3>
		
		<div>
			<p>Los reportes est&aacute;ticos tienen 5 acciones:</br>
		       El bot&oacute;n 'i' da informaci&oacute;n del reporte, </br>
			   El bot&oacute;n 'Excel' exporta el reporte a archivo Excel, </br>
			   El bot&oacute;n 'Gr&aacute;fico' Visualiza la informaci&oacute;n del reporte en gr&aacute;fico,</br>
			   El bot&oacute;n 'Impresora' imprime el reporte, </br>
			   El bot&oacute;n 'x' es para eliminar el reporte.
			   </p>
		</div>
		</div>		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang('site_close');?></button>
      </div>
    </div>
  </div>
</div>


<!-- Modal 2-->
<div class="modal fade" id="myModalObs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"><?php echo lang('site_close');?></span></button>
        <h4 class="modal-title" id="myModalLabel">Gesti&oacute;n de Existencias - Ayuda</h4>
      </div>
      <div class="modal-body">
        <div id="faqs">
		<h4>&#8226;Usuario Observador</h4>
		<h3>&iquest;C&oacute;mo solicitar un producto?</h3>
		
		<div>
			<p>En su p&aacute;gina de inicio tiene un link al lado derecho que tiene la imagen</br>
			   de un sobre el cual lo env&iacute;a al formulario de solicitud de producto.</br>
			   Debe llenar los siguientes campos: Nombre Completo, Cargo, Correo </br>
			   y el mensaje con el producto que solicita, presione "Enviar".</br>
			   Si no desea enviar el mensaje, presione "Cancelar".</br>
			   </p>
		</div>
		<h3>&iquest;Qu&eacute; visualizo en la p&aacute;gina de inicio?</h3>
		
		<div>
			<p>Puede ver sus datos personales, los productos asignados y el link para solicitar productos.
			   </p>
		</div>
		<h3>&iquestSi no tengo productos asignados,&iquest;Qu&eacute; se ve en la p&aacute;gina? </h3>
		
		<div>
			<p>Ver&aacute; un mensaje "Usted no tiene productos asociados, si desea realizar</br>
			   una solicitud presione el siguiente enlace".</br>
			   </p>
		</div>
		</div>		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang('site_close');?></button>
      </div>
    </div>
  </div>
</div>

<div class="navbar navbar-default my-navbar" role="navigation">
	    <div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		    </div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">				
				<?php $user = $this->ion_auth->user()->row(); 
					  $group_id = $this->ion_auth->group_test($user->id);
				
					  $admin = false;
						foreach ($group_id as $gid){
							$var = $gid->groupId;
							if($var == 1){
								$admin = true;
							}
						}
						if(!$admin){
							$class="style='display: none;'";	
							$data_target= "#myModalObs";
						}else{
							$class="";
							$data_target= "#myModalAdm";
						}	
?>
					<ul class="nav navbar-nav" >							
						<li class="divider-vertical"></li>
						<li class="menu-select-inicio"><a href="<?php echo site_url('auth/home');?>"><span class="inicio"><?php echo lang('menu_in');?></span></a></li>
																																
						<li class="divider-vertical" <?php echo $class; ?>></li>
						<li class="menu-select-admuser" <?php echo $class; ?>><a href="<?php echo site_url('auth/index');?>"><span class="admuser"><?php echo lang('menu_au');?></span></a></li>
												
						<li class="divider-vertical" <?php echo $class; ?>></li>
						<li class="menu-select-admprod" <?php echo $class; ?>><a href="<?php echo site_url('pages/adminProduct');?>"><span class="admprod"><?php echo lang('menu_ap');?></span></a></li>
						
						<li class="divider-vertical" <?php echo $class; ?>></li>
						<li class="menu-select-informes" <?php echo $class; ?>><a href="<?php echo site_url('pages/reports');?>"><span class="informes"><?php echo lang('menu_re');?></span></a></li>
						
						<li class="divider-vertical"></li>
						<li class="dropdown">
	              			<a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo lang('menu_id');?><b class="caret"></b></a>
	              			<ul class="dropdown-menu language-menu" role="menu" aria-labelledby="dLabel">
								<li class="jq-switch-language">
									<a href="<?php echo site_url('langSwitch/switchLanguage/english');?>" ><?php echo lang('menu_select_lang_i');?></a>
									<a href="<?php echo site_url('langSwitch/switchLanguage/spanish');?>" ><?php echo lang('menu_select_lang_e');?></a>
									<input type="hidden" value="" class="jq-language-key" />
								</li>	
	              			</ul>
	              		</li>					
					</ul>
					<ul class="nav navbar-nav navbar-right">
	            		<li class="divider-vertical">
	              			<a href="<?php echo site_url('auth/logout');?>"> 
	                  			<img class="logout" src="<?php get_image('logout.png');?>"> <?php echo lang('index_logout')?></a>
	            		</li>
	            		<li class="divider-vertical">
							<a class="link-modal" data-toggle="modal" data-target="<?php echo $data_target;?>">
	            				<span class="my_tooltip" data-toggle="tooltip" title="<?php echo lang('site_faq');?>"><i class="glyphicon glyphicon-list-alt"></i></span></a>
	            		</li>
	          		</ul>
				</div>
	    	</div>
	    </div>
	</div>