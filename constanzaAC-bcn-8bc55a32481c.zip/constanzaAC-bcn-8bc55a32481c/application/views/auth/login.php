<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	
	$(".jq-submit").off("click").on("click",function(){
		if(!checkForm(".jq-form-signin", ''))
			return false;
	});
});		
//]]></script>
<br>		
<div class="container container-login">
	<div class="row">
		<div class="col-sm-6 col-md-4 col-md-offset-4">
				<div class="account-wall">
					<img class="profile-img" src="<?php get_image('logo_bcn.png');?>" alt="BCM">
					<div class="form-signin jq-form-signin">
					<?php echo form_open("auth/login");?>
						 <?php echo form_input_mail_login($identity);?>
						  <?php echo form_input_password_login($password);?>
						<button class="btn btn-lg btn-primary btn-block jq-submit" type="submit"><?php echo lang('login_submit_btn');?></button>
						<!-- <label class="checkbox pull-left"><input type="checkbox" value="remember-me"><?php echo lang('login_remember_label');?></label>-->
						<?php echo form_close();?>
					</div>
					<div id="infoMessage" class="signin"><?php echo $message;?></div>
				</div>
		</div>
	</div>
</div>