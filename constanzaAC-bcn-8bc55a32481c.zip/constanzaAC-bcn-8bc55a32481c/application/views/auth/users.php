<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link
	rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>css/bootstrap.css" />
<link 
	rel="stylesheet" type="text/css" media="all" 
	href="<?php echo base_url();?>css/style.css" />
<link
	rel="stylesheet" type="text/css"
	href="<?php echo base_url();?>css/font.css" charset="utf-8" />
<title> BCN </title>

<div id="menu-upper" class="">
<div class="container-fluid banner-header">
	<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
	<span class="tag_line">Sistema de Inventario - BCN</span>
</div>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('index_heading');?></span>	
	<div class="btn-group third">
		<a><?php echo anchor('auth/create_user', lang('index_create_user_link'))?></a>
	</div>
</div>		
<div id="infoMessage"><?php echo $message;?></div>

<table class="jq-table-offer-results table table-hover">
		<thead>
			<tr>
				<?php $width1 = 20; $width2 = 20; $width3 = 20; $width4 = 15; $width5 = 15; $width6 = 10; ?>
				<th width="<?php echo $width1;?>%"><?php echo lang('index_fname_th');?></th>
				<th width="<?php echo $width2;?>%"><?php echo lang('index_lname_th');?></th>
				<th width="<?php echo $width3;?>%"><?php echo lang('index_email_th');?></th>
				<th width="<?php echo $width4;?>%"><?php echo lang('index_groups_th');?></th>
				<th class="align-left" width="<?php echo $width5;?>%"><?php echo lang('index_status_th');?></th>
				<th class="align-left" width="<?php echo $width6;?>%"><?php echo lang('index_action_th');?></th>
			</tr>
		</thead>
		<tbody>
	<?php foreach ($users as $user):?>
		<tr>
			<td><?php echo $user->first_name;?></td>
			<td><?php echo $user->last_name;?></td>
			<td><?php echo $user->email;?></td>
			<td>
				<?php foreach ($user->groups as $group):?>
					<?php echo anchor("auth/edit_group/".$group->id, $group->name) ;?><br />
                <?php endforeach?>
			</td>
			<td><?php echo ($user->active) ? anchor("auth/deactivate/".$user->id, lang('index_active_link')) : anchor("auth/activate/". $user->id, lang('index_inactive_link'));?></td>
			<td><?php echo anchor("auth/edit_user/".$user->id, 'Edit') ;?></td>
		</tr>
	<?php endforeach;?>
</table>
