<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	
		selectMenuUpperAdmUser();
		
	$("#jq-rut-valid").Rut({			
		   on_error: function(){ 
			   	$(".msg-rut-invalid").html("");
				$(".msg-rut-invalid").append("<?php echo lang("site_rut");?>");						
			    },
		   on_success:function(){ 
				$(".msg-rut-invalid").html("");						
		    }
	});
	
	$(".jq-input-date").datepicker({
		 changeMonth: true,
		 changeYear: true
	});
	
});		
//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('edit_user_heading');?></span>
</div>		
<div class="panel panel-default">
  <div class="panel-body">
<div id="jq-add-user-div" class="add_user scrollable">
<div id="jq-user-form">
<?php echo form_open(uri_string());?>
<table class="form-user">
      <tr>                
            <td><?php echo lang('create_user_fname_label', 'first_name');?></td>
            <td><?php echo form_input_large($first_name);?></td>
            
            <td><?php echo lang('site_language', 'language');?></td>
            <td><span class="td-left"><?php echo form_dropdown('language', $languageList, $language['value']);?></span></td>  
      </tr>
      <tr>	      
             <td><?php echo lang('create_user_lname_label', 'first_name');?></td>
             <td><?php echo form_input_large($last_name);?> </td>
             
             <td><?php echo lang('create_user_password_label', 'password');?></td>
             <td><span class="td-left"><?php echo form_input_large($password);?></span></td>
      </tr>
       <tr>
             <td> <?php echo lang('create_user_email_label', 'email');?></td>
             <td> <?php echo form_input_mail($email);?> </td>         
             
             <td> <?php echo lang('create_user_password_confirm_label', 'password_confirm');?></td>
             <td><span class="td-left"><?php echo form_input_large($password_confirm);?></span></td>              
      </tr>  
      <tr>
             <td><?php echo lang('create_user_lrut_label', 'rut');?></td>
             <td><?php echo form_input_id($rut, '', '', 'jq-rut-valid');?></td>                       
             
             <td><span class="msg-rut-invalid"></span></td> 
      </tr>  
      <tr>
             <td><?php echo lang('create_user_phone_label', 'phone');?></td>
             <td> <?php echo form_input_large($phone);?> </td>                    
      </tr> 
      <tr>
             <td><?php echo lang('create_user_ldate_admission_label', 'dateAdmission');?></td>
             <td><?php echo form_input_date($dateAdmission);?> </td>           
      </tr>      
      <tr>
             <td><?php echo lang('create_user_company_label', 'company');?></td>
             <td><?php echo form_dropdown('departmentId', $department, $departmentId['value']);?> </td>           
      </tr>      
      <tr>
             <td><?php echo lang('create_user_jobtitle_label', 'jobtitle');?></td>
             <td><?php echo form_dropdown('jobtitleId', $jobtitle, $jobtitleId['value']);?> </td>
      </tr>
      	   	<td><?php echo lang('edit_user_groups_heading', 'group');?></td>
      	   	<?php foreach ($groups as $group):?>
			<td><label class="checkbox">
				<?php
					$gID=$group['id'];
					$checked = null;
					$item = null;
					foreach($currentGroups as $grp) {
						if ($gID == $grp->id) {
							$checked= ' checked="checked"';
						break;
						}
					}
				?>
				<input type="checkbox" name="groups[]" value="<?php echo $group['id'];?>"<?php echo $checked;?>>
				<?php echo $group['name'];?>
				</label></td>
	<?php endforeach?>      	   
      </tr>
	      <?php echo form_hidden('id', $user->id);?>
	      <?php echo form_hidden($csrf); ?>
      <tr>
      <td style="padding-top: 30px;"><?php echo form_submit('submit', lang('edit_user_submit_btn'));?></td>
      <td><a href="<?php echo site_url('auth/index');?>" id="jq-create-product"> 
	            <input style="margin-top: 29px;" class="btn btn-small btn-success" type="button" value="Cancelar"></a></td>
      
      </tr>
      </table>
<?php echo form_close();?>
</table>
</div>
<div id="infoMessage" class="create-user-message"><?php echo $message;?></div>
</div>
</div>
</div>