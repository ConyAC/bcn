<?php $this->load->view("includes/head");?>
<div id="menu-upper" class="">
<div class="container-fluid banner-header">
	<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
	<span class="tag_line">Sistema de Inventario - BCN</span>
</div>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('deactivate_heading');?></span>
</div>	

<div id="jq-add-user-div" class="main-information-fields add_user left-wrapper scrollable">
<div id="jq-user-form">
<table>
<p><?php echo sprintf("�".lang('deactivate_subheading'), $user->username."?");?></p>

<?php echo form_open("auth/deactivate/".$user->id);?>
 <tr>
 <td><?php echo lang('deactivate_confirm_y_label', 'confirm');?></td>
 <td><input type="radio" name="confirm" value="yes" checked="checked" /></td>
 <td><?php echo lang('deactivate_confirm_n_label', 'confirm');?></td>
 <td><input type="radio" name="confirm" value="no" /></td>
 </tr>

  <?php echo form_hidden($csrf); ?>
  <?php echo form_hidden(array('id'=>$user->id)); ?>

  <tr><td style="padding-top: 30px;"><?php echo form_submit('submit', lang('deactivate_submit_btn'));?></td></tr>

<?php echo form_close();?>
</table>
</div>
</div>