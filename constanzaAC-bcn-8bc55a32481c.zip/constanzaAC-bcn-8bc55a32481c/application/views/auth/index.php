<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
$(function() {
	selectMenuUpperAdmUser();	
	$('.my_tooltip').tooltip('trigger');

	/* Eliminar un usuario - Ventana Modal.*/
	$("body").off("click", "#jq-delete-user").on("click", "#jq-delete-user", function() {	
		var tr_selected = $(this).parentsUntil("tr").parent();	
		$('#modal-delete').data('id', tr_selected).modal('show');			
	});

	$('#btnYes').click(function() {
		var tr_selected = $('#modal-delete').data('id');
	    $.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('auth/delete_users');?>", 
	         data: {id: tr_selected.find(".jq-user-id").val(), csrf: tr_selected.find(".jq-hidden-csrf").val()},
	         dataType: "text",   
	         cache:false,
	         success:  
	              function(data){ 
	              <?php echo notify("El usuario se ha eliminado con &eacute;xito", "success"); ?>;
	            	 $('#modal-delete').modal('hide');
	        		 $(tr_selected).remove();		        	 
	              }	 	                
	     }); 
	});

	/* Buscar usuario*/
	$("#send_users").click(function()
		    {       
		     $.ajax({
		         type: "POST",
		         url: "<?php echo site_url('auth/ajax_search_user');?>", 
		         data: {textbox: $("#textbox").val()},
		         dataType: "text",  
		         cache:false,
		         success: 
		              function(data){
		                var result = $('<div />').append(data).find('.jq-table-offer-results').html();
			            $('.jq-table-offer-results').html(result);			                
		              }
		     });
		     return false;
		 });

	/* Activar/Desactivar usuario*/
	$("body").off("click", ".jq-active-user").on("click", ".jq-active-user", function() {
		var tr_selected = $(this).parentsUntil("tr").parent();	
		  if(tr_selected.find(".jq-active-user").is(':checked')) {
			  $('#modal-active').data('id', tr_selected).modal('show');	
		 }else{
			 $('#modal-desactive').data('id', tr_selected).modal('show');				 
		 }			  	
	 });  

			  
	$('#modal-active').find('#btnYes').click(function() {
		var tr_selected = $('#modal-active').data('id');
		 $.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('auth/deactivate');?>", 
	         data: {id: tr_selected.find(".jq-user-id").val(), confirm:"no"},
	         dataType: "text",  
	         cache:false,
	         success:  
	              function(data){
	              <?php echo notify("El usuario se ha activado con &eacute;xito", "success"); ?>;
	              $('#modal-active').modal('hide');
	              }	 	                
	     });	
	});

	$('#modal-desactive').find('#btnYes').click(function() {
		var tr_selected = $('#modal-desactive').data('id');
		$.ajax({ 
	         type: "POST",
	         url: "<?php echo site_url('auth/deactivate');?>", 
	         data: {id: tr_selected.find(".jq-user-id").val(), confirm:"yes"},
	         dataType: "text",  
	         cache:false,
	         success:  
	              function(data){
	              <?php echo notify("El usuario se ha desactivado con &eacute;xito", "success"); ?>;
	              $('#modal-desactive').modal('hide');
	              }	 	                
	     });	
	});

//$(tr_selected).find(".jq-active-user").prop('checked', false);

	$("body").off("click", "#jq-view-user").on("click", "#jq-view-user", function() {	
		var tr_selected = $(this).parentsUntil("tr").parent();        	
		$.ajax({ 
		   type: "POST",
		   url: "<?php echo site_url('pages/ajax_view_user');?>", 
		   data: {id: tr_selected.find(".jq-user-id").val()},
		   cache:false,
		   success: function(data){	
			   /* JSON : [{"rut":null,"email":"constanza.aravenac@gmail.com","created_on":"1382398956","first_name":"Constanza","last_name":"Aravena","departmentId":null,
		         "phone":"6890627","jobtitleId":null,"dateAdmission":null,"Area":null,"Cargo":null}]*/
		   	 var resp = $.parseJSON(data);	

		   	$.each(resp, function(index, value) {				 				        		
			   	 var html = "<div class='jq-result-view-user text-align'>";
	    		 html += "<table class='table table-hover'>";
	    		 html += "<tr>";				     
	        	 html += "<td> Nombres</td>";   	
	        	 html += "<td> "+ value.first_name+" </td> ";	
	        	 html += "</tr>";
	        	 html += "<tr>";				     
	        	 html += "<td> Apellidos</td>";   	
	        	 html += "<td> "+ value.last_name+" </td> ";	
	        	 html += "</tr>";
	    		 html += "<tr>";		
	    		 html += "<td> Rut</td>";
	    		 html += "<td> "+ value.rut+" </td>";
	        	 html += "</tr>";
	        	 html += "<tr>";						        
	        	 html += "<td> Email</td>";	         	 
	        	 html += "<td> "+ value.email+" </td> ";
	        	 html += "<tr>";				     
	        	 html += "<td> Tel&eacute;fono</td>";   	
	        	 html += "<td> "+ value.phone+" </td> ";			
	        	 html += "</tr>";
	        	 html += "<tr>";		        	
	        	 html += "<td> Fecha Admisi&oacute;n</td>";
	        	 html += "<td> "+ value.dateAdmission+" </td> ";		
	        	 html += "</tr>";
	        	 html += "<tr>";			        
	        	 html += "<td> &Aacute;rea </td>";	
	        	 html += "<td> "+ value.Area+" </td> ";		
	        	 html += "</tr>";
	        	 html += "<tr>";			        
	        	 html += "<td> Cargo</td>";	
	        	 html += "<td> "+ value.Cargo+" </td> ";		
	        	 html += "</tr>";								      	 
	        	 html += "</table>";				
	        	 html += "</div>";

	        	 $('#modal-info-user').find(".modal-body").append(html);
    		});	
          }	 	                
 		});		
	 	$('#modal-info-user').modal('show');	
	});

	$('#btnInfo').click(function() {
		$('#modal-info-user').modal('hide');
		$('#modal-info-user').find(".modal-body").html('');
		
	});
});
//]]></script>
<!-- Modal info usuario -->
<div id="modal-info-user" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header without-border">
        <h4 class="modal-title"><?php echo lang("index_info");?></h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="btnInfo"><?php echo lang("site_close");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
	              
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div id="modal-delete" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo lang("index_delete_user_confirm");?></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYes"><?php echo lang("index_delete_th");?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-active" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo lang("index_status_activate_user");?></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYes"><?php echo lang("index_accept_th");?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="modal-desactive" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo lang("index_confirm_action");?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo lang("index_status_desactive_user");?></p>
      </div>
      <div class="modal-footer">
      	<button type="button" class="btn btn-primary" id="btnYes"><?php echo lang("index_accept_th");?></button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang("index_cancel_th");?></button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="dialog-view-user" class="view-user text-left" title="Download complete"></div>
<div class="view-header">
	<span class="middle2"><?php echo lang('index_heading');?></span>		
		<form class="navbar-form navbar-right form-search-user" role="search" method="post">
  			<div class="form-group">
  			   <input type="text" class="form-control input-search" id="textbox" placeholder="<?php echo lang("search_user");?>">
  			</div>
  			<button id="send_users" type="submit" name="textbox" class="btn btn-small btn-success"><?php echo lang('create_product_lsearch_label')?></button>
  			<a href="<?php echo site_url('auth/create_user');?>" id="jq-create-user" class="btn btn-small btn-success" role="button"><?php echo lang('create_user_heading');?></a>
		</form>
	</div>	

<div id="infoMessage"><?//php echo $message;?></div>
<div class="scrollable-users-table">
<table class="jq-table-offer-results table table-hover">
<?php if($users == null) {?>
			<tr>
				<td><div class="alert alert-warning" role="alert">
						<strong><?php echo lang("index_warning");?>! </strong><?php echo lang("index_no_results_found");?></div></td>
			</tr>
	<?php }else{?>
		<thead>
			<tr>
				<?php $width1 = 10; $width2 = 15; $width3 = 20; $width4 = 20; $width5 = 10; $width6 = 10; $width7 = 15; ?>
				<th width="<?php echo $width1;?>%"><?php echo lang('index_rut_th');?></th>
				<th width="<?php echo $width2;?>%"><?php echo lang('index_fname_th');?></th>
				<th width="<?php echo $width3;?>%"><?php echo lang('create_user_jobtitle_label');?></th>
				<th width="<?php echo $width4;?>%"><?php echo lang('index_email_th');?></th>
				<th width="<?php echo $width5;?>%"><?php echo lang('index_permission_th');?></th>
				<th class="align-left" width="<?php echo $width6;?>%"><?php echo lang('index_status_th');?></th>
				<th class="align-left" width="<?php echo $width7;?>%"><?php echo lang('index_action_th');?></th>
			</tr>
		</thead>
		<tbody>
			
	<?php foreach ($users as $user):?>
		<tr class="text-left">
		<?php if($user->rut != null){?>
			<td><?php echo $user->rut;?></td>
			<?php }else{?>
			<td><span class="no-info"><?php echo "no disponible";?></span></td>
			<?php }?>
			<td><?php echo $user->first_name.' '.$user->last_name;?><input type="hidden" value="<?php echo $user->id;?>" class="jq-user-id" /></td>
			
			<td><?php foreach ($user->jobtitle as $jobtitle):?>
					<?php echo $jobtitle['name'];?><br />
                <?php endforeach?>
			</td>
			<td><?php echo $user->email;?></td>
			<td>
				<?php foreach ($user->groups as $group):?>
					<!-- <?php echo anchor("auth/edit_group/".$group->id, $group->name) ;?><br />-->
					<?php echo ($group->name) ;?><br />
                <?php endforeach?>
			</td>		
			<?php if($user->active == 1){
							$class="checked='checked'";	
						}else{
							$class="";
						}	?>	
			<td class="checkbox-confirm"><input class="jq-active-user active-user" type="checkbox" <?php echo $class;?> /></td>  
			<!--<td><?php echo ($user->active) ? anchor("auth/deactivate/".$user->id, lang('index_active_link')) : anchor("auth/activate/". $user->id, lang('index_inactive_link'));?></td>-->
			<td>
			<a id="jq-view-user"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('information.png');?>" data-toggle="tooltip" title="<?php echo lang("index_view_user");?>"></a>
			<a href="<?php echo site_url('auth/edit_user/'.$user->id);?>" id="jq-edit-user"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('edit.png');?>" data-toggle="tooltip" title="<?php echo lang("index_edit_user");?>"></a>
			<a id="jq-delete-user"> 
	            <img class="img-reports my_tooltip" style="cursor: pointer;" src="<?php get_image('delete_unit.png');?>" data-toggle="tooltip" title="<?php echo lang("index_delete_th");?>"></a>
			</td>
		</tr>
	<?php endforeach; }?>
</table>
</div>