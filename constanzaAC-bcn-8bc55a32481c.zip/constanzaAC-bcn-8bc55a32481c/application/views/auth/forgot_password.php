<?php $this->load->view("includes/head");?>
<div id="menu-upper" class="">
<div class="container-fluid banner-header">
	<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
	<span class="tag_line">Gesti&oacute;n de Existencias</span>
</div>
</div>
<div class="btn-group back">
		<h4><a><?php echo anchor('auth/login', lang('back'))?></a></h4>
	</div>
<div class="view-header">
	<span class="middle2"><?php echo lang('forgot_password_heading');?></span>	
</div>		
<!-- <div id="infoMessage"><?php echo $message;?></div>-->

<div class="send-forgot-password">
<p><?php echo sprintf(lang('forgot_password_subheading'), $identity_label);?></p>
<div id="infoMessage"><?php echo $message;?></div>

<?php echo form_open("auth/forgot_password");?>
      	<label class="email-forgot-pass" for="email"><?php echo sprintf(lang('forgot_password_email_label'), $identity_label);?></label>
      	<span class="input-forgot-pass"><?php echo form_input_large($email);?></span>
		<br/>
        <span class="submit-forgot-pass"><?php echo form_submit('submit', lang('forgot_password_submit_btn'));?></span>
</div>
<?php echo form_close();?>