<?php $this->load->view("includes/test_head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	
		selectMenuUpperAdmUser();

		$(".jq-phone").find("#phone").addClass("jq-numeric-field");
		$(".jq-phone").find("#phone").addClass("jq-numeric-field");
		$("body").off("change", "#jq-area-id").on("change", "#jq-area-id", function() {	
				 $.ajax({ 
			         type: "POST",
			         url: "<?php echo site_url('pages/ajax_view_jobtitle_by_department');?>", 
			         data: {id: $("#jq-area-id").val()},
			         dataType: "text",  
			         cache:false,
			         success:   
			              function(data){      	
			        		 $("#jq-cargo-id").html(data);
			              }	 	                 
			     });
		});
		
		$("#jq-rut-valid").Rut({			
			   on_error: function(){ 
				   	$(".msg-rut-invalid").html("");
					$(".msg-rut-invalid").append("<?php echo lang("site_rut");?>");						
				    },
			   on_success:function(){ 
					$(".msg-rut-invalid").html("");						
			    }
			});

		 $(".jq-input-date").datepicker({
			 changeMonth: true,
			 changeYear: true
		});

		 $("#jq-send-form").off("click").on("click",function(){
			if(!checkForm(".form-user", ''))
				return false;
			
		});
			 
	});		
//]]></script>
<div id="menu-upper" class="">
		<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
		<span class="tag_line hidden-xs"><?php echo lang('index_title');?></span>
</div>

<?php $this->load->view('includes/menu_upper');?>

<div class="view-header">
	<span class="middle2"><?php echo lang('create_user_heading');?></span>
</div>		

<div class="panel panel-default">
  <div class="panel-body scrollable-users-table">
<div id="jq-add-user-div" class="add_user left-wrapper">
<div id="jq-user-form">
<?php echo form_open("auth/create_user");?>
<table class="form-user">
      <tr>
            <td><?php echo lang('create_user_fname_label', 'first_name');?></td>
            <td><?php echo form_input_large($first_name);?></td>
            
            <td><?php echo lang('site_language', 'language');?></td>
            <td><span class="td-left"><?php echo form_dropdown_id('language', '', $languageList, '');?></span></td>       
      </tr>
      <tr>	      
             <td><?php echo lang('create_user_lname_label', 'first_name');?></td>
             <td><?php echo form_input_large($last_name);?> </td>
             
             <td><?php echo lang('create_user_password_label', 'password');?></td>
             <td><span class="td-left"><?php echo form_input_large($password);?></span></td>
      </tr>
      <tr>
       		 <td> <?php echo lang('create_user_email_label', 'email');?></td>
             <td> <?php echo form_input_mail($email);?> </td>   
                         
             <td> <?php echo lang('create_user_password_confirm_label', 'password_confirm');?></td>
             <td><span class="td-left"><?php echo form_input_large($password_confirm);?></span></td>
      </tr> 
      <tr class="jq-rut">
     		 <td><?php echo lang('create_user_lrut_label', 'rut');?></td>
             <td><?php echo form_input_id($rut, '', '', 'jq-rut-valid');?></td>              
             <td><span class="msg-rut-invalid"></span></td>                       
      </tr>   
      <tr>
       		<td><?php echo lang('create_user_ldate_admission_label', 'dateAdmission');?></td>
             <td><?php echo form_input_date($dateAdmission);?> </td>    
      </tr> 
      <tr class="jq-phone">
             <td><?php echo lang('create_user_phone_label', 'phone');?></td>
             <td> <?php echo form_input($phone);?> </td>         
      </tr>      
      <tr>
             <td><?php echo lang('create_user_company_label', 'company');?></td>
             <td><?php echo form_dropdown_id('departmentId', 'jq-area-id', $department, '');?> </td>           
      </tr>      
      <tr>
             <td><?php echo lang('create_user_jobtitle_label', 'jobtitle');?></td>
             <td><select name="jobtitleId" id="jq-cargo-id" class="jq-required-field" ><option value="">Seleccionar</option></select></td>
      </tr>
      <tr> <td style="padding-top: 30px;"><input type="submit" id='jq-send-form' class='btn btn-small btn-success' value="<?php echo lang('create_user_submit_btn');?>" /></td>
		   <td style="padding-top: 30px;"><?php echo form_reset('reset', lang('create_user_cancel_btn'));?> </td></tr>      
<?php echo form_close();?>
</table>
</div>
<div id="infoMessage" class="create-user-message"><?php echo $message;?></div>
</div>
</div>
</div>