<?php $this->load->view("includes/head");?>
<script type="text/javascript">//<![CDATA[
	$(function(){	

		var name_user = $("input[name='name']").val(),
		jobtitle_user = $("input[name='jobtitle']").val(),
		email_user	  = $("input[name='email']").val(),
		message_user  = $("textare[name='message']").val();
		
		$("#jq-send-email").click(function(){      
			console.log("ingreso"); 
			console.log(name_user); 
			     $.ajax({
			         type: "POST",
			         url: "<?php echo site_url('email_controller/ajax_save_email');?>", 
			         data: { name: name_user, jobtitle:jobtitle_user, email:email_user, message:message_user},
			         dataType: "text",  
			         cache:false,
			         success: 
			              function(data){

			        	 console.log(data);
			                		                
			              }
			     });
			    // return false;
			 });
				
	});		
//]]></script>
<div id="menu-upper" class="">
<div class="container-fluid banner-header">
	<img class="company-logo" height="69px;" alt="logo" src="<?php get_image('logo_bcn.png');?>">
	<span class="tag_line">Gesti&oacute;n de Existencias</span>
</div>
</div>

<?php $this->load->view('includes/menu_upper');?>
<!DOCTYPE html>
<html>   
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<title><?php echo $title;?></title>
</head>
<body>
<div id="container">
<div>
    <h1><?php echo $title;?></h1>
</div>
<?php 
  $attributes = array('id' => 'form_email'); 
   if($msg===NULL){ 
   	
   	echo form_open("email_controller/send_email");?>   	
   	  <div><?php echo form_label('Nombre');?></div>             
     	 <div><?php echo form_input_large($name);?></div>
      <div><?php echo form_label('Cargo');?></div>  
     	 <div><?php echo form_input_large($jobtitle);?></div>
      <div><?php echo form_label('Email');?></div>
     	 <div><?php echo form_input_large($email);?></div>
      <div><?php echo form_label('Mensaje');?></div>
     	 <div><?php echo form_textarea($message)?></div>    
   	   <?php echo form_submit_email('submit', 'Enviar');?> </td>
   	   <?php echo form_reset('reset', lang('create_user_cancel_btn'));?>
   	   
   	<?php echo form_close();?>

 <?php }else
           { echo anchor('auth/home','Volver').br(2);
       }?>
</div>
</body>
</html> 