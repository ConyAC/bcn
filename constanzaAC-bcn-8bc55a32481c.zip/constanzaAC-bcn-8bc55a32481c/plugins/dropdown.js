/*Cerrar un dropdown*/
function closeDropdown(dropdown) {
	var status = $(dropdown).find(".jq-dropdown-status-input");
	$(status).val('closed');
	$(dropdown).find("li:not(.jq-dropdown-selected):not(.jq-dropdown-status)").hide();
}

/*Resetear/Inicializar un dropdown*/
function resetDropdown(dropdown) {
	$(dropdown).find(".jq-dropdown-active").removeClass('jq-dropdown-active').removeClass('dropdown-active');
	$(dropdown).find("li:nth-child(2)").addClass('jq-dropdown-active').addClass('dropdown-active');
	var new_html = $(dropdown).find(".jq-dropdown-active").html();
	$(dropdown).find("li.jq-dropdown-selected").html(new_html);
}

$(function() {
	/*Click en el select, comportamiento normal cuando está cerrado*/
	$("body").delegate(".jq-dropdown:not(.jq-visible) .jq-dropdown-selected", "click", function() {
		$(".jq-dropdown").css("z-index", "9999");
		$(".jq-dropdown-checker").css("z-index", "9999");
		$(this).parent(".jq-dropdown").css("z-index","10000");
		var status = $(this).parent(".jq-dropdown").find(".jq-dropdown-status-input");
		if($(status).val() == 'closed') {
			$(".jq-dropdown:not(.jq-visible)").each(function() {
				closeDropdown($(this));
			});
			
			$(".jq-dropdown-checker").each(function() {
				closeDropdown($(this));
			});

			$(status).val('open');
			$(this).parent(".jq-dropdown").find("li:not(.jq-dropdown-status)").show();
		}
		else {
			closeDropdown($(this).parent(".jq-dropdown"));
		}
	});
	
	/*Click en una opcion que no es la seleccionada actual*/
	$("body").delegate(".jq-dropdown:not(.jq-visible) li:not(.jq-dropdown-selected)", "click", function() {
		$(this).parent(".jq-dropdown").find("li.jq-dropdown-selected").html($(this).html());
		$(this).parent(".jq-dropdown").find(".jq-dropdown-active").removeClass("jq-dropdown-active").removeClass("dropdown-active");
		$(this).addClass("jq-dropdown-active").addClass("dropdown-active");
		closeDropdown($(this).parent(".jq-dropdown"));
	});
	
	/*Click en una opcion que no es la seleccionada actual, en un select abierto*/
	$("body").delegate(".jq-dropdown.jq-visible li:not(.jq-dropdown-selected)", "click", function() {
		$(this).parent(".jq-dropdown").find(".jq-dropdown-active").removeClass("jq-dropdown-active").removeClass("dropdown-active");
		$(".myArrow").remove();
		$(this).addClass("jq-dropdown-active").addClass("dropdown-active").append("<div class='myArrow'></div>");

		position_li = $(this).position();
		$(this).find(".myArrow").css("top", (position_li.top)+"px");
	});
	
	/*Cuando se hace click fuera de los select*/
	$(document).bind('click', function(e) {
        var $clicked = $(e.target);
        if (! $clicked.parents().hasClass("jq-dropdown") && ! $clicked.parents().hasClass("jq-dropdown-checker")) {
        	$(".jq-dropdown:not(.jq-visible)").find(".jq-dropdown-status-input").val("closed");
            $(".jq-dropdown:not(.jq-visible) li:not(.jq-dropdown-selected):not(.jq-dropdown-status)").hide();

            $(".jq-dropdown-checker").find(".jq-dropdown-status-input").val("closed");
            $(".jq-dropdown-checker li:not(.jq-dropdown-selected):not(.jq-dropdown-status)").hide();
        }
    });
	
	/*Click en el checker, comportamiento normal cuando está cerrado*/
	$("body").delegate(".jq-dropdown-checker .jq-dropdown-selected", "click", function() {
		$(".jq-dropdown").css("z-index", "9999");
		$(".jq-dropdown-checker").css("z-index", "9999");
		$(this).parent(".jq-dropdown-checker").css("z-index","10000");
		var status = $(this).parent(".jq-dropdown-checker").find(".jq-dropdown-status-input");
		if($(status).val() == 'closed') {
			$(".jq-dropdown-checker").each(function() {
				closeDropdown($(this));
			});
			
			$(".jq-dropdown:not(.jq-visible)").each(function() {
				closeDropdown($(this));
			});
			
			$(status).val('open');
			$(this).parent(".jq-dropdown-checker").find("li:not(.jq-dropdown-status)").show();
		}
		else {
			closeDropdown($(this).parent(".jq-dropdown-checker"));
		}
	});

	/*Cerrar el checker*/
	$("body").delegate(".jq-close", "click", function() {
		closeDropdown($(this).parent(".jq-dropdown-checker"));
	});
});