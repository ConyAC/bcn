//Obtener traducciones
//translations = {};
/*$.ajax({
	url: "reports/ajax_get_translations",
	type: "GET",
	async: false,
	success: function(t) {
		console.log(t);
		//translations = $.parseJSON(t);
	}
});*/

//Traducciones
Highcharts.setOptions({
	lang: {
		downloadJPEG: "Descargar JPEG",
		downloadPDF: "Descargar PDF",
		downloadPNG: "Descargar PNG",
		downloadSVG: "Descargar SVG",
		printChart: "Imprimir"
	}
}); 

//Configuracion minima para un grafico de barras simple
bars = {
	chart: {type: 'column', margin: [ 50, 50, 100, 80], width: 930},
	credits: {enabled: false},
	title: {text: ''},
	xAxis: {categories: [], labels: {rotation: -45, align: 'right', style: {fontSize: '9px', fontFamily: 'Verdana, sans-serif'}, formatter: function() {return cutString(this.value, 11);}}},
	yAxis: {min: 0, title: {text: ''}},
	legend: {verticalAlign: 'bottom', y: 10},
	tooltip: {formatter: function() {}},
	plotOptions: {column: {pointPadding: 0.2, borderWidth: 0}},
	series: [{
		name: '',
		data: [],
		dataLabels: {enabled: true, rotation: -90, color: '#FFFFFF', align: 'right', x: 4, y: 10, style: {fontSize: '11px', fontFamily: 'Verdana, sans-serif'}}
	}]
};

//Configuracion minima para un grafico pie
pie = {
	chart: {plotBackgroundColor: null, plotBorderWidth: null, plotShadow: false, width: 930},
	credits: {enabled: false},
	title: {text: ''},
	tooltip: {pointFormat: '{series.name}: <b>{point.percentage:.1f}% ({point.y})</b>'},
	plotOptions: {
		pie: {
			allowPointSelect: true,
			cursor: 'pointer',
			dataLabels: {
				enabled: true,
				color: '#000000',
				connectorColor: '#000000',
				format: '<b>{point.name}</b>: {point.percentage:.1f}% ({point.y})'
			}
		}
	},
    series: [{type: 'pie', name: '', data: []}]
};

//Entrega la configuración mínima de un tipo de grafico
function getHighchartSettings(type) {
	if(type == "bars")
		return $.extend({}, bars);
	if(type == "multiple_bars") {
		var multiple_bars = $.extend({}, bars);
		multiple_bars.tooltip = {};
		multiple_bars.series = [];
		return $.extend({}, multiple_bars);
	}
	if(type == "pie")
		return $.extend({}, pie);
}

//Funcion comun para obtener datos para un grafico de barras simple
function getBarsCommonSettings() {
	var settings = getHighchartSettings("bars");
	settings.xAxis.categories = [];
	$("#jq-details").find("table tbody tr").each(function() {
		var item = $.trim($(this).find("td:first span.jq-full").text());
		settings.xAxis.categories.push(item);
	});
	
	settings.series[0].data = [];
	$("#jq-details").find("table tbody tr").each(function() {
		var total = parseInt($.trim($(this).find("td.jq-total").text()));
		settings.series[0].data.push(total);
	});
	
	return $.extend({}, settings);
}

//Funcion comun para obtener datos para un grafico de barras multiple
function getMultipleBarsCommonSettings() {
	var settings = getHighchartSettings("multiple_bars");
	settings.tooltip = {
		headerFormat: '<span style="font-size:12px; font-weight:bold;">{point.key}</span><br/><br/><table>',
		pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
					'<td style="padding:0; text-align:right;"><b>{point.y}</b></td></tr>',
		footerFormat: '</table>',
		shared: true,
		useHTML: true
	};
	settings.xAxis.categories = [];
	$("#jq-details").find("table tbody tr").each(function() {
		var item = $.trim($(this).find("td:first span.jq-full").text());
		settings.xAxis.categories.push(item);
	});
	settings.legend = {y:15.4};
	settings.series = [];
	$("#jq-details").find(".dataTables_scrollHead table thead th.jq-data").each(function(i) {
		var item = {};
		item.name = $.trim($(this).text());
		item.data = [];
		$("#jq-details").find("table tbody tr").each(function() {
			var data = parseInt($.trim($(this).find(".jq-data").eq(i).text()));
			item.data.push(data);
		});
		
		settings.series.push(item);
	});
	
	return $.extend({}, settings);
}

//Funcion comun para obtener datos para un grafico pie
function getPieCommonSettings() {
	var settings = getHighchartSettings("pie");
	
	settings.series[0].data = [];
	$("#jq-details").find("table tbody tr").each(function() {
		var data = [];
		var name = $.trim($(this).find("td:first span.jq-full").text());
		var total = parseInt($.trim($(this).find("td.jq-total").text()));
		data.push(name);
		data.push(total);
		settings.series[0].data.push(data);
	});
	
	return $.extend({}, settings);
}

//Informe de procesos
function getProcessesReportSettings(key) {
	var settings = getBarsCommonSettings();
	
	settings.title.text = translations.processes_title;
	settings.yAxis.title.text = translations.processes_yaxis_title;
	settings.tooltip.formatter = function() {
		return "<b>"+this.x+"</b><br/> "+translations.processes_tooltip+": "+Highcharts.numberFormat(this.y, 0);
	};
	
	settings.series[0].name = translations.processes_tooltip;
	
	return settings;
}

//Informe de postulaciones a ofertas
function getOfferPostulationsReportSettings(key) {
	var settings = getBarsCommonSettings();
	settings.title.text = translations.offer_postulations_title;
	settings.yAxis.title.text = translations.offer_postulations_yaxis_title;
	settings.tooltip.formatter = function() {
		return "<b>"+this.x+"</b><br/> "+translations.offer_postulations_tooltip+": "+Highcharts.numberFormat(this.y, 0);
	};
	
	settings.series[0].name = translations.processes_tooltip;
	
	return settings;
}

//Informe a nivel empresa
function getCompanyReportSettings(key) {
	var settings = getMultipleBarsCommonSettings();
	settings.title.text = translations.company_title;
	return settings;
}

//Informe de origen de Cvs
function getOriginCVReportSettings(key) {
	var settings = getMultipleBarsCommonSettings();
	settings.title.text = translations.origincv_title;
	return settings;
}

//Informe de procedencia de CVs por proceso
function getCvsProvenanceByProcessReportSettings(key) {
	var settings = getPieCommonSettings();
	settings.title.text = translations.cvs_provenance_by_process_title;
	settings.series[0].name = $.trim($("#jq-details").find("table thead th.jq-total").text());
	return settings;
}

//Informe de días de postulacion
function getDaysOfInscriptionByProcessReportSettings(key) {
	var settings = getMultipleBarsCommonSettings();
	settings.title.text = translations.days_of_inscription_by_process_title;
	return settings;
}

function getGenderByProcessReportSettings(key) {
	var settings = getMultipleBarsCommonSettings();
	settings.title.text = translations.gender_by_process_title;
	return settings;
}

function getConsolidatedProcessesStatusReportSettings(key) {
	var settings = getPieCommonSettings();
	settings.title.text = translations.consolidated_processes_status_title;
	settings.series[0].name = $.trim($("#jq-details").find("table thead th.jq-total").text());
	return settings;
}
function getByUserReportSettings(key) {
	var settings = getMultipleBarsCommonSettings();
	settings.title.text = translations.offers_by_user_title;
	return settings;
}
