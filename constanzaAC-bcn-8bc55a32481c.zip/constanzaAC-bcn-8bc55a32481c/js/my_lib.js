$(function(){

$("body").off("keyup", ".highlight_field").on("keyup", ".highlight_field", function() {
		$(this).removeClass("highlight_field");
		$(this).nextAll(".jq-form-error").remove();
	});
	
	$("body").off("change", ".highlight_field").on("change", ".highlight_field", function() {
		$(this).removeClass("highlight_field");
		$(this).nextAll(".jq-form-error").remove();
	});
});

function isNumeric(n) {
	if($.trim(n) == "")
		return true;
	return parseFloat(n) == parseInt(n, 10) && !isNaN(n) && parseInt(n, 10) >= 0;
}

function isAlphaNumeric(str) {
	if($.trim(str) == "")
		return true;
	var valid_chars = "abcdefghijklmnñopqrstuvwxyz0123456789 .,-():;¿?¡![]{}_|°@/#$%&=*'ª";
	var i;
	str = normalize(str.toLowerCase());
	for(i = 0; i < str.length; i++) {
		var current_char = str.substring(i, i+1);
		if(valid_chars.indexOf(current_char) < 0)
			return false;
	}
	
	return true;
}

function validateEmail(email) {
    email = $.trim(email);
    if(email == "")
		return true;
    
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/igm;
    return re.test(email);
}

function my_normal_date_checker(normal_date2) {
	if($.trim(normal_date2) == "")
		return true;
	normal_date = normal_date2;
	if(!isset(normal_date) || !is_string(normal_date) || normal_date == "" || normal_date.length != 10)
		return false;
	
	var date = normal_date.split("-");
	if(date.length != 3) 
		return false;
	
	var day = date[0];
	var month = date[1];
	var year = date[2];
	return checkdate(month, day, year);
}


function validateHexadecimal(colorcode) {
	 var regColorcode = /^(#)([0-9a-fA-F]{3})([0-9a-fA-F]{3})?$/;
	 return regColorcode.test(colorcode);
}

function checkForm(form, messages) {
	return checkFormFull(form, true, messages);
}

function checkFormFull(form, putAlert, messages) {
	$(form).find(".highlight_field").removeClass("highlight_field");
	$(form).find(".jq-form-error").remove();
	$(form).find(".combonew_wrapper .jq-required-field").addClass("jq-exclude");
	var check = [];
	check.push(checkRequiredFields(form, messages));
	check.push(checkNumericFields(form, messages));
	//check.push(checkAlphaNumericFields(form, messages));
	check.push(checkEmailFields(form, messages));
	check.push(checkDateFields(form, messages));
	check.push(checkHexadecimalFields(form, messages));
	//check.push(checkMinLength(form, messages));
	
	$(form).find(".combonew_wrapper .jq-required-field").removeClass("jq-exclude");
	
	var result = true;
	$.each(check, function(index, value) {
		result = result && value;
	});
	
	if(!result && putAlert)
		alert("Ingrese los datos correctamente");
	
	return result;
}

function insertFormError(msg, where, container) {
	var div = "<div class='red jq-form-error' style='font-size:11px; text-align:left;'>"+msg+"</div>";
	if($(container).hasClass("combonew_wrapper"))
		$(container).append($(div));
	else if($(where).parent().hasClass("combonew_wrapper"))
		$(where).parent().append($(div));
	else
		$(div).insertAfter($(where));
}

function checkRequiredFields(container, messages) {
	var success = true;
	$(container).find(".jq-required-field:not(.jq-exclude)").each(function() {
		if($.trim($(this).val()) == "") {
			if($(this).attr("type") != "hidden") {
				$(this).addClass("highlight_field");
			    insertFormError("campo obligatorio", $(this), $(container));
			}
			success = false;
		}
	});
	return success;
}

function checkNumericFields(container, messages) {
	var success = true;
	$(container).find(".jq-numeric-field:not(.jq-exclude)").each(function() {
		if(!isNumeric($.trim($(this).val()))) {
			$(this).addClass("highlight_field");
			insertFormError("campo n&uacute;merico", $(this), $(container));
			success = false;
		}
	});
	return success;
}

function checkAlphaNumericFields(container, messages) {
	var success = true;
	$(container).find(".jq-alphanumeric-field:not(.jq-exclude)").each(function() {
		if(!isAlphaNumeric($.trim($(this).val()))) {
			$(this).addClass("highlight_field");
			insertFormError("campo alfan&uacute;merico", $(this), $(container));
			success = false;
		}
	});
	return success;
}

function checkEmailFields(container, messages) {
	console.log(container);
	var success = true;
	$(container).find(".jq-email-field:not(.jq-exclude)").each(function() {
		if(!validateEmail($.trim($(this).val()))) {
			$(this).addClass("highlight_field");
			insertFormError("correo inv&aacute;lido", $(this), $(container));
			success = false;
		}
	});
	return success;
}

function checkDateFields(container, messages) {
	var success = true;
	$(container).find(".jq-date-field:not(.jq-exclude)").each(function() {
		if(!my_normal_date_checker($.trim($(this).val()))) {
			$(this).addClass("highlight_field");
			insertFormError("fecha inv&aacute;lido", $(this), $(container));
			success = false;
		}
	});
	return success;
}

function checkHexadecimalFields(container, messages) {
	var success = true;
	$(container).find(".jq-hexadecimal-field:not(.jq-exclude)").each(function() {
		if(!validateHexadecimal($(this).val())) {
			$(this).addClass("highlight_field");
			insertFormError("", $(this), $(container));
			success = false;
		}
	});
	
	return success;
}

function checkRequiredRadioHighlight(radio_class, highlight) {
	var checked = false;
	$(radio_class).each(function() {
		if($(this).attr('checked') == 'checked') {
			checked = true;
			return false;
		}
	});
	
	if(highlight == true) {
		if(checked == false) {
			$(radio_class).each(function() {
				$(this).siblings("label").css('color', 'red');
			});
		}
		else {
			$(radio_class).each(function() {
				$(this).siblings("label").css('color', 'black');
			});
		}
	}
	return checked;
}

function checkRequiredRadio(radio_class) {
	return checkRequiredRadioHighlight(radio_class, true);
}

function removeHighlightFields(container, item_class) {
	$(container).find("."+item_class).each(function() {
		if($.trim($(this).val()) != "")
			$(this).removeClass('highlight_field');
	});
}

function checkVar(x) {
	if(x == null || x == undefined || (typeof x != "object" && $.trim(x) === "") || $.trim(x) === "null" || x === false)
		return false;
		
	return true;
}

function validar_email(valor)
{
	var filter = /[\w-\.]{3,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;
	if(filter.test(valor))
		return true;
	else
		return false;
}

function selectMenuUpperAdmProd(){
	$(".menu-select-admprod").animate({ backgroundColor: "#21759B" }, "slow");
	$(".admprod").css('color', '#FFFFFF');	
}

function selectMenuUpperAdmUser(){
	$(".menu-select-admuser").animate({ backgroundColor: "#21759B" }, "slow");
	$(".admuser").css('color', '#FFFFFF');
}

function selectMenuUpperReports(){
	$(".menu-select-informes").animate({ backgroundColor: "#21759B" }, "slow");
	$(".informes").css('color', '#FFFFFF'); 
}

function hideElement(){
	 $(".jq-label-ram, .jq-label-hdd, .jq-label-cpu, .jq-label-os, .jq-label-imei, .jq-label-user-assigned").hide();
  	 $(".jq-select-ram, .jq-select-hdd, .jq-select-cpu, .jq-select-os, .jq-select-imei, .jq-select-user-assigned").hide();
		
}
function selectType(){
	$("select[name=type]").change(function(){
		   if ( $('select[name=type]').val() == 1 ){
		  	   $(".jq-label-imei").show();
			   $(".jq-select-imei").show();
		   }else{
			   $(".jq-label-imei").hide();
			   $(".jq-select-imei").hide();
		   }
		
		   if ( $('select[name=type]').val() == 2 ){
		  	   $(".jq-label-ram, .jq-label-hdd, .jq-label-cpu, .jq-label-os").show();
		  	   $(".jq-select-ram, .jq-select-hdd, .jq-select-cpu, .jq-select-os").show();
		  	}else{
		  		 $(".jq-label-ram, .jq-label-hdd, .jq-label-cpu, .jq-label-os").hide();
		    	 $(".jq-select-ram, .jq-select-hdd, .jq-select-cpu, .jq-select-os").hide();
		   }   
		});		
}
function selectStatus(){
	$("select[name=statusId]").change(function(){
		   if ( $('select[name=statusId]').val() == 4 ){
			   $(".jq-label-user-assigned").show();
			   $(".jq-select-user-assigned").show();
		   }else{
			   $(".jq-label-user-assigned").hide();
			   $(".jq-select-user-assigned").hide();
		   }
	});
}
//TODO
function getEmailsPending(url){
	$.ajax({
		url: url,
		type: "POST",
		data: {},
		success: function(resp){


			$("#jq-notify-emails").append(resp);
		}	
	});
}

/*Funci�n para destacar un tr*/
function highlightBox( new_tr ){	
	//animaci�n
	$(new_tr).animate('fast', function(){
		$(new_tr).removeClass('invisible-obj').show('highlight', 3000);
		$(new_tr).find("td").animate({backgroundColor: "#F3F781"}, 'slow', function(){
			$(new_tr).find("td").animate({backgroundColor: "#FFFFFF"}, 5000);
		});
	});				
}

$('.my_tooltip').tooltip('trigger');

function quantityShow(){
	$("select[name=type]").change(function(){		
		   if ( $('select[name=type]').val() == 3 || $('select[name=type]').val() == 4 || $('select[name=type]').val() == 5 ){
		  	   	$(".jq-quantity-label, .jq-quantity-input").removeClass("hidden-obj");
		  	}else{
		  		$(".jq-quantity-label, .jq-quantity-input").addClass("hidden-obj");
		   }   
		});		
}