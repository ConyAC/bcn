<?php

// Start of mysqlnd v.mysqlnd 5.0.5-dev - 081106 - $Revision: 1.3.2.27 $
// End of mysqlnd v.mysqlnd 5.0.5-dev - 081106 - $Revision: 1.3.2.27 $
?>
